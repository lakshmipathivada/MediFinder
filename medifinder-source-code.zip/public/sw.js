// Service Worker for MediFinder Background Medicine Reminders, Alarms & Offline Background Sync
const CACHE_NAME = 'medifinder-sw-v6';
const DB_NAME = 'medifinder_idb_v1';
const DB_VERSION = 1;

let cachedReminders = [];
let cachedLogs = [];

// Helper: Open IndexedDB in Service Worker
function openDB() {
  return new Promise((resolve, reject) => {
    const request = indexedDB.open(DB_NAME, DB_VERSION);
    request.onupgradeneeded = (event) => {
      const db = event.target.result;
      if (!db.objectStoreNames.contains('reminders')) {
        db.createObjectStore('reminders', { keyPath: 'id' });
      }
      if (!db.objectStoreNames.contains('logs')) {
        db.createObjectStore('logs', { keyPath: 'id' });
      }
      if (!db.objectStoreNames.contains('sync_queue')) {
        db.createObjectStore('sync_queue', { keyPath: 'id', autoIncrement: true });
      }
    };
    request.onsuccess = (event) => resolve(event.target.result);
    request.onerror = (event) => reject(event.target.error);
  });
}

// Load persisted data from IndexedDB into memory on SW boot/activation
async function loadFromIDB() {
  try {
    const db = await openDB();

    // Load reminders
    const remindersTx = db.transaction('reminders', 'readonly');
    const remindersStore = remindersTx.objectStore('reminders');
    const remindersReq = remindersStore.getAll();
    remindersReq.onsuccess = () => {
      if (remindersReq.result && remindersReq.result.length > 0) {
        cachedReminders = remindersReq.result;
      }
    };

    // Load logs
    const logsTx = db.transaction('logs', 'readonly');
    const logsStore = logsTx.objectStore('logs');
    const logsReq = logsStore.getAll();
    logsReq.onsuccess = () => {
      if (logsReq.result && logsReq.result.length > 0) {
        cachedLogs = logsReq.result;
      }
    };
  } catch (err) {
    console.warn('[SW] Error loading from IndexedDB:', err);
  }
}

// Persist reminders to IndexedDB
async function saveRemindersToIDB(reminders) {
  try {
    const db = await openDB();
    const tx = db.transaction('reminders', 'readwrite');
    const store = tx.objectStore('reminders');
    store.clear();
    reminders.forEach((r) => store.put(r));
    cachedReminders = reminders;
  } catch (err) {
    console.warn('[SW] Error saving reminders to IDB:', err);
  }
}

// Persist logs to IndexedDB
async function saveLogsToIDB(logs) {
  try {
    const db = await openDB();
    const tx = db.transaction('logs', 'readwrite');
    const store = tx.objectStore('logs');
    logs.forEach((l) => store.put(l));
    cachedLogs = logs;
  } catch (err) {
    console.warn('[SW] Error saving logs to IDB:', err);
  }
}

// Add a single dose log to IndexedDB
async function addLogToIDB(logItem) {
  try {
    const db = await openDB();
    const tx = db.transaction('logs', 'readwrite');
    const store = tx.objectStore('logs');
    store.put(logItem);
    cachedLogs.unshift(logItem);
  } catch (err) {
    console.warn('[SW] Error adding log to IDB:', err);
  }
}

// Enqueue offline action into sync_queue
async function enqueuePendingSyncAction(actionType, payload) {
  try {
    const db = await openDB();
    const tx = db.transaction('sync_queue', 'readwrite');
    const store = tx.objectStore('sync_queue');
    store.add({
      action: actionType,
      payload: payload,
      timestamp: Date.now()
    });
  } catch (err) {
    console.warn('[SW] Error queueing sync action:', err);
  }
}

// Process pending sync queue items when online or sync event triggers
async function processBackgroundSync() {
  try {
    const db = await openDB();
    const tx = db.transaction('sync_queue', 'readwrite');
    const store = tx.objectStore('sync_queue');
    const getAllReq = store.getAll();

    getAllReq.onsuccess = async () => {
      const pendingItems = getAllReq.result || [];
      if (pendingItems.length === 0) {
        notifyAllClients('BACKGROUND_SYNC_COMPLETE', { count: 0 });
        return;
      }

      for (const item of pendingItems) {
        if (item.action === 'RECORD_DOSE') {
          const { userPhone, reminderId, timeSlot, status, medicineName } = item.payload;
          const newLog = {
            id: 'log-' + Date.now() + '-' + Math.random().toString(36).substring(2, 7),
            reminderId,
            userPhone: userPhone || '9876543210',
            medicineName: medicineName || 'Medicine',
            scheduledTimeSlot: timeSlot || '08:00',
            takenAt: Date.now(),
            date: new Date().toISOString().split('T')[0],
            status: status || 'taken_on_time'
          };
          await addLogToIDB(newLog);
        } else if (item.action === 'SNOOZE_REMINDER') {
          const { reminderId, minutes } = item.payload;
          const target = cachedReminders.find((r) => r.id === reminderId);
          if (target) {
            target.snoozedUntil = Date.now() + (minutes || 10) * 60 * 1000;
            await saveRemindersToIDB(cachedReminders);
          }
        }
      }

      // Clear sync queue
      const clearTx = db.transaction('sync_queue', 'readwrite');
      clearTx.objectStore('sync_queue').clear();

      // Notify connected app clients
      notifyAllClients('SYNC_REMINDERS', { reminders: cachedReminders });
      notifyAllClients('SYNC_LOGS', { logs: cachedLogs });
      notifyAllClients('BACKGROUND_SYNC_COMPLETE', { count: pendingItems.length });
    };
  } catch (err) {
    console.warn('[SW] Error processing background sync:', err);
  }
}

// Notify all open window clients
function notifyAllClients(type, data) {
  self.clients.matchAll({ type: 'window', includeUncontrolled: true }).then((clients) => {
    clients.forEach((client) => {
      client.postMessage({ type, ...data });
    });
  });
}

// Lifecycle Events
self.addEventListener('install', (event) => {
  self.skipWaiting();
});

self.addEventListener('activate', (event) => {
  event.waitUntil(
    Promise.all([
      self.clients.claim(),
      loadFromIDB()
    ])
  );
});

// Sync Event Listener (Background Sync API)
self.addEventListener('sync', (event) => {
  if (event.tag === 'sync-reminders' || event.tag === 'sync-dose-logs') {
    event.waitUntil(processBackgroundSync());
  }
});

// Web Push Event Listener (Wakes up service worker even when browser/tab is closed!)
self.addEventListener('push', (event) => {
  let data = {};
  if (event.data) {
    try {
      data = event.data.json();
    } catch {
      data = { title: '⏰ Medicine Reminder', body: event.data.text() };
    }
  }

  const title = data.title || '⏰ Medicine Reminder';
  const options = {
    body: data.body || 'Time to take your scheduled dose.',
    icon: data.icon || '/icon.svg',
    badge: data.badge || '/icon.svg',
    tag: data.tag || `med-push-${Date.now()}`,
    sound: '/alarm-digital.wav',
    requireInteraction: true,
    renotify: true,
    silent: false,
    vibrate: [500, 250, 500, 250, 500, 250, 1000],
    data: data.data || {
      url: '/?tab=reminders&autoRing=1',
      reminderId: data.reminderId,
      medicineName: data.medicineName,
      timeSlot: data.timeSlot
    },
    actions: data.actions || [
      { action: 'take', title: 'Take Now' },
      { action: 'snooze', title: 'Snooze 10m' }
    ]
  };

  event.waitUntil(self.registration.showNotification(title, options));
});

// Periodic Sync Event Listener (Periodic Background Sync API)
self.addEventListener('periodicsync', (event) => {
  if (event.tag === 'check-reminders' || event.tag === 'sync-reminders') {
    event.waitUntil(
      Promise.all([
        loadFromIDB(),
        checkAndTriggerAlarms(),
        processBackgroundSync()
      ])
    );
  }
});

// Message Listener from Client App
self.addEventListener('message', (event) => {
  if (!event.data) return;
  if (event.data.type === 'SYNC_REMINDERS') {
    cachedReminders = event.data.reminders || [];
    saveRemindersToIDB(cachedReminders);
  } else if (event.data.type === 'SYNC_LOGS') {
    cachedLogs = event.data.logs || [];
    saveLogsToIDB(cachedLogs);
  } else if (event.data.type === 'CHECK_ALARMS_NOW') {
    if (cachedReminders.length === 0) {
      loadFromIDB().then(() => checkAndTriggerAlarms());
    } else {
      checkAndTriggerAlarms();
    }
  } else if (event.data.type === 'PROCESS_SYNC_NOW') {
    processBackgroundSync();
  } else if (event.data.type === 'SCHEDULE_TEST_NOTIFICATION') {
    const delay = event.data.delay || 5000;
    setTimeout(() => {
      self.registration.showNotification('⏰ MediFinder Medicine Alert: Dolo 650', {
        body: 'Time to take 1 tablet (After Food). Tap to open alarm!',
        icon: '/icon.svg',
        badge: '/icon.svg',
        tag: 'med-test-alarm-' + Date.now(),
        sound: '/alarm-digital.wav',
        requireInteraction: true,
        renotify: true,
        silent: false,
        vibrate: [1000, 250, 1000, 250, 1000, 250, 2000],
        data: {
          url: '/?tab=reminders&autoRing=1&test=1',
          reminderId: 'test-dolo-650',
          medicineName: 'Dolo 650',
          timeSlot: 'Now'
        },
        actions: [
          { action: 'take', title: '💊 Mark Taken' },
          { action: 'snooze', title: '⏰ Snooze 10m' }
        ]
      });
    }, delay);
  }
});

// Periodic background check loop inside SW
setInterval(() => {
  if (cachedReminders.length === 0) {
    loadFromIDB().then(() => checkAndTriggerAlarms());
  } else {
    checkAndTriggerAlarms();
  }
}, 20000); // Check every 20 seconds

function checkAndTriggerAlarms() {
  if (!cachedReminders || cachedReminders.length === 0) return;

  const now = new Date();
  const currentHours = now.getHours().toString().padStart(2, '0');
  const currentMinutes = now.getMinutes().toString().padStart(2, '0');
  const currentTimeSlot = `${currentHours}:${currentMinutes}`;
  const todayStr = now.toISOString().split('T')[0];

  cachedReminders.forEach((rem) => {
    if (!rem.active) return;

    if (rem.snoozedUntil && Date.now() < rem.snoozedUntil) {
      return;
    }

    const matchesTime = rem.times.includes(currentTimeSlot);
    const isSnoozeExpired = rem.snoozedUntil && Date.now() >= rem.snoozedUntil;

    if (matchesTime || isSnoozeExpired) {
      const timeSlotKey = isSnoozeExpired ? 'snooze' : currentTimeSlot;
      const notificationTag = `med-alarm-${rem.id}-${timeSlotKey}-${todayStr}`;

      self.registration.getNotifications({ tag: notificationTag }).then((existingNotifications) => {
        if (existingNotifications.length === 0) {
          triggerBackgroundNotification(rem, timeSlotKey, notificationTag);
        }
      });
    }
  });
}

function triggerBackgroundNotification(rem, timeSlot, tag) {
  const title = `⏰ Medicine Reminder: ${rem.medicineName}`;
  const options = {
    body: `Time to take your dose: ${rem.dosage} (${rem.foodInstruction || 'As directed'}). Tap to open alarm.`,
    icon: '/icon.svg',
    badge: '/icon.svg',
    tag: tag,
    sound: '/alarm-digital.wav',
    requireInteraction: true,
    renotify: true,
    silent: false,
    vibrate: [1000, 250, 1000, 250, 1000, 250, 2000],
    data: {
      url: `/?tab=reminders&alarmId=${rem.id}&timeSlot=${timeSlot}&autoRing=1`,
      reminderId: rem.id,
      medicineName: rem.medicineName,
      timeSlot: timeSlot
    },
    actions: [
      { action: 'take', title: '💊 Mark Taken' },
      { action: 'snooze', title: '⏰ Snooze 10m' },
      { action: 'skip', title: '❌ Skip' }
    ]
  };

  self.registration.showNotification(title, options);

  // Escalating Re-Notification: If unacknowledged after 35 seconds, trigger secondary reminder
  setTimeout(async () => {
    try {
      const existing = await self.registration.getNotifications({ tag: tag });
      if (existing && existing.length > 0) {
        self.registration.showNotification(`🚨 Dose Alert: ${rem.medicineName}`, {
          ...options,
          tag: tag + '-urgent',
          body: `⚠️ Important: Please take your ${rem.medicineName} (${rem.dosage}) now!`,
          renotify: true
        });
      }
    } catch (e) {
      // ignore
    }
  }, 35000);
}

// Notification click listener to open app or record action directly
self.addEventListener('notificationclick', (event) => {
  event.notification.close();

  const action = event.action;
  const data = event.notification.data || {};
  const targetUrl = data.url || '/?tab=reminders';

  const isTake = action === 'take' || action === 'take_dose';
  const isSnooze = action === 'snooze' || action === 'snooze_10';
  const isSkip = action === 'skip';

  if (isTake || isSkip || isSnooze) {
    const statusMap = {
      take: 'taken_on_time',
      take_dose: 'taken_on_time',
      skip: 'skipped'
    };

    // If 'take' or 'skip', record the dose log directly in IndexedDB
    if (isTake || isSkip) {
      const newLog = {
        id: 'log-' + Date.now() + '-' + Math.random().toString(36).substring(2, 7),
        reminderId: data.reminderId,
        userPhone: '9876543210',
        medicineName: data.medicineName || 'Medicine',
        scheduledTimeSlot: data.timeSlot || '08:00',
        takenAt: Date.now(),
        date: new Date().toISOString().split('T')[0],
        status: statusMap[action] || 'taken_on_time'
      };
      event.waitUntil(addLogToIDB(newLog));
    } else if (isSnooze) {
      // Apply 10 minute snooze directly in memory and IDB
      const targetRem = cachedReminders.find((r) => r.id === data.reminderId);
      if (targetRem) {
        targetRem.snoozedUntil = Date.now() + 10 * 60 * 1000;
        event.waitUntil(saveRemindersToIDB(cachedReminders));
      }
    }

    // Register Background Sync if supported
    if (self.registration.sync) {
      self.registration.sync.register('sync-dose-logs').catch(() => {});
    }

    // Inform client windows or open window
    event.waitUntil(
      self.clients.matchAll({ type: 'window', includeUncontrolled: true }).then((clientList) => {
        for (const client of clientList) {
          if ('focus' in client) {
            client.postMessage({
              type: 'NOTIFICATION_ACTION',
              action,
              reminderId: data.reminderId,
              timeSlot: data.timeSlot
            });
            return client.focus();
          }
        }
        if (self.clients.openWindow) {
          return self.clients.openWindow(`${targetUrl}&userAction=${action}`);
        }
      })
    );
  } else {
    // Standard notification click -> focus or open app
    event.waitUntil(
      self.clients.matchAll({ type: 'window', includeUncontrolled: true }).then((clientList) => {
        for (const client of clientList) {
          if ('focus' in client) {
            return client.focus();
          }
        }
        if (self.clients.openWindow) {
          return self.clients.openWindow(targetUrl);
        }
      })
    );
  }
});
