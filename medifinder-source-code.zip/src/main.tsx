import React from 'react';
import ReactDOM from 'react-dom/client';
import App from './App';
import './index.css';
import { reminderStore } from './services/reminderStore';

// Register Service Worker for background medicine reminders, alarms & offline sync
if (typeof window !== 'undefined' && 'serviceWorker' in navigator) {
  window.addEventListener('load', () => {
    navigator.serviceWorker
      .register('/sw.js')
      .then((registration: any) => {
        console.log('MediFinder ServiceWorker registered:', registration.scope);

        // Register Background Sync if supported by browser
        if ('sync' in registration) {
          registration.sync.register('sync-reminders').catch(() => {});
          registration.sync.register('sync-dose-logs').catch(() => {});
        }

        // Register Periodic Background Sync if supported
        if ('periodicSync' in registration) {
          registration.periodicSync.register('check-reminders', {
            minInterval: 15 * 60 * 1000 // 15 minutes
          }).catch(() => {});
        }

        // Trigger initial synchronization of state
        reminderStore.syncServiceWorker('9876543210');
      })
      .catch((error) => {
        console.warn('ServiceWorker registration failed:', error);
      });
  });
}

ReactDOM.createRoot(document.getElementById('root') as HTMLElement).render(
  <React.StrictMode>
    <App />
  </React.StrictMode>
);
