import React, { useState, useEffect } from 'react';
import { 
  Home, 
  Search, 
  Sparkles, 
  Store, 
  Bell, 
  User, 
  Pill, 
  Moon, 
  Sun, 
  ShieldAlert, 
  Tv,
  LogOut,
  ChevronDown,
  Check
} from 'lucide-react';
import LandingView from './components/LandingView';
import HomeScreen from './components/HomeScreen';
import MedicineSearch from './components/MedicineSearch';
import AIMedicineAssistantChat from './components/AIMedicineAssistantChat';
import PharmacyConnector from './components/PharmacyConnector';
import MedicineReminderModule from './components/MedicineReminderModule';
import ProfileView from './components/ProfileView';
import AIVideoTour from './components/AIVideoTour';
import AdminPanel from './components/AdminPanel';
import PharmacyStreetNavigationModal from './components/PharmacyStreetNavigationModal';
import { UserProfile, Pharmacy } from './types';
import { authService } from './services/authService';
import { reminderStore } from './services/reminderStore';

export default function App() {
  const [currentUser, setCurrentUser] = useState<UserProfile | null>(() => {
    return authService.getStoredUser();
  });
  const [isCheckingAuth, setIsCheckingAuth] = useState(true);

  const [activeTab, setActiveTab] = useState<'home' | 'search' | 'ai' | 'connect' | 'reminders' | 'profile'>(() => {
    if (typeof window !== 'undefined') {
      const params = new URLSearchParams(window.location.search);
      const alarmId = params.get('alarmId');
      const autoRing = params.get('autoRing');
      const isTest = params.get('test');
      const hasAlarmAction = Boolean(alarmId || autoRing || isTest);

      const tabParam = params.get('tab');
      // Only open reminders on load if launched by an active alarm/notification trigger
      if (tabParam === 'reminders' && hasAlarmAction) {
        return 'reminders';
      }

      // If stale ?tab=reminders was left in the URL bar, clean it and default to home
      if (tabParam === 'reminders') {
        window.history.replaceState({}, document.title, window.location.pathname);
        return 'home';
      }

      if (tabParam && ['search', 'ai', 'connect', 'profile'].includes(tabParam)) {
        return tabParam as any;
      }

      if (window.location.search) {
        window.history.replaceState({}, document.title, window.location.pathname);
      }
    }
    return 'home';
  });
  const [reminderSubTab, setReminderSubTab] = useState<'schedule' | 'reminders' | 'add' | 'history'>('schedule');

  // Handle browser back/forward or notification deep-links
  useEffect(() => {
    if (typeof window === 'undefined') return;
    const handleUrlChange = () => {
      const params = new URLSearchParams(window.location.search);
      const tabParam = params.get('tab');
      if (tabParam && ['home', 'search', 'ai', 'connect', 'reminders', 'profile'].includes(tabParam)) {
        setActiveTab(tabParam as any);
      }
    };
    window.addEventListener('popstate', handleUrlChange);
    return () => window.removeEventListener('popstate', handleUrlChange);
  }, []);

  const [searchInitialQuery, setSearchInitialQuery] = useState('');
  const [aiInitialPrompt, setAiInitialPrompt] = useState('');
  const [activeRemindersCount, setActiveRemindersCount] = useState(0);

  const [darkMode, setDarkMode] = useState<boolean>(() => {
    if (typeof window !== 'undefined') {
      return localStorage.getItem('medifinder_theme') === 'dark';
    }
    return false;
  });

  const [showVideoTour, setShowVideoTour] = useState(false);
  const [showAdminPanel, setShowAdminPanel] = useState(false);
  const [isProfileMenuOpen, setIsProfileMenuOpen] = useState(false);
  const [navPharmacy, setNavPharmacy] = useState<Pharmacy | null>(null);

  // Validate session against Firebase / server on startup
  useEffect(() => {
    let mounted = true;
    const unsubscribe = authService.subscribeAuth((user) => {
      if (mounted) {
        if (user) {
          setCurrentUser(user);
        }
        setIsCheckingAuth(false);
      }
    });

    return () => {
      mounted = false;
      unsubscribe();
    };
  }, []);

  // Update active reminder badge count
  useEffect(() => {
    if (!currentUser?.phone) return;
    const updateCount = () => {
      const list = reminderStore.getReminders(currentUser.phone);
      setActiveRemindersCount(list.filter(r => r.active).length);
    };
    updateCount();
    const unsub = reminderStore.subscribe(updateCount);
    return unsub;
  }, [currentUser?.phone]);

  useEffect(() => {
    if (darkMode) {
      document.documentElement.classList.add('dark');
      localStorage.setItem('medifinder_theme', 'dark');
    } else {
      document.documentElement.classList.remove('dark');
      localStorage.setItem('medifinder_theme', 'light');
    }
  }, [darkMode]);

  // Handle URL parameters for background alarm navigation
  useEffect(() => {
    if (typeof window !== 'undefined') {
      const params = new URLSearchParams(window.location.search);
      const alarmId = params.get('alarmId');
      const autoRing = params.get('autoRing');
      const isTest = params.get('test');
      if (alarmId || autoRing || isTest) {
        setActiveTab('reminders');
      } else if (params.get('tab') === 'reminders') {
        // Clear stale reminders param from URL
        window.history.replaceState({}, document.title, window.location.pathname);
      }
    }
  }, []);

  const handleLogin = (user: UserProfile) => {
    setCurrentUser(user);
  };

  const handleLogout = async () => {
    setIsProfileMenuOpen(false);
    await authService.logout();
    setCurrentUser(null);
  };

  const handleNavigate = (
    tab: 'home' | 'search' | 'ai' | 'connect' | 'reminders' | 'profile',
    options?: { 
      reminderSubTab?: 'schedule' | 'reminders' | 'add' | 'history';
      searchQuery?: string;
      aiPrompt?: string;
    }
  ) => {
    setActiveTab(tab);
    if (options?.reminderSubTab) {
      setReminderSubTab(options.reminderSubTab);
    }
    if (options?.searchQuery !== undefined) {
      setSearchInitialQuery(options.searchQuery);
    }
    if (options?.aiPrompt !== undefined) {
      setAiInitialPrompt(options.aiPrompt);
    }

    // Keep URL clean so page refreshes always return to Home
    if (typeof window !== 'undefined' && window.location.search) {
      window.history.replaceState({}, document.title, window.location.pathname);
    }

    window.scrollTo({ top: 0, behavior: 'smooth' });
  };

  if (isCheckingAuth) {
    return (
      <div className="min-h-screen bg-slate-50 dark:bg-slate-950 flex flex-col items-center justify-center gap-3">
        <div className="w-10 h-10 border-3 border-[#0bbbb6] border-t-transparent rounded-full animate-spin" />
        <span className="text-xs font-bold text-slate-400">Verifying MediFinder security session...</span>
      </div>
    );
  }

  if (!currentUser) {
    return <LandingView onLogin={handleLogin} />;
  }

  return (
    <div className="min-h-screen bg-slate-50 dark:bg-slate-950 text-slate-800 dark:text-slate-100 flex flex-col font-sans transition-colors duration-200">
      
      {/* TOP APPLICATION BAR */}
      <header className="sticky top-0 z-40 bg-white/90 dark:bg-slate-900/90 backdrop-blur-md border-b border-slate-200/80 dark:border-slate-800 px-4 sm:px-8 py-3 flex items-center justify-between shadow-2xs">
        
        {/* Brand Logo */}
        <div 
          onClick={() => handleNavigate('home')}
          className="flex items-center gap-2.5 cursor-pointer group shrink-0"
        >
          <div className="w-9 h-9 rounded-2xl bg-[#e6f8f7] dark:bg-teal-950/60 text-[#0bbbb6] border border-[#0bbbb6]/30 flex items-center justify-center font-bold shadow-2xs transition group-hover:scale-105">
            <Pill className="w-5 h-5" />
          </div>
          <div>
            <h1 className="text-base font-extrabold text-slate-900 dark:text-white leading-none tracking-tight">
              MediFinder
            </h1>
            <span className="text-[10px] font-bold text-[#0bbbb6] uppercase tracking-wider">
              Health & Reminders
            </span>
          </div>
        </div>

        {/* DESKTOP PRIMARY NAVIGATION BAR (MD & LG SCREENS) */}
        <nav className="hidden md:flex items-center gap-1 bg-slate-100/80 dark:bg-slate-800/80 p-1.5 rounded-2xl border border-slate-200/60 dark:border-slate-700/60">
          <button
            onClick={() => handleNavigate('home')}
            className={`px-3.5 py-1.5 rounded-xl text-xs font-bold transition flex items-center gap-1.5 cursor-pointer ${
              activeTab === 'home'
                ? 'bg-[#0bbbb6] text-white shadow-xs'
                : 'text-slate-600 dark:text-slate-300 hover:text-slate-900 dark:hover:text-white hover:bg-white dark:hover:bg-slate-700'
            }`}
          >
            <Home className="w-3.5 h-3.5" />
            <span>Home</span>
          </button>

          <button
            onClick={() => handleNavigate('search')}
            className={`px-3.5 py-1.5 rounded-xl text-xs font-bold transition flex items-center gap-1.5 cursor-pointer ${
              activeTab === 'search'
                ? 'bg-[#0bbbb6] text-white shadow-xs'
                : 'text-slate-600 dark:text-slate-300 hover:text-slate-900 dark:hover:text-white hover:bg-white dark:hover:bg-slate-700'
            }`}
          >
            <Search className="w-3.5 h-3.5" />
            <span>Search</span>
          </button>

          <button
            onClick={() => handleNavigate('reminders')}
            className={`relative px-3.5 py-1.5 rounded-xl text-xs font-bold transition flex items-center gap-1.5 cursor-pointer ${
              activeTab === 'reminders'
                ? 'bg-[#0bbbb6] text-white shadow-xs'
                : 'text-slate-600 dark:text-slate-300 hover:text-slate-900 dark:hover:text-white hover:bg-white dark:hover:bg-slate-700'
            }`}
          >
            <Bell className="w-3.5 h-3.5" />
            <span>Reminders</span>
            {activeRemindersCount > 0 && (
              <span className={`px-1.5 py-0.2 rounded-full text-[9px] font-black ${
                activeTab === 'reminders'
                  ? 'bg-white text-[#0bbbb6]'
                  : 'bg-[#0bbbb6] text-white'
              }`}>
                {activeRemindersCount}
              </span>
            )}
          </button>

          <button
            onClick={() => handleNavigate('ai')}
            className={`px-3.5 py-1.5 rounded-xl text-xs font-bold transition flex items-center gap-1.5 cursor-pointer ${
              activeTab === 'ai'
                ? 'bg-purple-600 text-white shadow-xs'
                : 'text-slate-600 dark:text-slate-300 hover:text-purple-600 dark:hover:text-purple-400 hover:bg-white dark:hover:bg-slate-700'
            }`}
          >
            <Sparkles className="w-3.5 h-3.5" />
            <span>AI Assistant</span>
          </button>

          <button
            onClick={() => handleNavigate('connect')}
            className={`px-3.5 py-1.5 rounded-xl text-xs font-bold transition flex items-center gap-1.5 cursor-pointer ${
              activeTab === 'connect'
                ? 'bg-emerald-600 text-white shadow-xs'
                : 'text-slate-600 dark:text-slate-300 hover:text-emerald-600 dark:hover:text-emerald-400 hover:bg-white dark:hover:bg-slate-700'
            }`}
          >
            <Store className="w-3.5 h-3.5" />
            <span>Pharmacies</span>
          </button>
        </nav>

        {/* RIGHT CONTROLS: TOUR, THEME, USER PROFILE DROPDOWN */}
        <div className="flex items-center gap-2">
          {/* AI Presentation Tour Button */}
          <button
            onClick={() => setShowVideoTour(true)}
            className="p-2 text-slate-600 dark:text-slate-300 hover:text-[#0bbbb6] hover:bg-slate-100 dark:hover:bg-slate-800 rounded-xl transition cursor-pointer flex items-center gap-1.5 text-xs font-bold"
            title="AI Video Presentation Tour"
          >
            <Tv className="w-4 h-4 text-[#0bbbb6]" />
            <span className="hidden sm:inline">Tour</span>
          </button>

          {/* Dark Mode Toggle */}
          <button
            onClick={() => setDarkMode(!darkMode)}
            className="p-2 text-slate-600 dark:text-slate-300 hover:bg-slate-100 dark:hover:bg-slate-800 rounded-xl transition cursor-pointer"
            title="Toggle theme mode"
          >
            {darkMode ? <Sun className="w-4 h-4 text-amber-400" /> : <Moon className="w-4 h-4 text-indigo-600" />}
          </button>

          {/* User Profile avatar & dropdown trigger */}
          <div className="relative">
            <button
              onClick={() => setIsProfileMenuOpen(!isProfileMenuOpen)}
              className="flex items-center gap-2 p-1 pl-1.5 pr-2 rounded-2xl hover:bg-slate-100 dark:hover:bg-slate-800 border border-transparent hover:border-slate-200 dark:hover:border-slate-700 transition cursor-pointer"
              title={`${currentUser.name} (${currentUser.email || currentUser.phone})`}
            >
              <div className="w-8 h-8 rounded-full overflow-hidden border border-[#0bbbb6]/40 flex items-center justify-center bg-[#0bbbb6]/15 text-[#0bbbb6] dark:bg-teal-500/20 dark:text-teal-300 font-bold text-xs shadow-2xs">
                {currentUser.avatar ? (
                  <img src={currentUser.avatar} alt={currentUser.name} className="w-full h-full object-cover" />
                ) : (
                  currentUser.name.charAt(0).toUpperCase()
                )}
              </div>
              <span className="hidden lg:inline text-xs font-bold text-slate-700 dark:text-slate-200 max-w-[90px] truncate">
                {currentUser.name.split(' ')[0]}
              </span>
              <ChevronDown className="w-3.5 h-3.5 text-slate-400" />
            </button>

            {/* FLOATING USER PROFILE MENU */}
            {isProfileMenuOpen && (
              <>
                <div 
                  className="fixed inset-0 z-40 cursor-default" 
                  onClick={() => setIsProfileMenuOpen(false)} 
                />
                <div className="absolute right-0 mt-2 w-64 bg-white dark:bg-slate-900 border border-slate-200/80 dark:border-slate-800 rounded-3xl shadow-xl z-50 p-2 text-slate-700 dark:text-slate-200 animate-fade-in">
                  <div className="p-3 border-b border-slate-100 dark:border-slate-800">
                    <div className="flex items-center gap-2.5">
                      <div className="w-10 h-10 rounded-full overflow-hidden border border-[#0bbbb6]/40 flex items-center justify-center bg-[#0bbbb6]/15 text-[#0bbbb6] dark:bg-teal-500/20 dark:text-teal-300 font-bold text-sm shrink-0">
                        {currentUser.avatar ? (
                          <img src={currentUser.avatar} alt={currentUser.name} className="w-full h-full object-cover" />
                        ) : (
                          currentUser.name.charAt(0).toUpperCase()
                        )}
                      </div>
                      <div className="overflow-hidden">
                        <div className="text-xs font-bold text-slate-900 dark:text-white truncate">
                          {currentUser.name}
                        </div>
                        <div className="text-[11px] text-slate-400 truncate">
                          {currentUser.email || currentUser.phone}
                        </div>
                      </div>
                    </div>
                  </div>

                  <div className="p-1 space-y-0.5">
                    <button
                      onClick={() => {
                        handleNavigate('profile');
                        setIsProfileMenuOpen(false);
                      }}
                      className="w-full flex items-center gap-2.5 px-3 py-2 text-xs font-semibold rounded-xl hover:bg-slate-100 dark:hover:bg-slate-800 text-slate-700 dark:text-slate-200 transition cursor-pointer"
                    >
                      <User className="w-4 h-4 text-[#0bbbb6]" />
                      <span>My Health Profile</span>
                    </button>

                    <button
                      onClick={() => {
                        setShowVideoTour(true);
                        setIsProfileMenuOpen(false);
                      }}
                      className="w-full flex items-center gap-2.5 px-3 py-2 text-xs font-semibold rounded-xl hover:bg-slate-100 dark:hover:bg-slate-800 text-slate-700 dark:text-slate-200 transition cursor-pointer"
                    >
                      <Tv className="w-4 h-4 text-purple-500" />
                      <span>Product Tour</span>
                    </button>

                    <button
                      onClick={() => setDarkMode(!darkMode)}
                      className="w-full flex items-center justify-between px-3 py-2 text-xs font-semibold rounded-xl hover:bg-slate-100 dark:hover:bg-slate-800 text-slate-700 dark:text-slate-200 transition cursor-pointer"
                    >
                      <div className="flex items-center gap-2.5">
                        {darkMode ? <Sun className="w-4 h-4 text-amber-400" /> : <Moon className="w-4 h-4 text-indigo-500" />}
                        <span>Dark Theme</span>
                      </div>
                      <span className="text-[10px] text-slate-400 font-bold">{darkMode ? 'ON' : 'OFF'}</span>
                    </button>

                    <button
                      onClick={() => {
                        setShowAdminPanel(true);
                        setIsProfileMenuOpen(false);
                      }}
                      className="w-full flex items-center gap-2.5 px-3 py-2 text-xs font-semibold rounded-xl hover:bg-slate-100 dark:hover:bg-slate-800 text-slate-700 dark:text-slate-200 transition cursor-pointer"
                    >
                      <ShieldAlert className="w-4 h-4 text-teal-600" />
                      <span>Admin Settings</span>
                    </button>
                  </div>

                  <div className="p-1 pt-1.5 border-t border-slate-100 dark:border-slate-800">
                    <button
                      onClick={handleLogout}
                      className="w-full flex items-center gap-2.5 px-3 py-2 text-xs font-bold text-rose-600 hover:bg-rose-50 dark:hover:bg-rose-950/40 rounded-xl transition cursor-pointer"
                    >
                      <LogOut className="w-4 h-4" />
                      <span>Sign Out</span>
                    </button>
                  </div>
                </div>
              </>
            )}
          </div>
        </div>
      </header>

      {/* MAIN VIEW CONTENT CONTAINER */}
      <main className="flex-grow max-w-7xl mx-auto w-full px-4 sm:px-6 lg:px-8 py-6 pb-24 md:pb-12 animate-fade-in">
        {activeTab === 'home' && (
          <HomeScreen
            currentUser={currentUser}
            onNavigate={handleNavigate}
            onSelectPharmacyForNav={ph => setNavPharmacy(ph)}
            darkMode={darkMode}
          />
        )}

        {activeTab === 'search' && (
          <MedicineSearch
            initialQuery={searchInitialQuery}
            onSelectPharmacyForNav={ph => setNavPharmacy(ph)}
            onNavigateToConnect={() => setActiveTab('connect')}
          />
        )}

        {activeTab === 'ai' && (
          <AIMedicineAssistantChat 
            isEmbedded 
            initialPrompt={aiInitialPrompt}
          />
        )}

        {activeTab === 'connect' && (
          <PharmacyConnector
            onPharmacyAdded={() => setActiveTab('search')}
          />
        )}

        {activeTab === 'reminders' && (
          <MedicineReminderModule
            currentUser={currentUser}
            initialSubTab={reminderSubTab}
          />
        )}

        {activeTab === 'profile' && (
          <ProfileView
            currentUser={currentUser}
            darkMode={darkMode}
            setDarkMode={setDarkMode}
            onShowVideoTour={() => setShowVideoTour(true)}
            onShowAdminPrompt={() => setShowAdminPanel(true)}
            onLogout={handleLogout}
          />
        )}
      </main>

      {/* RESPONSIVE BOTTOM NAVIGATION BAR (ONLY ON MOBILE & TABLET: md:hidden) */}
      <nav className="md:hidden fixed bottom-0 left-0 right-0 z-40 bg-white/95 dark:bg-slate-900/95 backdrop-blur-md border-t border-slate-200/80 dark:border-slate-800 px-2 py-1.5 flex items-center justify-around shadow-lg">
        <button
          onClick={() => handleNavigate('home')}
          className={`flex flex-col items-center gap-0.5 px-3 py-1 rounded-2xl transition cursor-pointer ${
            activeTab === 'home'
              ? 'text-[#0bbbb6] font-extrabold'
              : 'text-slate-500 dark:text-slate-400 hover:text-slate-900'
          }`}
        >
          <Home className="w-5 h-5" />
          <span className="text-[10px]">Home</span>
        </button>

        <button
          onClick={() => handleNavigate('search')}
          className={`flex flex-col items-center gap-0.5 px-3 py-1 rounded-2xl transition cursor-pointer ${
            activeTab === 'search'
              ? 'text-[#0bbbb6] font-extrabold'
              : 'text-slate-500 dark:text-slate-400 hover:text-slate-900'
          }`}
        >
          <Search className="w-5 h-5" />
          <span className="text-[10px]">Search</span>
        </button>

        <button
          onClick={() => handleNavigate('reminders')}
          className={`relative flex flex-col items-center gap-0.5 px-3 py-1 rounded-2xl transition cursor-pointer ${
            activeTab === 'reminders'
              ? 'text-[#0bbbb6] font-extrabold'
              : 'text-slate-500 dark:text-slate-400 hover:text-slate-900'
          }`}
        >
          <Bell className="w-5 h-5" />
          <span className="text-[10px]">Reminders</span>
          {activeRemindersCount > 0 && (
            <span className="absolute -top-0.5 right-2 w-2 h-2 rounded-full bg-[#0bbbb6]" />
          )}
        </button>

        <button
          onClick={() => handleNavigate('ai')}
          className={`flex flex-col items-center gap-0.5 px-3 py-1 rounded-2xl transition cursor-pointer ${
            activeTab === 'ai'
              ? 'text-purple-600 font-extrabold'
              : 'text-slate-500 dark:text-slate-400 hover:text-slate-900'
          }`}
        >
          <Sparkles className="w-5 h-5" />
          <span className="text-[10px]">AI Chat</span>
        </button>

        <button
          onClick={() => handleNavigate('connect')}
          className={`flex flex-col items-center gap-0.5 px-3 py-1 rounded-2xl transition cursor-pointer ${
            activeTab === 'connect'
              ? 'text-emerald-600 font-extrabold'
              : 'text-slate-500 dark:text-slate-400 hover:text-slate-900'
          }`}
        >
          <Store className="w-5 h-5" />
          <span className="text-[10px]">Stores</span>
        </button>

        <button
          onClick={() => handleNavigate('profile')}
          className={`flex flex-col items-center gap-0.5 px-3 py-1 rounded-2xl transition cursor-pointer ${
            activeTab === 'profile'
              ? 'text-[#0bbbb6] font-extrabold'
              : 'text-slate-500 dark:text-slate-400 hover:text-slate-900'
          }`}
        >
          <User className="w-5 h-5" />
          <span className="text-[10px]">Profile</span>
        </button>
      </nav>

      {/* MODALS & OVERLAYS */}
      {showVideoTour && <AIVideoTour onClose={() => setShowVideoTour(false)} />}
      {showAdminPanel && <AdminPanel onClose={() => setShowAdminPanel(false)} />}
      {navPharmacy && (
        <PharmacyStreetNavigationModal
          pharmacy={navPharmacy}
          onClose={() => setNavPharmacy(null)}
        />
      )}

    </div>
  );
}
