import React, { useState, useEffect } from 'react';
import { 
  Store, 
  MapPin, 
  Phone, 
  Clock, 
  CheckCircle2, 
  Building2, 
  User, 
  Mail, 
  Upload, 
  FileSpreadsheet, 
  AlertTriangle, 
  Check, 
  Trash2, 
  Plus, 
  FileText, 
  Download, 
  RefreshCw, 
  ChevronRight, 
  ChevronLeft, 
  Edit3, 
  LocateFixed, 
  Eye,
  Pill,
  Search
} from 'lucide-react';
import * as XLSX from 'xlsx';
import { PharmacyStore } from '../services/store';
import { Pharmacy } from '../types';

interface PharmacyConnectorProps {
  onPharmacyAdded: () => void;
}

interface MedicineInput {
  name: string;
  genericName: string;
  dosage: string;
  price: number;
  stockStatus: 'In Stock' | 'Low Stock' | 'Out of Stock';
  quantity: number;
}

const SAMPLE_TEMPLATE_DATA = [
  { "Medicine Name": "Dolo 650", "Generic Name": "Paracetamol", "Dosage": "650mg", "Price": 30, "Stock Status": "In Stock", "Quantity": 150 },
  { "Medicine Name": "Amoxicillin 500mg", "Generic Name": "Amoxicillin", "Dosage": "500mg", "Price": 75, "Stock Status": "In Stock", "Quantity": 80 },
  { "Medicine Name": "Amlodipine 5mg", "Generic Name": "Amlodipine Besylate", "Dosage": "5mg", "Price": 38, "Stock Status": "In Stock", "Quantity": 60 },
  { "Medicine Name": "Pantoprazole 40mg", "Generic Name": "Pantoprazole Sodium", "Dosage": "40mg", "Price": 55, "Stock Status": "In Stock", "Quantity": 100 },
  { "Medicine Name": "Azithromycin 500mg", "Generic Name": "Azithromycin", "Dosage": "500mg", "Price": 120, "Stock Status": "Low Stock", "Quantity": 15 },
  { "Medicine Name": "Cetirizine 10mg", "Generic Name": "Cetirizine HCl", "Dosage": "10mg", "Price": 20, "Stock Status": "In Stock", "Quantity": 200 }
];

export default function PharmacyConnector({ onPharmacyAdded }: PharmacyConnectorProps) {
  // Active Wizard Step: 1 | 2 | 3
  const [currentStep, setCurrentStep] = useState<number>(1);
  const [editingPharmacyId, setEditingPharmacyId] = useState<string | null>(null);

  // Step 1: Pharmacy Details
  const [name, setName] = useState('');
  const [ownerName, setOwnerName] = useState('');
  const [phone, setPhone] = useState('');
  const [email, setEmail] = useState('');
  const [address, setAddress] = useState('');
  const [city, setCity] = useState('Hyderabad');
  const [openHours, setOpenHours] = useState('8:00 AM - 10:00 PM');
  const [lat, setLat] = useState<number>(17.4325);
  const [lng, setLng] = useState<number>(78.4071);
  const [isDetectingGps, setIsDetectingGps] = useState(false);
  const [gpsSuccessMessage, setGpsSuccessMessage] = useState('');

  // Step 2: Medicine Inventory Upload
  const [importedMedicines, setImportedMedicines] = useState<MedicineInput[]>([]);
  const [fileName, setFileName] = useState<string>('');
  const [uploadError, setUploadError] = useState<string>('');
  const [validationDuplicates, setValidationDuplicates] = useState<string[]>([]);
  const [invalidEntriesCount, setInvalidEntriesCount] = useState<number>(0);
  const [inventorySearchQuery, setInventorySearchQuery] = useState('');

  // Manual Add Medicine Modal/Inline State
  const [newMedName, setNewMedName] = useState('');
  const [newMedGeneric, setNewMedGeneric] = useState('');
  const [newMedDosage, setNewMedDosage] = useState('');
  const [newMedPrice, setNewMedPrice] = useState<string>('50');
  const [newMedQty, setNewMedQty] = useState<string>('50');

  // Registration Status
  const [isPublishing, setIsPublishing] = useState(false);
  const [isSuccess, setIsSuccess] = useState(false);

  // Registered Pharmacies list for inventory update
  const [registeredPharmacies, setRegisteredPharmacies] = useState<Pharmacy[]>([]);

  useEffect(() => {
    setRegisteredPharmacies(PharmacyStore.getPharmacies());
  }, []);

  // GPS Auto Detection
  const handleAutoDetectLocation = () => {
    if (!navigator.geolocation) {
      alert("Geolocation is not supported by your browser.");
      return;
    }
    setIsDetectingGps(true);
    setGpsSuccessMessage('');

    navigator.geolocation.getCurrentPosition(
      (pos) => {
        setLat(Number(pos.coords.latitude.toFixed(6)));
        setLng(Number(pos.coords.longitude.toFixed(6)));
        setIsDetectingGps(false);
        setGpsSuccessMessage(`GPS location captured (${pos.coords.latitude.toFixed(4)}, ${pos.coords.longitude.toFixed(4)})`);
      },
      (err) => {
        setIsDetectingGps(false);
        alert(`Location detection failed: ${err.message}. Defaulting to current map pins.`);
      },
      { timeout: 10000, enableHighAccuracy: true }
    );
  };

  // Step 1 Validation
  const handleStep1Next = (e: React.FormEvent) => {
    e.preventDefault();
    if (!name.trim() || !ownerName.trim() || !phone.trim() || !address.trim()) {
      alert("Please fill in all required fields (Pharmacy Name, Owner Name, Phone, Address).");
      return;
    }
    setCurrentStep(2);
  };

  // Step 2 File Parser (.csv & .xlsx via SheetJS)
  const handleFileUpload = (e: React.ChangeEvent<HTMLInputElement>) => {
    const file = e.target.files?.[0];
    if (!file) return;

    setFileName(file.name);
    setUploadError('');

    const reader = new FileReader();
    reader.onload = (evt) => {
      try {
        const buffer = evt.target?.result as ArrayBuffer;
        const workbook = XLSX.read(buffer, { type: 'array' });
        const sheetName = workbook.SheetNames[0];
        const sheet = workbook.Sheets[sheetName];
        const rawJson: any[] = XLSX.utils.sheet_to_json(sheet, { defval: '' });

        if (!rawJson || rawJson.length === 0) {
          setUploadError("The uploaded file is empty or formatted incorrectly.");
          return;
        }

        const parsedMeds: MedicineInput[] = [];
        const duplicatesMap = new Map<string, number>();
        let invalidCount = 0;

        rawJson.forEach((row) => {
          // Normalize key lookups
          const keys = Object.keys(row);
          const getKey = (possibleNames: string[]) => {
            const foundKey = keys.find(k => 
              possibleNames.some(p => k.toLowerCase().trim().includes(p.toLowerCase()))
            );
            return foundKey ? row[foundKey] : '';
          };

          const medName = String(getKey(['medicine name', 'medicinename', 'name', 'medicine', 'item'])).trim();
          const genericName = String(getKey(['generic name', 'genericname', 'generic', 'salt', 'composition'])).trim() || 'General Compound';
          const dosage = String(getKey(['dosage', 'strength', 'dose'])).trim() || 'Standard';
          const rawPrice = parseFloat(String(getKey(['price', 'mrp', 'cost', 'rate'])).replace(/[^0-9.]/g, '')) || 50;
          const rawQty = parseInt(String(getKey(['quantity', 'qty', 'stock', 'units'])).replace(/[^0-9]/g, ''), 10) || 50;
          
          let stockStatus: 'In Stock' | 'Low Stock' | 'Out of Stock' = 'In Stock';
          const rawStatus = String(getKey(['stock status', 'status', 'stockstatus'])).toLowerCase().trim();
          if (rawStatus.includes('out') || rawQty === 0) {
            stockStatus = 'Out of Stock';
          } else if (rawStatus.includes('low') || rawQty < 20) {
            stockStatus = 'Low Stock';
          }

          if (!medName) {
            invalidCount++;
            return;
          }

          // Track duplicate medicine names
          const normKey = medName.toLowerCase();
          duplicatesMap.set(normKey, (duplicatesMap.get(normKey) || 0) + 1);

          parsedMeds.push({
            name: medName,
            genericName,
            dosage,
            price: rawPrice,
            stockStatus,
            quantity: rawQty
          });
        });

        const duplicatesList = Array.from(duplicatesMap.entries())
          .filter(([_, count]) => count > 1)
          .map(([key, _]) => key);

        setImportedMedicines(parsedMeds);
        setValidationDuplicates(duplicatesList);
        setInvalidEntriesCount(invalidCount);

      } catch (err: any) {
        setUploadError(`Failed to parse file: ${err.message || 'Invalid format'}. Please upload a valid .csv or .xlsx file.`);
      }
    };

    reader.readAsArrayBuffer(file);
  };

  // Download CSV Sample Template
  const handleDownloadSampleTemplate = () => {
    const ws = XLSX.utils.json_to_sheet(SAMPLE_TEMPLATE_DATA);
    const wb = XLSX.utils.book_new();
    XLSX.utils.book_append_sheet(wb, ws, "InventoryTemplate");
    XLSX.writeFile(wb, "medifinder_pharmacy_inventory_template.xlsx");
  };

  // Load Demo Inventory
  const handleLoadDemoInventory = () => {
    setFileName("sample_medifinder_inventory.xlsx");
    setUploadError('');
    setValidationDuplicates([]);
    setInvalidEntriesCount(0);
    setImportedMedicines([
      { name: 'Dolo 650', genericName: 'Paracetamol / Acetaminophen', dosage: '650mg', price: 30, stockStatus: 'In Stock', quantity: 180 },
      { name: 'Paracetamol 500mg', genericName: 'Acetaminophen', dosage: '500mg', price: 25, stockStatus: 'In Stock', quantity: 150 },
      { name: 'Amoxicillin 500mg', genericName: 'Amoxicillin Trihydrate', dosage: '500mg', price: 75, stockStatus: 'In Stock', quantity: 80 },
      { name: 'Amlodipine 5mg', genericName: 'Amlodipine Besylate', dosage: '5mg', price: 38, stockStatus: 'In Stock', quantity: 60 },
      { name: 'Pantoprazole 40mg', genericName: 'Pantoprazole Sodium', dosage: '40mg', price: 55, stockStatus: 'In Stock', quantity: 95 },
      { name: 'Metformin 500mg', genericName: 'Metformin HCl', dosage: '500mg', price: 30, stockStatus: 'In Stock', quantity: 110 },
      { name: 'Azithromycin 500mg', genericName: 'Azithromycin', dosage: '500mg', price: 115, stockStatus: 'Low Stock', quantity: 12 },
      { name: 'Cetirizine 10mg', genericName: 'Cetirizine HCl', dosage: '10mg', price: 20, stockStatus: 'In Stock', quantity: 140 }
    ]);
  };

  // Deduplicate Medicines
  const handleDeduplicate = () => {
    const uniqueMap = new Map<string, MedicineInput>();
    importedMedicines.forEach(med => {
      const key = med.name.toLowerCase();
      if (!uniqueMap.has(key)) {
        uniqueMap.set(key, med);
      }
    });
    setImportedMedicines(Array.from(uniqueMap.values()));
    setValidationDuplicates([]);
  };

  // Add Single Medicine Manually
  const handleAddManualMedicine = (e: React.FormEvent) => {
    e.preventDefault();
    if (!newMedName.trim()) return;

    const qtyVal = parseInt(newMedQty, 10) || 50;
    let status: 'In Stock' | 'Low Stock' | 'Out of Stock' = 'In Stock';
    if (qtyVal === 0) status = 'Out of Stock';
    else if (qtyVal < 20) status = 'Low Stock';

    const newMed: MedicineInput = {
      name: newMedName.trim(),
      genericName: newMedGeneric.trim() || 'General Compound',
      dosage: newMedDosage.trim() || 'Standard',
      price: parseFloat(newMedPrice) || 50,
      stockStatus: status,
      quantity: qtyVal
    };

    setImportedMedicines(prev => [newMed, ...prev]);
    setNewMedName('');
    setNewMedGeneric('');
    setNewMedDosage('');
  };

  // Remove medicine item
  const handleRemoveMedicine = (index: number) => {
    setImportedMedicines(prev => prev.filter((_, idx) => idx !== index));
  };

  // Final Registration & Publish (Step 3 Submit)
  const handlePublishPharmacy = () => {
    if (importedMedicines.length === 0) {
      alert("Please upload or add at least 1 medicine item to your inventory before registering.");
      return;
    }

    setIsPublishing(true);

    const savedPharmacy = PharmacyStore.upsertPharmacy({
      id: editingPharmacyId || undefined,
      name,
      ownerName,
      email,
      address,
      city,
      phone,
      distanceKm: 0.8,
      lat,
      lng,
      openHours,
      isOpen: true,
      medicines: importedMedicines
    });

    setTimeout(() => {
      setIsPublishing(false);
      setIsSuccess(true);
      setRegisteredPharmacies(PharmacyStore.getPharmacies());
    }, 1000);
  };

  // Edit existing pharmacy inventory
  const handleLoadExistingPharmacyForEdit = (ph: Pharmacy) => {
    setEditingPharmacyId(ph.id);
    setName(ph.name);
    setOwnerName(ph.ownerName || '');
    setPhone(ph.phone);
    setEmail(ph.email || '');
    setAddress(ph.address);
    setCity(ph.city);
    setOpenHours(ph.openHours);
    setLat(ph.lat);
    setLng(ph.lng);
    setImportedMedicines(ph.medicines);
    setFileName(`existing_inventory_${ph.name.toLowerCase().replace(/\s+/g, '_')}.xlsx`);
    setCurrentStep(1);
    setIsSuccess(false);
  };

  const handleResetForm = () => {
    setEditingPharmacyId(null);
    setName('');
    setOwnerName('');
    setPhone('');
    setEmail('');
    setAddress('');
    setCity('Hyderabad');
    setOpenHours('8:00 AM - 10:00 PM');
    setImportedMedicines([]);
    setFileName('');
    setCurrentStep(1);
    setIsSuccess(false);
  };

  // Filtered inventory list for preview
  const filteredPreviewMedicines = importedMedicines.filter(m => 
    m.name.toLowerCase().includes(inventorySearchQuery.toLowerCase()) ||
    m.genericName.toLowerCase().includes(inventorySearchQuery.toLowerCase())
  );

  return (
    <div className="max-w-4xl mx-auto space-y-6 pb-20 animate-fade-in">
      {/* PAGE TITLE BANNER */}
      <div className="bg-white dark:bg-slate-900 border border-slate-200/80 dark:border-slate-800 rounded-3xl p-6 shadow-xs flex flex-col sm:flex-row items-start sm:items-center justify-between gap-4">
        <div className="flex items-center gap-3">
          <div className="w-12 h-12 rounded-2xl bg-[#0bbbb6]/10 text-[#0bbbb6] flex items-center justify-center font-bold shrink-0">
            <Store className="w-6 h-6" />
          </div>
          <div>
            <h1 className="text-xl sm:text-2xl font-extrabold text-slate-900 dark:text-white flex items-center gap-2">
              <span>Pharmacy Registration Portal</span>
            </h1>
            <p className="text-xs text-slate-500 dark:text-slate-400 font-medium">
              3-Step automated setup to register pharmacy and publish inventory
            </p>
          </div>
        </div>

        {editingPharmacyId && (
          <span className="px-3 py-1.5 rounded-2xl bg-amber-100 dark:bg-amber-950/60 text-amber-800 dark:text-amber-300 text-xs font-bold border border-amber-300/40">
            ✏️ Updating Existing Inventory
          </span>
        )}
      </div>

      {/* 3-STEP PROGRESS STEPPER */}
      <div className="bg-white dark:bg-slate-900 border border-slate-200/80 dark:border-slate-800 rounded-3xl p-4 sm:p-5 shadow-xs">
        <div className="grid grid-cols-3 gap-2">
          {/* Step 1 Tab */}
          <button
            onClick={() => setCurrentStep(1)}
            className={`p-3 rounded-2xl border text-left transition flex items-center gap-2.5 cursor-pointer ${
              currentStep === 1
                ? 'bg-[#0bbbb6] text-white border-[#0bbbb6] shadow-2xs'
                : currentStep > 1
                ? 'bg-teal-50 dark:bg-teal-950/40 text-teal-800 dark:text-teal-300 border-teal-200 dark:border-teal-800'
                : 'bg-slate-50 dark:bg-slate-800/60 text-slate-500 dark:text-slate-400 border-slate-200 dark:border-slate-700'
            }`}
          >
            <div className={`w-7 h-7 rounded-xl flex items-center justify-center text-xs font-black shrink-0 ${
              currentStep === 1 ? 'bg-white text-[#0bbbb6]' : 'bg-slate-200 dark:bg-slate-700'
            }`}>
              1
            </div>
            <div className="hidden sm:block">
              <div className="text-xs font-black">Step 1</div>
              <div className="text-[10px] opacity-80 font-medium">Pharmacy Details</div>
            </div>
          </button>

          {/* Step 2 Tab */}
          <button
            onClick={() => {
              if (!name.trim() || !phone.trim()) {
                alert("Please complete Step 1 details first.");
                return;
              }
              setCurrentStep(2);
            }}
            className={`p-3 rounded-2xl border text-left transition flex items-center gap-2.5 cursor-pointer ${
              currentStep === 2
                ? 'bg-[#0bbbb6] text-white border-[#0bbbb6] shadow-2xs'
                : currentStep > 2
                ? 'bg-teal-50 dark:bg-teal-950/40 text-teal-800 dark:text-teal-300 border-teal-200 dark:border-teal-800'
                : 'bg-slate-50 dark:bg-slate-800/60 text-slate-500 dark:text-slate-400 border-slate-200 dark:border-slate-700'
            }`}
          >
            <div className={`w-7 h-7 rounded-xl flex items-center justify-center text-xs font-black shrink-0 ${
              currentStep === 2 ? 'bg-white text-[#0bbbb6]' : 'bg-slate-200 dark:bg-slate-700'
            }`}>
              2
            </div>
            <div className="hidden sm:block">
              <div className="text-xs font-black">Step 2</div>
              <div className="text-[10px] opacity-80 font-medium">Upload Inventory</div>
            </div>
          </button>

          {/* Step 3 Tab */}
          <button
            onClick={() => {
              if (importedMedicines.length === 0) {
                alert("Please upload or add medicine inventory in Step 2 first.");
                return;
              }
              setCurrentStep(3);
            }}
            className={`p-3 rounded-2xl border text-left transition flex items-center gap-2.5 cursor-pointer ${
              currentStep === 3
                ? 'bg-[#0bbbb6] text-white border-[#0bbbb6] shadow-2xs'
                : 'bg-slate-50 dark:bg-slate-800/60 text-slate-500 dark:text-slate-400 border-slate-200 dark:border-slate-700'
            }`}
          >
            <div className={`w-7 h-7 rounded-xl flex items-center justify-center text-xs font-black shrink-0 ${
              currentStep === 3 ? 'bg-white text-[#0bbbb6]' : 'bg-slate-200 dark:bg-slate-700'
            }`}>
              3
            </div>
            <div className="hidden sm:block">
              <div className="text-xs font-black">Step 3</div>
              <div className="text-[10px] opacity-80 font-medium">Review & Publish</div>
            </div>
          </button>
        </div>
      </div>

      {/* SUCCESS SCREEN */}
      {isSuccess ? (
        <div className="bg-white dark:bg-slate-900 border border-emerald-200 dark:border-emerald-800/80 rounded-3xl p-8 text-center space-y-4 shadow-md animate-fade-in">
          <div className="w-16 h-16 bg-emerald-100 dark:bg-emerald-950 text-emerald-600 rounded-3xl flex items-center justify-center mx-auto shadow-xs">
            <CheckCircle2 className="w-10 h-10 animate-bounce" />
          </div>
          <div className="space-y-1">
            <h2 className="text-xl sm:text-2xl font-extrabold text-slate-900 dark:text-white">
              Pharmacy Successfully Published!
            </h2>
            <p className="text-xs sm:text-sm text-slate-500 dark:text-slate-400 font-medium max-w-md mx-auto">
              <strong>{name}</strong> is now live. All {importedMedicines.length} imported medicines are immediately searchable by nearby users on MediFinder!
            </p>
          </div>

          <div className="pt-4 flex flex-wrap items-center justify-center gap-3">
            <button
              onClick={onPharmacyAdded}
              className="px-6 py-3 bg-[#0bbbb6] hover:bg-[#0aa6a1] text-white font-extrabold rounded-2xl text-xs sm:text-sm shadow-md transition cursor-pointer flex items-center gap-2"
            >
              <Search className="w-4 h-4" />
              <span>View in Medicine Search</span>
            </button>

            <button
              onClick={handleResetForm}
              className="px-5 py-3 bg-slate-100 dark:bg-slate-800 text-slate-700 dark:text-slate-200 font-bold rounded-2xl text-xs sm:text-sm transition cursor-pointer hover:bg-slate-200"
            >
              Register Another Pharmacy
            </button>
          </div>
        </div>
      ) : (
        <>
          {/* STEP 1: PHARMACY DETAILS FORM */}
          {currentStep === 1 && (
            <div className="bg-white dark:bg-slate-900 border border-slate-200/80 dark:border-slate-800 rounded-3xl p-6 sm:p-8 space-y-6 shadow-xs animate-fade-in">
              <div className="border-b border-slate-100 dark:border-slate-800 pb-4">
                <h2 className="text-lg font-extrabold text-slate-900 dark:text-white flex items-center gap-2">
                  <Building2 className="w-5 h-5 text-[#0bbbb6]" />
                  <span>Step 1: Pharmacy Details</span>
                </h2>
                <p className="text-xs text-slate-500 dark:text-slate-400 font-medium mt-0.5">
                  Enter store information, owner contact, address, and operating hours
                </p>
              </div>

              <form onSubmit={handleStep1Next} className="space-y-4">
                <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
                  {/* Pharmacy Name */}
                  <div>
                    <label className="block text-xs font-bold text-slate-700 dark:text-slate-300 mb-1">
                      Pharmacy Name *
                    </label>
                    <div className="relative">
                      <Building2 className="w-4 h-4 text-slate-400 absolute left-3.5 top-3" />
                      <input
                        type="text"
                        required
                        value={name}
                        onChange={e => setName(e.target.value)}
                        placeholder="e.g. Apollo Pharmacy - Health Hub"
                        className="w-full pl-10 pr-4 py-2.5 bg-slate-50 dark:bg-slate-800 border border-slate-200 dark:border-slate-700 rounded-2xl text-xs sm:text-sm focus:outline-none focus:ring-2 focus:ring-[#0bbbb6] dark:text-white font-medium"
                      />
                    </div>
                  </div>

                  {/* Owner Name */}
                  <div>
                    <label className="block text-xs font-bold text-slate-700 dark:text-slate-300 mb-1">
                      Owner / Pharmacist Name *
                    </label>
                    <div className="relative">
                      <User className="w-4 h-4 text-slate-400 absolute left-3.5 top-3" />
                      <input
                        type="text"
                        required
                        value={ownerName}
                        onChange={e => setOwnerName(e.target.value)}
                        placeholder="e.g. Dr. Rajesh Sharma"
                        className="w-full pl-10 pr-4 py-2.5 bg-slate-50 dark:bg-slate-800 border border-slate-200 dark:border-slate-700 rounded-2xl text-xs sm:text-sm focus:outline-none focus:ring-2 focus:ring-[#0bbbb6] dark:text-white font-medium"
                      />
                    </div>
                  </div>

                  {/* Phone Number */}
                  <div>
                    <label className="block text-xs font-bold text-slate-700 dark:text-slate-300 mb-1">
                      Phone Number (Tap to Call) *
                    </label>
                    <div className="relative">
                      <Phone className="w-4 h-4 text-slate-400 absolute left-3.5 top-3" />
                      <input
                        type="text"
                        required
                        value={phone}
                        onChange={e => setPhone(e.target.value)}
                        placeholder="+91 98765 43210"
                        className="w-full pl-10 pr-4 py-2.5 bg-slate-50 dark:bg-slate-800 border border-slate-200 dark:border-slate-700 rounded-2xl text-xs sm:text-sm focus:outline-none focus:ring-2 focus:ring-[#0bbbb6] dark:text-white font-medium"
                      />
                    </div>
                  </div>

                  {/* Email */}
                  <div>
                    <label className="block text-xs font-bold text-slate-700 dark:text-slate-300 mb-1">
                      Email Address (Optional)
                    </label>
                    <div className="relative">
                      <Mail className="w-4 h-4 text-slate-400 absolute left-3.5 top-3" />
                      <input
                        type="email"
                        value={email}
                        onChange={e => setEmail(e.target.value)}
                        placeholder="contact@pharmacy.com"
                        className="w-full pl-10 pr-4 py-2.5 bg-slate-50 dark:bg-slate-800 border border-slate-200 dark:border-slate-700 rounded-2xl text-xs sm:text-sm focus:outline-none focus:ring-2 focus:ring-[#0bbbb6] dark:text-white font-medium"
                      />
                    </div>
                  </div>

                  {/* Address */}
                  <div className="md:col-span-2">
                    <label className="block text-xs font-bold text-slate-700 dark:text-slate-300 mb-1">
                      Street Address & Landmark *
                    </label>
                    <div className="relative">
                      <MapPin className="w-4 h-4 text-slate-400 absolute left-3.5 top-3" />
                      <input
                        type="text"
                        required
                        value={address}
                        onChange={e => setAddress(e.target.value)}
                        placeholder="e.g. Shop 14, Ground Floor, Jubilee Hills Road No 36"
                        className="w-full pl-10 pr-4 py-2.5 bg-slate-50 dark:bg-slate-800 border border-slate-200 dark:border-slate-700 rounded-2xl text-xs sm:text-sm focus:outline-none focus:ring-2 focus:ring-[#0bbbb6] dark:text-white font-medium"
                      />
                    </div>
                  </div>

                  {/* City */}
                  <div>
                    <label className="block text-xs font-bold text-slate-700 dark:text-slate-300 mb-1">
                      City / Region *
                    </label>
                    <input
                      type="text"
                      required
                      value={city}
                      onChange={e => setCity(e.target.value)}
                      placeholder="e.g. Hyderabad"
                      className="w-full px-4 py-2.5 bg-slate-50 dark:bg-slate-800 border border-slate-200 dark:border-slate-700 rounded-2xl text-xs sm:text-sm focus:outline-none focus:ring-2 focus:ring-[#0bbbb6] dark:text-white font-medium"
                    />
                  </div>

                  {/* Opening & Closing Hours */}
                  <div>
                    <label className="block text-xs font-bold text-slate-700 dark:text-slate-300 mb-1">
                      Opening & Closing Hours *
                    </label>
                    <div className="relative">
                      <Clock className="w-4 h-4 text-slate-400 absolute left-3.5 top-3" />
                      <input
                        type="text"
                        required
                        value={openHours}
                        onChange={e => setOpenHours(e.target.value)}
                        placeholder="e.g. 8:00 AM - 10:00 PM or Open 24 Hours"
                        className="w-full pl-10 pr-4 py-2.5 bg-slate-50 dark:bg-slate-800 border border-slate-200 dark:border-slate-700 rounded-2xl text-xs sm:text-sm focus:outline-none focus:ring-2 focus:ring-[#0bbbb6] dark:text-white font-medium"
                      />
                    </div>
                  </div>
                </div>

                {/* GPS LOCATION SETUP */}
                <div className="pt-3 border-t border-slate-100 dark:border-slate-800 space-y-3">
                  <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-2">
                    <div>
                      <label className="text-xs font-bold text-slate-700 dark:text-slate-300 flex items-center gap-1.5">
                        <MapPin className="w-4 h-4 text-[#0bbbb6]" />
                        <span>GPS Coordinates (Latitude & Longitude)</span>
                      </label>
                      <p className="text-[11px] text-slate-500 dark:text-slate-400">
                        Required for exact Google Maps navigation and distance calculations
                      </p>
                    </div>

                    <button
                      type="button"
                      onClick={handleAutoDetectLocation}
                      disabled={isDetectingGps}
                      className="px-3.5 py-1.5 bg-[#0bbbb6]/10 text-[#0bbbb6] hover:bg-[#0bbbb6]/20 font-bold rounded-2xl text-xs transition flex items-center gap-1.5 shrink-0 cursor-pointer"
                    >
                      <LocateFixed className={`w-3.5 h-3.5 ${isDetectingGps ? 'animate-spin' : ''}`} />
                      <span>{isDetectingGps ? 'Detecting GPS...' : 'Auto-Detect GPS Location'}</span>
                    </button>
                  </div>

                  {gpsSuccessMessage && (
                    <div className="p-2.5 bg-emerald-50 dark:bg-emerald-950/40 text-emerald-700 dark:text-emerald-300 text-xs font-bold rounded-xl border border-emerald-200/60 flex items-center gap-1.5">
                      <CheckCircle2 className="w-4 h-4 text-emerald-600" />
                      <span>{gpsSuccessMessage}</span>
                    </div>
                  )}

                  <div className="grid grid-cols-2 gap-3">
                    <div>
                      <span className="text-[10px] font-bold text-slate-500 uppercase">Latitude</span>
                      <input
                        type="number"
                        step="any"
                        value={lat}
                        onChange={e => setLat(parseFloat(e.target.value) || 0)}
                        className="w-full px-3 py-2 bg-slate-50 dark:bg-slate-800 border border-slate-200 dark:border-slate-700 rounded-xl text-xs font-bold dark:text-white"
                      />
                    </div>
                    <div>
                      <span className="text-[10px] font-bold text-slate-500 uppercase">Longitude</span>
                      <input
                        type="number"
                        step="any"
                        value={lng}
                        onChange={e => setLng(parseFloat(e.target.value) || 0)}
                        className="w-full px-3 py-2 bg-slate-50 dark:bg-slate-800 border border-slate-200 dark:border-slate-700 rounded-xl text-xs font-bold dark:text-white"
                      />
                    </div>
                  </div>
                </div>

                <div className="pt-4 flex justify-end">
                  <button
                    type="submit"
                    className="px-6 py-3 bg-[#0bbbb6] hover:bg-[#0aa6a1] text-white font-extrabold rounded-2xl text-xs sm:text-sm shadow-md transition cursor-pointer flex items-center gap-2"
                  >
                    <span>Proceed to Step 2: Upload Inventory</span>
                    <ChevronRight className="w-4 h-4" />
                  </button>
                </div>
              </form>
            </div>
          )}

          {/* STEP 2: MEDICINE INVENTORY UPLOAD */}
          {currentStep === 2 && (
            <div className="bg-white dark:bg-slate-900 border border-slate-200/80 dark:border-slate-800 rounded-3xl p-6 sm:p-8 space-y-6 shadow-xs animate-fade-in">
              <div className="border-b border-slate-100 dark:border-slate-800 pb-4 flex flex-col sm:flex-row sm:items-center justify-between gap-3">
                <div>
                  <h2 className="text-lg font-extrabold text-slate-900 dark:text-white flex items-center gap-2">
                    <FileSpreadsheet className="w-5 h-5 text-[#0bbbb6]" />
                    <span>Step 2: Medicine Inventory Upload</span>
                  </h2>
                  <p className="text-xs text-slate-500 dark:text-slate-400 font-medium mt-0.5">
                    Upload a CSV or Excel (.csv / .xlsx) spreadsheet containing your stock
                  </p>
                </div>

                <div className="flex items-center gap-2 shrink-0">
                  <button
                    type="button"
                    onClick={handleDownloadSampleTemplate}
                    className="px-3.5 py-1.5 bg-slate-100 dark:bg-slate-800 hover:bg-slate-200 text-slate-700 dark:text-slate-200 font-bold rounded-2xl text-xs transition flex items-center gap-1.5 cursor-pointer"
                  >
                    <Download className="w-3.5 h-3.5" />
                    <span>Download Sample Excel</span>
                  </button>

                  <button
                    type="button"
                    onClick={handleLoadDemoInventory}
                    className="px-3.5 py-1.5 bg-teal-50 dark:bg-teal-950/40 text-[#0bbbb6] font-bold border border-[#0bbbb6]/30 rounded-2xl text-xs transition flex items-center gap-1.5 cursor-pointer"
                  >
                    <RefreshCw className="w-3.5 h-3.5" />
                    <span>Load Demo Data</span>
                  </button>
                </div>
              </div>

              {/* UPLOAD BOX */}
              <div className="border-2 border-dashed border-[#0bbbb6]/40 dark:border-teal-700/60 rounded-3xl p-6 sm:p-8 text-center space-y-4 bg-teal-50/30 dark:bg-slate-800/40">
                <div className="w-12 h-12 bg-[#0bbbb6]/10 text-[#0bbbb6] rounded-2xl flex items-center justify-center mx-auto">
                  <Upload className="w-6 h-6" />
                </div>

                <div className="space-y-1">
                  <h3 className="text-sm font-extrabold text-slate-800 dark:text-white">
                    Drop your inventory file here or browse
                  </h3>
                  <p className="text-xs text-slate-500 dark:text-slate-400 font-medium">
                    Supports <strong>.csv, .xlsx, .xls</strong> formats. Column headers auto-detected.
                  </p>
                </div>

                <div className="flex items-center justify-center">
                  <label className="px-5 py-2.5 bg-[#0bbbb6] hover:bg-[#0aa6a1] text-white font-bold rounded-2xl text-xs cursor-pointer shadow-xs transition flex items-center gap-2">
                    <FileText className="w-4 h-4" />
                    <span>Select CSV or Excel File</span>
                    <input
                      type="file"
                      accept=".csv, .xlsx, .xls"
                      onChange={handleFileUpload}
                      className="hidden"
                    />
                  </label>
                </div>

                {fileName && (
                  <div className="p-3 bg-white dark:bg-slate-900 border border-slate-200 dark:border-slate-700 rounded-2xl text-xs font-bold text-slate-700 dark:text-slate-200 inline-flex items-center gap-2 shadow-2xs">
                    <FileSpreadsheet className="w-4 h-4 text-[#0bbbb6]" />
                    <span>Uploaded: {fileName}</span>
                  </div>
                )}
              </div>

              {/* UPLOAD ERROR DISPLAY */}
              {uploadError && (
                <div className="p-3 bg-rose-50 dark:bg-rose-950/40 border border-rose-200 dark:border-rose-800 rounded-2xl text-xs text-rose-700 dark:text-rose-300 font-bold flex items-center gap-2">
                  <AlertTriangle className="w-4 h-4 shrink-0" />
                  <span>{uploadError}</span>
                </div>
              )}

              {/* IMPORT STATS & VALIDATION SUMMARY */}
              {importedMedicines.length > 0 && (
                <div className="space-y-4">
                  <div className="grid grid-cols-1 sm:grid-cols-3 gap-3">
                    <div className="p-3.5 bg-emerald-50 dark:bg-emerald-950/40 border border-emerald-200/60 dark:border-emerald-800 rounded-2xl text-center">
                      <div className="text-xs font-bold text-emerald-800 dark:text-emerald-300">Total Valid Medicines</div>
                      <div className="text-xl font-black text-emerald-600 dark:text-emerald-400 mt-0.5">
                        {importedMedicines.length}
                      </div>
                    </div>

                    <div className="p-3.5 bg-amber-50 dark:bg-amber-950/40 border border-amber-200/60 dark:border-amber-800 rounded-2xl text-center">
                      <div className="text-xs font-bold text-amber-800 dark:text-amber-300">Duplicates Identified</div>
                      <div className="text-xl font-black text-amber-600 dark:text-amber-400 mt-0.5">
                        {validationDuplicates.length}
                      </div>
                    </div>

                    <div className="p-3.5 bg-slate-50 dark:bg-slate-800 border border-slate-200/60 dark:border-slate-700 rounded-2xl text-center">
                      <div className="text-xs font-bold text-slate-700 dark:text-slate-300">Invalid Rows Skipped</div>
                      <div className="text-xl font-black text-slate-800 dark:text-slate-200 mt-0.5">
                        {invalidEntriesCount}
                      </div>
                    </div>
                  </div>

                  {/* DUPLICATE WARNING BAR */}
                  {validationDuplicates.length > 0 && (
                    <div className="p-4 bg-amber-50 dark:bg-amber-950/50 border border-amber-200 dark:border-amber-800 rounded-2xl flex flex-col sm:flex-row sm:items-center justify-between gap-3 text-xs">
                      <div className="space-y-0.5">
                        <div className="font-extrabold text-amber-900 dark:text-amber-200 flex items-center gap-1.5">
                          <AlertTriangle className="w-4 h-4 text-amber-600 shrink-0" />
                          <span>Duplicate Medicine Entries Detected ({validationDuplicates.length})</span>
                        </div>
                        <p className="text-amber-800 dark:text-amber-300 text-[11px]">
                          Multiple entries found for: {validationDuplicates.slice(0, 3).join(', ')}...
                        </p>
                      </div>

                      <button
                        type="button"
                        onClick={handleDeduplicate}
                        className="px-3.5 py-1.5 bg-amber-600 hover:bg-amber-700 text-white font-bold rounded-xl shrink-0 transition cursor-pointer"
                      >
                        Auto-Remove Duplicates
                      </button>
                    </div>
                  )}

                  {/* QUICK MANUAL MEDICINE ADD FORM */}
                  <div className="p-4 bg-slate-50 dark:bg-slate-800/60 rounded-2xl border border-slate-200 dark:border-slate-700 space-y-3">
                    <div className="text-xs font-extrabold text-slate-800 dark:text-slate-200 flex items-center gap-1.5">
                      <Plus className="w-4 h-4 text-[#0bbbb6]" />
                      <span>Add Individual Medicine Manually</span>
                    </div>

                    <form onSubmit={handleAddManualMedicine} className="grid grid-cols-1 sm:grid-cols-5 gap-2">
                      <input
                        type="text"
                        placeholder="Medicine Name *"
                        value={newMedName}
                        onChange={e => setNewMedName(e.target.value)}
                        className="px-3 py-2 bg-white dark:bg-slate-900 border border-slate-200 dark:border-slate-700 rounded-xl text-xs font-medium dark:text-white"
                      />
                      <input
                        type="text"
                        placeholder="Generic / Salt"
                        value={newMedGeneric}
                        onChange={e => setNewMedGeneric(e.target.value)}
                        className="px-3 py-2 bg-white dark:bg-slate-900 border border-slate-200 dark:border-slate-700 rounded-xl text-xs font-medium dark:text-white"
                      />
                      <input
                        type="text"
                        placeholder="Dosage (e.g. 500mg)"
                        value={newMedDosage}
                        onChange={e => setNewMedDosage(e.target.value)}
                        className="px-3 py-2 bg-white dark:bg-slate-900 border border-slate-200 dark:border-slate-700 rounded-xl text-xs font-medium dark:text-white"
                      />
                      <input
                        type="number"
                        placeholder="Price (₹)"
                        value={newMedPrice}
                        onChange={e => setNewMedPrice(e.target.value)}
                        className="px-3 py-2 bg-white dark:bg-slate-900 border border-slate-200 dark:border-slate-700 rounded-xl text-xs font-medium dark:text-white"
                      />
                      <button
                        type="submit"
                        className="px-3 py-2 bg-[#0bbbb6] hover:bg-[#0aa6a1] text-white font-bold rounded-xl text-xs transition cursor-pointer flex items-center justify-center gap-1"
                      >
                        <Plus className="w-3.5 h-3.5" />
                        <span>Add Item</span>
                      </button>
                    </form>
                  </div>
                </div>
              )}

              {/* NAVIGATION BUTTONS */}
              <div className="pt-4 flex items-center justify-between border-t border-slate-100 dark:border-slate-800">
                <button
                  type="button"
                  onClick={() => setCurrentStep(1)}
                  className="px-5 py-2.5 bg-slate-100 dark:bg-slate-800 text-slate-700 dark:text-slate-300 font-bold rounded-2xl text-xs transition cursor-pointer flex items-center gap-1.5"
                >
                  <ChevronLeft className="w-4 h-4" />
                  <span>Back to Details</span>
                </button>

                <button
                  type="button"
                  onClick={() => {
                    if (importedMedicines.length === 0) {
                      alert("Please upload or add at least 1 medicine item.");
                      return;
                    }
                    setCurrentStep(3);
                  }}
                  className="px-6 py-3 bg-[#0bbbb6] hover:bg-[#0aa6a1] text-white font-extrabold rounded-2xl text-xs sm:text-sm shadow-md transition cursor-pointer flex items-center gap-2"
                >
                  <span>Proceed to Step 3: Review & Publish</span>
                  <ChevronRight className="w-4 h-4" />
                </button>
              </div>
            </div>
          )}

          {/* STEP 3: REVIEW & PUBLISH */}
          {currentStep === 3 && (
            <div className="bg-white dark:bg-slate-900 border border-slate-200/80 dark:border-slate-800 rounded-3xl p-6 sm:p-8 space-y-6 shadow-xs animate-fade-in">
              <div className="border-b border-slate-100 dark:border-slate-800 pb-4">
                <h2 className="text-lg font-extrabold text-slate-900 dark:text-white flex items-center gap-2">
                  <Eye className="w-5 h-5 text-[#0bbbb6]" />
                  <span>Step 3: Review & Publish</span>
                </h2>
                <p className="text-xs text-slate-500 dark:text-slate-400 font-medium mt-0.5">
                  Verify your pharmacy details and medicine inventory before going live
                </p>
              </div>

              {/* PHARMACY SUMMARY CARD */}
              <div className="p-5 bg-slate-50 dark:bg-slate-800/60 rounded-3xl border border-slate-200 dark:border-slate-700 space-y-3">
                <div className="flex items-center justify-between">
                  <div className="flex items-center gap-2">
                    <Building2 className="w-5 h-5 text-[#0bbbb6]" />
                    <h3 className="text-base font-extrabold text-slate-900 dark:text-white">{name}</h3>
                  </div>

                  <button
                    onClick={() => setCurrentStep(1)}
                    className="text-xs font-bold text-[#0bbbb6] hover:underline flex items-center gap-1 cursor-pointer"
                  >
                    <Edit3 className="w-3.5 h-3.5" />
                    <span>Edit Details</span>
                  </button>
                </div>

                <div className="grid grid-cols-1 sm:grid-cols-2 md:grid-cols-3 gap-3 text-xs text-slate-600 dark:text-slate-300 font-medium">
                  <div>
                    <span className="text-slate-400 font-bold block text-[10px] uppercase">Owner Name</span>
                    <strong>{ownerName}</strong>
                  </div>
                  <div>
                    <span className="text-slate-400 font-bold block text-[10px] uppercase">Phone Number</span>
                    <strong>{phone}</strong>
                  </div>
                  <div>
                    <span className="text-slate-400 font-bold block text-[10px] uppercase">Email</span>
                    <strong>{email || 'N/A'}</strong>
                  </div>
                  <div>
                    <span className="text-slate-400 font-bold block text-[10px] uppercase">Address</span>
                    <strong>{address}, {city}</strong>
                  </div>
                  <div>
                    <span className="text-slate-400 font-bold block text-[10px] uppercase">Opening Hours</span>
                    <strong>{openHours}</strong>
                  </div>
                  <div>
                    <span className="text-slate-400 font-bold block text-[10px] uppercase">GPS Coordinates</span>
                    <strong>{lat}, {lng}</strong>
                  </div>
                </div>
              </div>

              {/* MEDICINE INVENTORY PREVIEW TABLE */}
              <div className="space-y-3">
                <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-2">
                  <div className="flex items-center gap-2">
                    <Pill className="w-4 h-4 text-[#0bbbb6]" />
                    <h4 className="text-sm font-extrabold text-slate-900 dark:text-white">
                      Uploaded Medicine Inventory ({importedMedicines.length} items)
                    </h4>
                  </div>

                  <div className="flex items-center gap-2">
                    <input
                      type="text"
                      placeholder="Filter preview list..."
                      value={inventorySearchQuery}
                      onChange={e => setInventorySearchQuery(e.target.value)}
                      className="px-3 py-1.5 bg-slate-50 dark:bg-slate-800 border border-slate-200 dark:border-slate-700 rounded-xl text-xs font-medium dark:text-white"
                    />

                    <button
                      onClick={() => setCurrentStep(2)}
                      className="text-xs font-bold text-[#0bbbb6] hover:underline flex items-center gap-1 cursor-pointer shrink-0"
                    >
                      <Edit3 className="w-3.5 h-3.5" />
                      <span>Re-upload File</span>
                    </button>
                  </div>
                </div>

                <div className="overflow-x-auto border border-slate-200 dark:border-slate-800 rounded-2xl max-h-72 overflow-y-auto">
                  <table className="w-full text-left border-collapse text-xs">
                    <thead className="bg-slate-100 dark:bg-slate-800/80 sticky top-0 z-10 text-slate-700 dark:text-slate-300 font-bold border-b border-slate-200 dark:border-slate-700">
                      <tr>
                        <th className="p-3">#</th>
                        <th className="p-3">Medicine Name</th>
                        <th className="p-3">Generic Salt</th>
                        <th className="p-3">Dosage</th>
                        <th className="p-3">Price</th>
                        <th className="p-3">Stock Status</th>
                        <th className="p-3">Qty</th>
                        <th className="p-3 text-right">Action</th>
                      </tr>
                    </thead>
                    <tbody className="divide-y divide-slate-100 dark:divide-slate-800 font-medium">
                      {filteredPreviewMedicines.map((med, idx) => (
                        <tr key={idx} className="hover:bg-slate-50 dark:hover:bg-slate-800/40">
                          <td className="p-3 text-slate-400">{idx + 1}</td>
                          <td className="p-3 font-bold text-slate-900 dark:text-white">{med.name}</td>
                          <td className="p-3 text-slate-500 dark:text-slate-400">{med.genericName}</td>
                          <td className="p-3">{med.dosage}</td>
                          <td className="p-3 font-bold text-slate-800 dark:text-slate-200">₹{med.price}</td>
                          <td className="p-3">
                            <span className={`px-2 py-0.5 rounded-full text-[10px] font-bold ${
                              med.stockStatus === 'In Stock'
                                ? 'bg-emerald-100 dark:bg-emerald-950 text-emerald-800 dark:text-emerald-300'
                                : med.stockStatus === 'Low Stock'
                                ? 'bg-amber-100 dark:bg-amber-950 text-amber-800 dark:text-amber-300'
                                : 'bg-rose-100 dark:bg-rose-950 text-rose-800 dark:text-rose-300'
                            }`}>
                              {med.stockStatus}
                            </span>
                          </td>
                          <td className="p-3 font-bold">{med.quantity}</td>
                          <td className="p-3 text-right">
                            <button
                              onClick={() => handleRemoveMedicine(idx)}
                              className="text-rose-500 hover:text-rose-700 p-1 rounded transition cursor-pointer"
                              title="Delete medicine"
                            >
                              <Trash2 className="w-3.5 h-3.5" />
                            </button>
                          </td>
                        </tr>
                      ))}
                    </tbody>
                  </table>
                </div>
              </div>

              {/* SUBMIT BUTTON */}
              <div className="pt-4 flex items-center justify-between border-t border-slate-100 dark:border-slate-800">
                <button
                  type="button"
                  onClick={() => setCurrentStep(2)}
                  className="px-5 py-2.5 bg-slate-100 dark:bg-slate-800 text-slate-700 dark:text-slate-300 font-bold rounded-2xl text-xs transition cursor-pointer flex items-center gap-1.5"
                >
                  <ChevronLeft className="w-4 h-4" />
                  <span>Back to Upload</span>
                </button>

                <button
                  type="button"
                  onClick={handlePublishPharmacy}
                  disabled={isPublishing}
                  className="px-8 py-3 bg-[#0bbbb6] hover:bg-[#0aa6a1] text-white font-extrabold rounded-2xl text-sm shadow-md transition cursor-pointer flex items-center gap-2"
                >
                  <CheckCircle2 className="w-5 h-5" />
                  <span>{isPublishing ? 'Saving & Publishing...' : 'Register & Publish Pharmacy'}</span>
                </button>
              </div>
            </div>
          )}
        </>
      )}

      {/* EXISTING REGISTERED PHARMACIES INVENTORY MANAGER */}
      <div className="bg-white dark:bg-slate-900 border border-slate-200/80 dark:border-slate-800 rounded-3xl p-6 space-y-4 shadow-xs">
        <div className="flex items-center justify-between">
          <div className="flex items-center gap-2">
            <Building2 className="w-5 h-5 text-[#0bbbb6]" />
            <h3 className="text-base font-extrabold text-slate-900 dark:text-white">
              Manage Registered Pharmacies ({registeredPharmacies.length})
            </h3>
          </div>

          <span className="text-xs text-slate-400 font-medium">
            Re-upload inventory anytime without duplicates
          </span>
        </div>

        <div className="grid grid-cols-1 md:grid-cols-2 gap-3">
          {registeredPharmacies.map((ph) => (
            <div
              key={ph.id}
              className="p-4 bg-slate-50 dark:bg-slate-800/60 border border-slate-200 dark:border-slate-700 rounded-2xl flex items-center justify-between gap-3"
            >
              <div className="space-y-0.5">
                <h4 className="text-xs sm:text-sm font-extrabold text-slate-900 dark:text-white">
                  {ph.name}
                </h4>
                <p className="text-[11px] text-slate-500 dark:text-slate-400 font-medium">
                  📍 {ph.address} • 📞 {ph.phone}
                </p>
                <div className="text-[10px] font-bold text-[#0bbbb6]">
                  {ph.medicines.length} medicines in inventory
                </div>
              </div>

              <button
                onClick={() => handleLoadExistingPharmacyForEdit(ph)}
                className="px-3.5 py-2 bg-[#0bbbb6]/10 text-[#0bbbb6] hover:bg-[#0bbbb6]/20 font-bold rounded-xl text-xs transition cursor-pointer shrink-0 flex items-center gap-1"
              >
                <Edit3 className="w-3.5 h-3.5" />
                <span>Update Inventory</span>
              </button>
            </div>
          ))}
        </div>
      </div>
    </div>
  );
}
