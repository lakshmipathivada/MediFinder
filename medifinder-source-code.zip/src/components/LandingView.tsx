import React, { useState, useEffect, useRef } from 'react';
import { 
  Pill, 
  ShieldCheck, 
  ArrowRight, 
  AlertCircle, 
  Phone, 
  User, 
  X, 
  Plus, 
  Check, 
  Key, 
  Mail, 
  Lock, 
  Eye, 
  EyeOff, 
  LogIn, 
  UserPlus,
  Flame,
  ExternalLink,
  RefreshCw
} from 'lucide-react';
import { UserProfile } from '../types';
import { authService } from '../services/authService';
import { 
  isFirebaseConfigured, 
  getFirebaseConfig, 
  saveFirebaseConfig, 
  clearFirebaseConfig 
} from '../lib/firebase';

interface LandingViewProps {
  onLogin: (user: UserProfile) => void;
}

interface PresetAccount {
  name: string;
  email: string;
  avatarColor: string;
  password?: string;
  phone: string;
}

const PRESET_ACCOUNTS: PresetAccount[] = [
  {
    name: 'Govardhan',
    email: 'govardhan.dev@gmail.com',
    avatarColor: 'bg-indigo-600',
    password: 'Password@123',
    phone: '9848012345'
  },
  {
    name: 'Alex Johnson',
    email: 'alex.johnson@gmail.com',
    avatarColor: 'bg-blue-600',
    password: 'Password@123',
    phone: '9123456789'
  },
  {
    name: 'Lakshmi Pathi Vada',
    email: 'lakshmipathivada25@gmail.com',
    avatarColor: 'bg-emerald-600',
    password: 'Password@123',
    phone: '9876543210'
  }
];

export default function LandingView({ onLogin }: LandingViewProps) {
  const [authMode, setAuthMode] = useState<'signin' | 'signup'>('signin');

  // Sign In form state
  const [signInEmail, setSignInEmail] = useState('');
  const [signInPassword, setSignInPassword] = useState('');
  const [showSignInPassword, setShowSignInPassword] = useState(false);

  // Sign Up form state
  const [signUpName, setSignUpName] = useState('');
  const [signUpEmail, setSignUpEmail] = useState('');
  const [signUpPhone, setSignUpPhone] = useState('');
  const [signUpPassword, setSignUpPassword] = useState('');
  const [signUpConfirmPassword, setSignUpConfirmPassword] = useState('');
  const [showSignUpPassword, setShowSignUpPassword] = useState(false);

  // UI feedback state
  const [isLoading, setIsLoading] = useState(false);
  const [errorMessage, setErrorMessage] = useState<string | null>(null);
  const [successMessage, setSuccessMessage] = useState<string | null>(null);

  // Google Accounts Modal state
  const [showGoogleModal, setShowGoogleModal] = useState(false);
  const [customGoogleEmail, setCustomGoogleEmail] = useState('');
  const [customGoogleName, setCustomGoogleName] = useState('');
  const [showAddGoogleInput, setShowAddGoogleInput] = useState(false);
  const [showClientIdConfig, setShowClientIdConfig] = useState(false);

  // Firebase configuration state
  const [isFirebase, setIsFirebase] = useState(() => isFirebaseConfigured());
  const [firebaseCfg, setFirebaseCfg] = useState(() => getFirebaseConfig());
  const [showFirebaseModal, setShowFirebaseModal] = useState(false);
  const [fbPasteText, setFbPasteText] = useState('');
  const [fbApiKey, setFbApiKey] = useState(firebaseCfg?.apiKey || '');
  const [fbProjectId, setFbProjectId] = useState(firebaseCfg?.projectId || '');
  const [fbAuthDomain, setFbAuthDomain] = useState(firebaseCfg?.authDomain || '');
  const [fbAppId, setFbAppId] = useState(firebaseCfg?.appId || '');

  const handleContinueWithGoogle = async () => {
    setErrorMessage(null);
    if (isFirebase) {
      setIsLoading(true);
      try {
        const user = await authService.loginWithGoogle();
        onLogin(user);
      } catch (err: any) {
        setErrorMessage(err?.message || 'Google sign-in was cancelled or failed.');
      } finally {
        setIsLoading(false);
      }
    } else {
      setShowGoogleModal(true);
    }
  };

  const handleSaveFirebaseSettings = (e?: React.FormEvent) => {
    if (e) e.preventDefault();
    try {
      let finalConfig: any = {};
      const paste = fbPasteText.trim();
      if (paste) {
        const apiKeyMatch = paste.match(/apiKey["':\s]+([^\s"',;]+)/);
        const authDomainMatch = paste.match(/authDomain["':\s]+([^\s"',;]+)/);
        const projectIdMatch = paste.match(/projectId["':\s]+([^\s"',;]+)/);
        const storageBucketMatch = paste.match(/storageBucket["':\s]+([^\s"',;]+)/);
        const senderIdMatch = paste.match(/messagingSenderId["':\s]+([^\s"',;]+)/);
        const appIdMatch = paste.match(/appId["':\s]+([^\s"',;]+)/);

        const pid = projectIdMatch ? projectIdMatch[1] : fbProjectId.trim();
        finalConfig = {
          apiKey: apiKeyMatch ? apiKeyMatch[1] : fbApiKey.trim(),
          authDomain: authDomainMatch ? authDomainMatch[1] : fbAuthDomain.trim() || `${pid}.firebaseapp.com`,
          projectId: pid,
          storageBucket: storageBucketMatch ? storageBucketMatch[1] : `${pid}.appspot.com`,
          messagingSenderId: senderIdMatch ? senderIdMatch[1] : '',
          appId: appIdMatch ? appIdMatch[1] : fbAppId.trim()
        };
      } else {
        if (!fbApiKey.trim() || !fbProjectId.trim()) {
          setErrorMessage('Please provide at least a valid Firebase apiKey and projectId.');
          return;
        }
        finalConfig = {
          apiKey: fbApiKey.trim(),
          authDomain: fbAuthDomain.trim() || `${fbProjectId.trim()}.firebaseapp.com`,
          projectId: fbProjectId.trim(),
          storageBucket: `${fbProjectId.trim()}.appspot.com`,
          messagingSenderId: '',
          appId: fbAppId.trim()
        };
      }

      saveFirebaseConfig(finalConfig);
      setIsFirebase(true);
      setFirebaseCfg(finalConfig);
      setShowFirebaseModal(false);
      setSuccessMessage(`Firebase project "${finalConfig.projectId}" connected successfully! Reloading...`);
      setTimeout(() => {
        window.location.reload();
      }, 600);
    } catch (err: any) {
      setErrorMessage('Failed to configure Firebase: ' + (err?.message || String(err)));
    }
  };

  const handleClearFirebase = () => {
    clearFirebaseConfig();
    setIsFirebase(false);
    setFirebaseCfg(null);
    setShowFirebaseModal(false);
    setSuccessMessage('Firebase configuration removed. Reloading...');
    setTimeout(() => {
      window.location.reload();
    }, 600);
  };

  const [googleClientId, setGoogleClientId] = useState(() => {
    return (
      (import.meta as any).env?.VITE_GOOGLE_CLIENT_ID ||
      localStorage.getItem('medifinder_google_client_id') ||
      ''
    );
  });
  const [clientIdInput, setClientIdInput] = useState(googleClientId);

  const googleBtnContainerRef = useRef<HTMLDivElement>(null);

  // Initialize Google Identity Services if client ID is configured
  useEffect(() => {
    if (!googleClientId) return;
    const win = window as any;
    if (win.google?.accounts?.id && googleBtnContainerRef.current) {
      try {
        win.google.accounts.id.initialize({
          client_id: googleClientId,
          callback: async (response: { credential?: string }) => {
            if (response.credential) {
              await handleGoogleCredentialLogin(response.credential);
            }
          }
        });
        googleBtnContainerRef.current.innerHTML = '';
        win.google.accounts.id.renderButton(googleBtnContainerRef.current, {
          theme: 'outline',
          size: 'large',
          type: 'standard',
          shape: 'pill',
          text: 'continue_with',
          width: 320
        });
      } catch (err) {
        console.warn('Google Identity Services notice:', err);
      }
    }
  }, [googleClientId, showGoogleModal]);

  const handleGoogleCredentialLogin = async (credential: string) => {
    setIsLoading(true);
    setErrorMessage(null);
    try {
      const user = await authService.loginWithGoogle({ credential });
      setShowGoogleModal(false);
      onLogin(user);
    } catch (err: any) {
      setErrorMessage(err?.message || 'Google authentication failed.');
    } finally {
      setIsLoading(false);
    }
  };

  const handleGoogleAccountSelect = async (account: PresetAccount) => {
    setIsLoading(true);
    setErrorMessage(null);
    try {
      const user = await authService.loginWithGoogle({
        userInfo: {
          email: account.email,
          name: account.name,
          avatar: `https://ui-avatars.com/api/?name=${encodeURIComponent(account.name)}&background=0bbbb6&color=fff`
        }
      });
      setShowGoogleModal(false);
      onLogin(user);
    } catch (err: any) {
      setErrorMessage(err?.message || 'Google login failed.');
    } finally {
      setIsLoading(false);
    }
  };

  const handleCustomGoogleSubmit = async (e: React.FormEvent) => {
    e.preventDefault();
    if (!customGoogleEmail.trim() || !customGoogleName.trim()) return;
    setIsLoading(true);
    setErrorMessage(null);
    try {
      const user = await authService.loginWithGoogle({
        userInfo: {
          email: customGoogleEmail.trim(),
          name: customGoogleName.trim(),
          avatar: `https://ui-avatars.com/api/?name=${encodeURIComponent(customGoogleName.trim())}&background=4285F4&color=fff`
        }
      });
      setShowGoogleModal(false);
      onLogin(user);
    } catch (err: any) {
      setErrorMessage(err?.message || 'Google sign-in failed.');
    } finally {
      setIsLoading(false);
    }
  };

  const handleSignInSubmit = async (e: React.FormEvent) => {
    e.preventDefault();
    setErrorMessage(null);

    if (!signInEmail.trim()) {
      setErrorMessage('Please enter your email address.');
      return;
    }
    if (!signInPassword) {
      setErrorMessage('Please enter your password.');
      return;
    }

    setIsLoading(true);
    try {
      const user = await authService.login(signInEmail.trim(), signInPassword);
      onLogin(user);
    } catch (err: any) {
      setErrorMessage(err?.message || 'Invalid email or password.');
    } finally {
      setIsLoading(false);
    }
  };

  const handleSignUpSubmit = async (e: React.FormEvent) => {
    e.preventDefault();
    setErrorMessage(null);

    if (!signUpName.trim()) {
      setErrorMessage('Please enter your full name.');
      return;
    }
    if (!signUpEmail.trim() || !/^[^\s@]+@[^\s@]+\.[^\s@]+$/.test(signUpEmail.trim())) {
      setErrorMessage('Please enter a valid email address.');
      return;
    }
    if (signUpPassword.length < 6) {
      setErrorMessage('Password must be at least 6 characters long.');
      return;
    }
    if (signUpPassword !== signUpConfirmPassword) {
      setErrorMessage('Passwords do not match.');
      return;
    }

    setIsLoading(true);
    try {
      const user = await authService.register({
        name: signUpName.trim(),
        email: signUpEmail.trim(),
        password: signUpPassword,
        phone: signUpPhone.trim() || '9876543210'
      });
      setSuccessMessage('Account created successfully!');
      setTimeout(() => onLogin(user), 300);
    } catch (err: any) {
      setErrorMessage(err?.message || 'Failed to create account.');
    } finally {
      setIsLoading(false);
    }
  };

  const handleQuickPresetFill = (account: PresetAccount) => {
    setSignInEmail(account.email);
    if (account.password) {
      setSignInPassword(account.password);
    }
    setErrorMessage(null);
  };

  const handleSaveClientId = (e: React.FormEvent) => {
    e.preventDefault();
    const trimmed = clientIdInput.trim();
    setGoogleClientId(trimmed);
    localStorage.setItem('medifinder_google_client_id', trimmed);
    setShowClientIdConfig(false);
  };

  return (
    <div className="min-h-screen bg-gradient-to-br from-teal-50/50 via-slate-50 to-emerald-50/30 dark:from-slate-950 dark:via-slate-900 dark:to-teal-950/40 flex items-center justify-center p-4 sm:p-6 animate-fade-in">
      <div className="max-w-md w-full bg-white dark:bg-slate-900 border border-slate-200/90 dark:border-slate-800 rounded-3xl p-6 sm:p-8 space-y-6 shadow-2xl relative overflow-hidden">
        
        {/* Subtle decorative background gradient accent */}
        <div className="absolute -top-20 -right-20 w-40 h-40 bg-[#0bbbb6]/10 rounded-full blur-2xl pointer-events-none" />
        <div className="absolute -bottom-20 -left-20 w-40 h-40 bg-teal-500/10 rounded-full blur-2xl pointer-events-none" />

        {/* Brand Header */}
        <div className="text-center space-y-2 relative z-10">
          <div className="w-16 h-16 rounded-3xl bg-[#e6f8f7] dark:bg-teal-950/80 text-[#0bbbb6] dark:text-teal-400 border border-[#0bbbb6]/30 flex items-center justify-center mx-auto shadow-sm">
            <Pill className="w-8 h-8" />
          </div>

          <div>
            <h1 className="text-2xl sm:text-3xl font-black text-slate-900 dark:text-white tracking-tight">
              MediFinder
            </h1>
            <p className="text-xs sm:text-sm text-slate-500 dark:text-slate-400 font-semibold mt-0.5">
              Secure Medicine Reminders & Pharmacy Network
            </p>
          </div>
        </div>

        {/* Auth Mode Tabs */}
        <div className="grid grid-cols-2 p-1 bg-slate-100 dark:bg-slate-800/80 rounded-2xl relative z-10">
          <button
            type="button"
            onClick={() => { setAuthMode('signin'); setErrorMessage(null); }}
            className={`py-2 text-xs font-bold rounded-xl transition flex items-center justify-center gap-1.5 cursor-pointer ${
              authMode === 'signin'
                ? 'bg-white dark:bg-slate-700 text-slate-900 dark:text-white shadow-xs'
                : 'text-slate-500 dark:text-slate-400 hover:text-slate-900 dark:hover:text-white'
            }`}
          >
            <LogIn className="w-3.5 h-3.5" />
            <span>Sign In</span>
          </button>

          <button
            type="button"
            onClick={() => { setAuthMode('signup'); setErrorMessage(null); }}
            className={`py-2 text-xs font-bold rounded-xl transition flex items-center justify-center gap-1.5 cursor-pointer ${
              authMode === 'signup'
                ? 'bg-white dark:bg-slate-700 text-slate-900 dark:text-white shadow-xs'
                : 'text-slate-500 dark:text-slate-400 hover:text-slate-900 dark:hover:text-white'
            }`}
          >
            <UserPlus className="w-3.5 h-3.5" />
            <span>Create Account</span>
          </button>
        </div>

        {/* Global Error/Success Message */}
        {errorMessage && (
          <div className="p-3 bg-rose-50 dark:bg-rose-950/40 border border-rose-200 dark:border-rose-900/60 rounded-2xl flex items-center gap-2 text-xs font-bold text-rose-600 dark:text-rose-400 animate-fade-in">
            <AlertCircle className="w-4 h-4 shrink-0" />
            <span>{errorMessage}</span>
          </div>
        )}
        {successMessage && (
          <div className="p-3 bg-emerald-50 dark:bg-emerald-950/40 border border-emerald-200 dark:border-emerald-900/60 rounded-2xl flex items-center gap-2 text-xs font-bold text-emerald-600 dark:text-emerald-400 animate-fade-in">
            <Check className="w-4 h-4 shrink-0" />
            <span>{successMessage}</span>
          </div>
        )}

        {/* Continue with Google Section */}
        <div className="space-y-3 relative z-10">
          <button
            type="button"
            onClick={handleContinueWithGoogle}
            disabled={isLoading}
            className="w-full py-3 px-4 bg-white dark:bg-slate-800 hover:bg-slate-50 dark:hover:bg-slate-700/80 border border-slate-300 dark:border-slate-700 rounded-2xl text-xs sm:text-sm font-bold text-slate-700 dark:text-slate-200 shadow-sm hover:shadow transition cursor-pointer flex items-center justify-center gap-3 group"
          >
            <svg className="w-5 h-5 shrink-0" viewBox="0 0 24 24">
              <path fill="#4285F4" d="M22.56 12.25c0-.78-.07-1.53-.2-2.25H12v4.26h5.92c-.26 1.37-1.04 2.53-2.21 3.31v2.77h3.57c2.08-1.92 3.28-4.74 3.28-8.09z" />
              <path fill="#34A853" d="M12 23c2.97 0 5.46-.98 7.28-2.66l-3.57-2.77c-.98.66-2.23 1.06-3.71 1.06-2.86 0-5.29-1.93-6.16-4.53H2.18v2.84C3.99 20.53 7.7 23 12 23z" />
              <path fill="#FBBC05" d="M5.84 14.09c-.22-.66-.35-1.36-.35-2.09s.13-1.43.35-2.09V7.06H2.18C1.43 8.55 1 10.22 1 12s.43 3.45 1.18 4.94l2.85-2.22.81-.63z" />
              <path fill="#EA4335" d="M12 5.38c1.62 0 3.06.56 4.21 1.64l3.15-3.15C17.45 2.09 14.97 1 12 1 7.7 1 3.99 3.47 2.18 7.06l3.66 2.84c.87-2.6 3.3-4.52 6.16-4.52z" />
            </svg>
            <span>Continue with Google</span>
          </button>

          <div className="relative flex items-center justify-center">
            <div className="border-t border-slate-200 dark:border-slate-800 w-full" />
            <span className="bg-white dark:bg-slate-900 px-3 text-[10px] font-bold text-slate-400 uppercase tracking-wider absolute">
              or with email & password
            </span>
          </div>
        </div>

        {/* SIGN IN FORM */}
        {authMode === 'signin' && (
          <form onSubmit={handleSignInSubmit} className="space-y-4 relative z-10" noValidate>
            <div className="space-y-1">
              <label className="block text-xs font-bold text-slate-700 dark:text-slate-300">
                Email Address
              </label>
              <div className="relative">
                <Mail className="w-4 h-4 text-slate-400 absolute left-3.5 top-3.5" />
                <input
                  type="email"
                  required
                  value={signInEmail}
                  onChange={e => setSignInEmail(e.target.value)}
                  placeholder="name@example.com"
                  className="w-full pl-10 pr-4 py-2.5 bg-slate-50 dark:bg-slate-800/80 border border-slate-200 dark:border-slate-700 rounded-2xl text-xs sm:text-sm focus:outline-none focus:ring-2 focus:ring-[#0bbbb6] dark:text-white font-medium"
                />
              </div>
            </div>

            <div className="space-y-1">
              <label className="block text-xs font-bold text-slate-700 dark:text-slate-300">
                Password
              </label>
              <div className="relative">
                <Lock className="w-4 h-4 text-slate-400 absolute left-3.5 top-3.5" />
                <input
                  type={showSignInPassword ? 'text' : 'password'}
                  required
                  value={signInPassword}
                  onChange={e => setSignInPassword(e.target.value)}
                  placeholder="••••••••"
                  className="w-full pl-10 pr-10 py-2.5 bg-slate-50 dark:bg-slate-800/80 border border-slate-200 dark:border-slate-700 rounded-2xl text-xs sm:text-sm focus:outline-none focus:ring-2 focus:ring-[#0bbbb6] dark:text-white font-medium"
                />
                <button
                  type="button"
                  onClick={() => setShowSignInPassword(!showSignInPassword)}
                  className="absolute right-3 top-3 text-slate-400 hover:text-slate-600 dark:hover:text-slate-200 cursor-pointer"
                >
                  {showSignInPassword ? <EyeOff className="w-4 h-4" /> : <Eye className="w-4 h-4" />}
                </button>
              </div>
            </div>

            <button
              type="submit"
              disabled={isLoading}
              className="w-full py-3 bg-[#0bbbb6] hover:bg-[#0aa6a1] disabled:opacity-50 text-white font-extrabold rounded-2xl text-xs sm:text-sm shadow-md hover:shadow-lg active:scale-[0.99] transition cursor-pointer flex items-center justify-center gap-2 mt-2"
            >
              {isLoading ? (
                <div className="w-4 h-4 border-2 border-white border-t-transparent rounded-full animate-spin" />
              ) : (
                <>
                  <span>Sign In</span>
                  <ArrowRight className="w-4 h-4" />
                </>
              )}
            </button>
          </form>
        )}

        {/* SIGN UP FORM */}
        {authMode === 'signup' && (
          <form onSubmit={handleSignUpSubmit} className="space-y-3 relative z-10" noValidate>
            <div className="space-y-1">
              <label className="block text-xs font-bold text-slate-700 dark:text-slate-300">
                Full Name <span className="text-rose-500">*</span>
              </label>
              <div className="relative">
                <User className="w-4 h-4 text-slate-400 absolute left-3.5 top-3.5" />
                <input
                  type="text"
                  required
                  value={signUpName}
                  onChange={e => setSignUpName(e.target.value)}
                  placeholder="e.g. Jane Doe"
                  className="w-full pl-10 pr-4 py-2 bg-slate-50 dark:bg-slate-800/80 border border-slate-200 dark:border-slate-700 rounded-2xl text-xs sm:text-sm focus:outline-none focus:ring-2 focus:ring-[#0bbbb6] dark:text-white font-medium"
                />
              </div>
            </div>

            <div className="space-y-1">
              <label className="block text-xs font-bold text-slate-700 dark:text-slate-300">
                Email Address <span className="text-rose-500">*</span>
              </label>
              <div className="relative">
                <Mail className="w-4 h-4 text-slate-400 absolute left-3.5 top-3.5" />
                <input
                  type="email"
                  required
                  value={signUpEmail}
                  onChange={e => setSignUpEmail(e.target.value)}
                  placeholder="name@example.com"
                  className="w-full pl-10 pr-4 py-2 bg-slate-50 dark:bg-slate-800/80 border border-slate-200 dark:border-slate-700 rounded-2xl text-xs sm:text-sm focus:outline-none focus:ring-2 focus:ring-[#0bbbb6] dark:text-white font-medium"
                />
              </div>
            </div>

            <div className="space-y-1">
              <label className="block text-xs font-bold text-slate-700 dark:text-slate-300">
                Mobile Phone (for medicine reminders)
              </label>
              <div className="relative">
                <Phone className="w-4 h-4 text-slate-400 absolute left-3.5 top-3.5" />
                <input
                  type="tel"
                  value={signUpPhone}
                  onChange={e => setSignUpPhone(e.target.value)}
                  placeholder="e.g. 9876543210"
                  className="w-full pl-10 pr-4 py-2 bg-slate-50 dark:bg-slate-800/80 border border-slate-200 dark:border-slate-700 rounded-2xl text-xs sm:text-sm focus:outline-none focus:ring-2 focus:ring-[#0bbbb6] dark:text-white font-medium"
                />
              </div>
            </div>

            <div className="space-y-1">
              <label className="block text-xs font-bold text-slate-700 dark:text-slate-300">
                Create Password (min 6 characters) <span className="text-rose-500">*</span>
              </label>
              <div className="relative">
                <Lock className="w-4 h-4 text-slate-400 absolute left-3.5 top-3.5" />
                <input
                  type={showSignUpPassword ? 'text' : 'password'}
                  required
                  value={signUpPassword}
                  onChange={e => setSignUpPassword(e.target.value)}
                  placeholder="••••••••"
                  className="w-full pl-10 pr-10 py-2 bg-slate-50 dark:bg-slate-800/80 border border-slate-200 dark:border-slate-700 rounded-2xl text-xs sm:text-sm focus:outline-none focus:ring-2 focus:ring-[#0bbbb6] dark:text-white font-medium"
                />
                <button
                  type="button"
                  onClick={() => setShowSignUpPassword(!showSignUpPassword)}
                  className="absolute right-3 top-3 text-slate-400 hover:text-slate-600 dark:hover:text-slate-200 cursor-pointer"
                >
                  {showSignUpPassword ? <EyeOff className="w-4 h-4" /> : <Eye className="w-4 h-4" />}
                </button>
              </div>
            </div>

            <div className="space-y-1">
              <label className="block text-xs font-bold text-slate-700 dark:text-slate-300">
                Confirm Password <span className="text-rose-500">*</span>
              </label>
              <div className="relative">
                <Lock className="w-4 h-4 text-slate-400 absolute left-3.5 top-3.5" />
                <input
                  type={showSignUpPassword ? 'text' : 'password'}
                  required
                  value={signUpConfirmPassword}
                  onChange={e => setSignUpConfirmPassword(e.target.value)}
                  placeholder="••••••••"
                  className="w-full pl-10 pr-4 py-2 bg-slate-50 dark:bg-slate-800/80 border border-slate-200 dark:border-slate-700 rounded-2xl text-xs sm:text-sm focus:outline-none focus:ring-2 focus:ring-[#0bbbb6] dark:text-white font-medium"
                />
              </div>
            </div>

            <button
              type="submit"
              disabled={isLoading}
              className="w-full py-3 bg-[#0bbbb6] hover:bg-[#0aa6a1] disabled:opacity-50 text-white font-extrabold rounded-2xl text-xs sm:text-sm shadow-md hover:shadow-lg active:scale-[0.99] transition cursor-pointer flex items-center justify-center gap-2 mt-2"
            >
              {isLoading ? (
                <div className="w-4 h-4 border-2 border-white border-t-transparent rounded-full animate-spin" />
              ) : (
                <>
                  <span>Create Account</span>
                  <ArrowRight className="w-4 h-4" />
                </>
              )}
            </button>
          </form>
        )}

        <div className="flex items-center justify-center gap-1.5 text-[10px] text-slate-400 font-semibold text-center">
          <ShieldCheck className="w-3.5 h-3.5 text-emerald-500" />
          <span>Secure Firebase Authentication • Protected</span>
        </div>

      </div>

      {/* GOOGLE ACCOUNTS SELECTION / FIREBASE MODAL */}
      {showGoogleModal && (
        <div className="fixed inset-0 z-50 flex items-center justify-center p-4 bg-slate-900/60 backdrop-blur-xs animate-fade-in">
          <div className="bg-white dark:bg-slate-900 border border-slate-200 dark:border-slate-800 rounded-3xl max-w-md w-full p-6 shadow-2xl relative space-y-5 animate-scale-up max-h-[90vh] overflow-y-auto">
            
            <button
              onClick={() => setShowGoogleModal(false)}
              className="absolute right-4 top-4 p-1.5 text-slate-400 hover:text-slate-600 dark:hover:text-slate-200 rounded-full hover:bg-slate-100 dark:hover:bg-slate-800 transition cursor-pointer"
            >
              <X className="w-5 h-5" />
            </button>

            <div className="text-center space-y-2 pt-1">
              <div className="w-12 h-12 rounded-full bg-slate-100 dark:bg-slate-800 flex items-center justify-center mx-auto shadow-inner">
                <svg className="w-7 h-7" viewBox="0 0 24 24">
                  <path fill="#4285F4" d="M22.56 12.25c0-.78-.07-1.53-.2-2.25H12v4.26h5.92c-.26 1.37-1.04 2.53-2.21 3.31v2.77h3.57c2.08-1.92 3.28-4.74 3.28-8.09z" />
                  <path fill="#34A853" d="M12 23c2.97 0 5.46-.98 7.28-2.66l-3.57-2.77c-.98.66-2.23 1.06-3.71 1.06-2.86 0-5.29-1.93-6.16-4.53H2.18v2.84C3.99 20.53 7.7 23 12 23z" />
                  <path fill="#FBBC05" d="M5.84 14.09c-.22-.66-.35-1.36-.35-2.09s.13-1.43.35-2.09V7.06H2.18C1.43 8.55 1 10.22 1 12s.43 3.45 1.18 4.94l2.85-2.22.81-.63z" />
                  <path fill="#EA4335" d="M12 5.38c1.62 0 3.06.56 4.21 1.64l3.15-3.15C17.45 2.09 14.97 1 12 1 7.7 1 3.99 3.47 2.18 7.06l3.66 2.84c.87-2.6 3.3-4.52 6.16-4.52z" />
                </svg>
              </div>

              <h2 className="text-lg font-bold text-slate-900 dark:text-white">
                Google Authentication
              </h2>
              <p className="text-xs text-slate-500 dark:text-slate-400 font-medium">
                Choose an option to continue to <strong className="text-slate-800 dark:text-slate-200">MediFinder</strong>
              </p>
            </div>

            {/* Real Firebase Google Popup Button (when configured) */}
            {isFirebase ? (
              <div className="p-4 bg-emerald-50 dark:bg-emerald-950/30 border border-emerald-200 dark:border-emerald-900/60 rounded-2xl text-center space-y-2">
                <div className="flex items-center justify-center gap-1.5 text-xs font-bold text-emerald-700 dark:text-emerald-300">
                  <Flame className="w-4 h-4 text-amber-500 fill-amber-500" />
                  <span>Firebase Project Connected: <code>{firebaseCfg?.projectId}</code></span>
                </div>
                <button
                  type="button"
                  onClick={handleContinueWithGoogle}
                  disabled={isLoading}
                  className="w-full py-2.5 px-4 bg-[#0bbbb6] hover:bg-[#0aa6a1] text-white font-bold rounded-xl text-xs transition cursor-pointer shadow-sm flex items-center justify-center gap-2"
                >
                  <svg className="w-4 h-4" viewBox="0 0 24 24">
                    <path fill="#ffffff" d="M22.56 12.25c0-.78-.07-1.53-.2-2.25H12v4.26h5.92c-.26 1.37-1.04 2.53-2.21 3.31v2.77h3.57c2.08-1.92 3.28-4.74 3.28-8.09z" />
                    <path fill="#ffffff" d="M12 23c2.97 0 5.46-.98 7.28-2.66l-3.57-2.77c-.98.66-2.23 1.06-3.71 1.06-2.86 0-5.29-1.93-6.16-4.53H2.18v2.84C3.99 20.53 7.7 23 12 23z" />
                    <path fill="#ffffff" d="M5.84 14.09c-.22-.66-.35-1.36-.35-2.09s.13-1.43.35-2.09V7.06H2.18C1.43 8.55 1 10.22 1 12s.43 3.45 1.18 4.94l2.85-2.22.81-.63z" />
                    <path fill="#ffffff" d="M12 5.38c1.62 0 3.06.56 4.21 1.64l3.15-3.15C17.45 2.09 14.97 1 12 1 7.7 1 3.99 3.47 2.18 7.06l3.66 2.84c.87-2.6 3.3-4.52 6.16-4.52z" />
                  </svg>
                  <span>Open Real Google Popup</span>
                </button>
              </div>
            ) : (
              /* Notice encouraging Firebase connection */
              <div className="p-3.5 bg-amber-50 dark:bg-amber-950/40 border border-amber-200 dark:border-amber-900/60 rounded-2xl text-left space-y-2">
                <div className="flex items-center gap-2 text-xs font-bold text-amber-800 dark:text-amber-300">
                  <Flame className="w-4 h-4 text-amber-500 shrink-0" />
                  <span>Connect Firebase for Real Google Sign-in</span>
                </div>
                <p className="text-[11px] text-amber-700/90 dark:text-amber-300/80 leading-relaxed">
                  Firebase gives you genuine Google account popups and secure cloud auth. You can connect your Firebase project in 10 seconds below or use quick test accounts.
                </p>
                <button
                  type="button"
                  onClick={() => { setShowGoogleModal(false); setShowFirebaseModal(true); }}
                  className="w-full py-2 px-3 bg-amber-500 hover:bg-amber-600 text-white font-bold rounded-xl text-xs transition cursor-pointer flex items-center justify-center gap-1.5"
                >
                  <Key className="w-3.5 h-3.5" />
                  <span>Configure Firebase Keys</span>
                </button>
              </div>
            )}

            {/* Quick Test Accounts */}
            <div className="space-y-2">
              <div className="text-[11px] font-bold text-slate-500 dark:text-slate-400 uppercase tracking-wider">
                Quick Test Accounts:
              </div>
              <div className="space-y-2 max-h-48 overflow-y-auto pr-1">
                {PRESET_ACCOUNTS.map((acc) => (
                  <button
                    key={acc.email}
                    onClick={() => handleGoogleAccountSelect(acc)}
                    disabled={isLoading}
                    className="w-full p-2.5 rounded-2xl border border-slate-200 dark:border-slate-800 hover:border-[#0bbbb6]/60 dark:hover:border-teal-500/60 hover:bg-slate-50 dark:hover:bg-slate-800/60 transition flex items-center justify-between text-left group cursor-pointer"
                  >
                    <div className="flex items-center gap-2.5">
                      <div className={`w-8 h-8 rounded-full ${acc.avatarColor} text-white font-extrabold flex items-center justify-center text-xs shadow-xs shrink-0`}>
                        {acc.name.charAt(0)}
                      </div>
                      <div className="overflow-hidden">
                        <div className="text-xs font-bold text-slate-900 dark:text-white group-hover:text-[#0bbbb6] transition truncate">
                          {acc.name}
                        </div>
                        <div className="text-[10px] text-slate-500 dark:text-slate-400 truncate">
                          {acc.email}
                        </div>
                      </div>
                    </div>

                    <ArrowRight className="w-4 h-4 text-slate-300 group-hover:text-[#0bbbb6] transition shrink-0" />
                  </button>
                ))}

                {/* Add / Use Another Account option */}
                {!showAddGoogleInput ? (
                  <button
                    type="button"
                    onClick={() => setShowAddGoogleInput(true)}
                    className="w-full p-2.5 rounded-2xl border border-dashed border-slate-300 dark:border-slate-700 hover:border-[#0bbbb6] text-slate-600 dark:text-slate-300 hover:text-[#0bbbb6] text-xs font-bold transition flex items-center gap-2.5 cursor-pointer"
                  >
                    <div className="w-8 h-8 rounded-full bg-slate-100 dark:bg-slate-800 flex items-center justify-center text-slate-500 dark:text-slate-400 shrink-0">
                      <Plus className="w-4 h-4" />
                    </div>
                    <span>Enter custom Google email</span>
                  </button>
                ) : (
                  <form onSubmit={handleCustomGoogleSubmit} className="p-3 bg-slate-50 dark:bg-slate-800/60 rounded-2xl border border-slate-200 dark:border-slate-700 space-y-2 animate-fade-in">
                    <div className="text-[11px] font-bold text-slate-700 dark:text-slate-300">Custom Google Profile:</div>
                    <input
                      type="text"
                      required
                      placeholder="Full Name (e.g. John Doe)"
                      value={customGoogleName}
                      onChange={e => setCustomGoogleName(e.target.value)}
                      className="w-full px-3 py-2 bg-white dark:bg-slate-900 border border-slate-200 dark:border-slate-700 rounded-xl text-xs font-medium dark:text-white"
                    />
                    <input
                      type="email"
                      required
                      placeholder="Email address (e.g. john@gmail.com)"
                      value={customGoogleEmail}
                      onChange={e => setCustomGoogleEmail(e.target.value)}
                      className="w-full px-3 py-2 bg-white dark:bg-slate-900 border border-slate-200 dark:border-slate-700 rounded-xl text-xs font-medium dark:text-white"
                    />
                    <div className="flex items-center gap-2 pt-1">
                      <button
                        type="submit"
                        disabled={isLoading}
                        className="flex-1 py-2 bg-[#0bbbb6] hover:bg-[#0aa6a1] text-white font-bold rounded-xl text-xs transition cursor-pointer disabled:opacity-50"
                      >
                        {isLoading ? 'Signing In...' : 'Sign In'}
                      </button>
                      <button
                        type="button"
                        onClick={() => setShowAddGoogleInput(false)}
                        className="px-3 py-2 bg-slate-200 dark:bg-slate-700 text-slate-700 dark:text-slate-200 font-bold rounded-xl text-xs transition cursor-pointer"
                      >
                        Cancel
                      </button>
                    </div>
                  </form>
                )}
              </div>
            </div>

            {/* Official Google Identity Services Button (rendered when Client ID is set) */}
            {googleClientId && (
              <div className="pt-1 flex flex-col items-center justify-center space-y-1">
                <div ref={googleBtnContainerRef} className="flex justify-center w-full" />
              </div>
            )}

            <div className="pt-2 border-t border-slate-100 dark:border-slate-800 text-center space-y-2">
              <button
                type="button"
                onClick={() => { setShowGoogleModal(false); setShowFirebaseModal(true); }}
                className="text-[11px] text-[#0bbbb6] hover:underline font-bold flex items-center justify-center gap-1.5 mx-auto cursor-pointer"
              >
                <Flame className="w-3.5 h-3.5 text-amber-500" />
                <span>{isFirebase ? 'Manage Firebase Configuration' : 'Connect Firebase for Real Google Auth'}</span>
              </button>
            </div>

          </div>
        </div>
      )}

      {/* FIREBASE CONFIGURATION MODAL */}
      {showFirebaseModal && (
        <div className="fixed inset-0 z-50 flex items-center justify-center p-4 bg-slate-900/60 backdrop-blur-xs animate-fade-in">
          <div className="bg-white dark:bg-slate-900 border border-slate-200 dark:border-slate-800 rounded-3xl max-w-md w-full p-6 shadow-2xl relative space-y-5 animate-scale-up max-h-[90vh] overflow-y-auto">
            
            <button
              onClick={() => setShowFirebaseModal(false)}
              className="absolute right-4 top-4 p-1.5 text-slate-400 hover:text-slate-600 dark:hover:text-slate-200 rounded-full hover:bg-slate-100 dark:hover:bg-slate-800 transition cursor-pointer"
            >
              <X className="w-5 h-5" />
            </button>

            <div className="text-center space-y-2 pt-1">
              <div className="w-12 h-12 rounded-full bg-amber-50 dark:bg-amber-950/40 border border-amber-200 dark:border-amber-800/60 flex items-center justify-center mx-auto shadow-inner">
                <Flame className="w-6 h-6 text-amber-500" />
              </div>

              <h2 className="text-lg font-bold text-slate-900 dark:text-white">
                Firebase Authentication Setup
              </h2>
              <p className="text-xs text-slate-500 dark:text-slate-400 font-medium">
                Connect your Firebase project for genuine Google Popup and cloud authentication.
              </p>
            </div>

            {isFirebase && (
              <div className="p-3 bg-emerald-50 dark:bg-emerald-950/40 border border-emerald-200 dark:border-emerald-900/60 rounded-2xl text-xs space-y-1">
                <div className="font-bold text-emerald-700 dark:text-emerald-300 flex items-center gap-1.5">
                  <Check className="w-4 h-4 text-emerald-600" />
                  <span>Firebase is Currently Connected!</span>
                </div>
                <div className="text-[11px] text-emerald-800 dark:text-emerald-400">
                  Project: <strong>{firebaseCfg?.projectId}</strong>
                </div>
              </div>
            )}

            {/* Quick 1-Click Paste from Firebase Console */}
            <form onSubmit={handleSaveFirebaseSettings} className="space-y-4">
              <div className="space-y-1.5 text-left">
                <label className="block text-xs font-bold text-slate-700 dark:text-slate-300">
                  Paste Firebase Config (JSON or JavaScript code snippet):
                </label>
                <textarea
                  rows={4}
                  value={fbPasteText}
                  onChange={e => setFbPasteText(e.target.value)}
                  placeholder={'const firebaseConfig = {\n  apiKey: "AIzaSy...",\n  authDomain: "your-app.firebaseapp.com",\n  projectId: "your-app",\n  appId: "1:..."\n};'}
                  className="w-full p-3 bg-slate-50 dark:bg-slate-800 border border-slate-200 dark:border-slate-700 rounded-xl text-xs font-mono text-slate-800 dark:text-slate-200 focus:outline-none focus:ring-2 focus:ring-[#0bbbb6]"
                />
                <p className="text-[10px] text-slate-400">
                  Copy from Firebase Console &gt; Project Settings &gt; General &gt; Your apps &gt; SDK setup and configuration.
                </p>
              </div>

              <div className="relative flex items-center justify-center">
                <div className="border-t border-slate-200 dark:border-slate-800 w-full" />
                <span className="bg-white dark:bg-slate-900 px-3 text-[10px] font-bold text-slate-400 uppercase tracking-wider absolute">
                  or enter keys manually
                </span>
              </div>

              <div className="space-y-2 text-left">
                <div>
                  <label className="block text-[11px] font-bold text-slate-700 dark:text-slate-300 mb-1">
                    API Key (apiKey):
                  </label>
                  <input
                    type="text"
                    value={fbApiKey}
                    onChange={e => setFbApiKey(e.target.value)}
                    placeholder="AIzaSy..."
                    className="w-full px-3 py-1.5 bg-slate-50 dark:bg-slate-800 border border-slate-200 dark:border-slate-700 rounded-xl text-xs font-mono dark:text-white"
                  />
                </div>

                <div>
                  <label className="block text-[11px] font-bold text-slate-700 dark:text-slate-300 mb-1">
                    Project ID (projectId):
                  </label>
                  <input
                    type="text"
                    value={fbProjectId}
                    onChange={e => setFbProjectId(e.target.value)}
                    placeholder="medifinder-app"
                    className="w-full px-3 py-1.5 bg-slate-50 dark:bg-slate-800 border border-slate-200 dark:border-slate-700 rounded-xl text-xs font-mono dark:text-white"
                  />
                </div>

                <div>
                  <label className="block text-[11px] font-bold text-slate-700 dark:text-slate-300 mb-1">
                    Auth Domain (authDomain):
                  </label>
                  <input
                    type="text"
                    value={fbAuthDomain}
                    onChange={e => setFbAuthDomain(e.target.value)}
                    placeholder="medifinder-app.firebaseapp.com"
                    className="w-full px-3 py-1.5 bg-slate-50 dark:bg-slate-800 border border-slate-200 dark:border-slate-700 rounded-xl text-xs font-mono dark:text-white"
                  />
                </div>

                <div>
                  <label className="block text-[11px] font-bold text-slate-700 dark:text-slate-300 mb-1">
                    App ID (appId):
                  </label>
                  <input
                    type="text"
                    value={fbAppId}
                    onChange={e => setFbAppId(e.target.value)}
                    placeholder="1:123456789:web:abcdef"
                    className="w-full px-3 py-1.5 bg-slate-50 dark:bg-slate-800 border border-slate-200 dark:border-slate-700 rounded-xl text-xs font-mono dark:text-white"
                  />
                </div>
              </div>

              <div className="flex items-center gap-2 pt-2">
                <button
                  type="submit"
                  className="flex-1 py-2.5 bg-[#0bbbb6] hover:bg-[#0aa6a1] text-white font-bold rounded-xl text-xs transition cursor-pointer flex items-center justify-center gap-2 shadow-sm"
                >
                  <Check className="w-4 h-4" />
                  <span>Save &amp; Connect Firebase</span>
                </button>

                {isFirebase && (
                  <button
                    type="button"
                    onClick={handleClearFirebase}
                    className="px-3 py-2.5 text-rose-500 hover:bg-rose-50 dark:hover:bg-rose-950/30 rounded-xl text-xs font-bold transition cursor-pointer border border-rose-200 dark:border-rose-900/50"
                  >
                    Disconnect
                  </button>
                )}
              </div>
            </form>

            <div className="p-3 bg-slate-50 dark:bg-slate-800/60 rounded-2xl text-[10px] text-slate-500 dark:text-slate-400 text-left space-y-1">
              <div className="font-bold text-slate-700 dark:text-slate-300">Firebase Setup Checklist:</div>
              <ol className="list-decimal pl-4 space-y-0.5">
                <li>Go to <a href="https://console.firebase.google.com" target="_blank" rel="noreferrer" className="text-[#0bbbb6] underline">console.firebase.google.com</a></li>
                <li>Enable <strong>Google</strong> &amp; <strong>Email/Password</strong> under Authentication &gt; Sign-in method</li>
                <li>Confirm <code>localhost</code> is listed under Authentication &gt; Settings &gt; Authorized domains</li>
              </ol>
            </div>

          </div>
        </div>
      )}
    </div>
  );
}

