import React, { useState, useEffect, useRef } from 'react';
import { 
  Search, 
  MapPin, 
  Phone, 
  CheckCircle2, 
  AlertCircle, 
  XCircle, 
  Navigation,
  Pill,
  Filter,
  LocateFixed,
  Layers,
  Compass,
  Radio,
  Check,
  Edit3,
  ExternalLink,
  Sliders,
  HelpCircle,
  RefreshCw,
  Building2,
  Car,
  Star,
  Sparkles,
  Maximize2
} from 'lucide-react';
import { PharmacyStore } from '../services/store';
import { Pharmacy } from '../types';
import { 
  calculateDistanceKm, 
  calculateTravelTime, 
  reverseGeocode, 
  geocodeCityOrPincode, 
  fetchRealNearbyPharmaciesOSM,
  getGoogleMapsNavigationUrl,
  isValidCoordinate,
  CITY_PRESETS,
  CityPreset,
  getLiveNearbyPharmacies,
  getLastKnownUserLocation,
  saveLastKnownUserLocation
} from '../services/locationService';
import { findLocalMedicine, findMedicineAlternatives, MedicineInfo } from '../data/medicineDatabase';
import GoogleMapsView from './GoogleMapsView';

interface MedicineSearchProps {
  onSelectPharmacyForNav?: (ph: Pharmacy) => void;
  onNavigateToConnect?: () => void;
  initialQuery?: string;
}

const RADIUS_OPTIONS = [5, 10, 15, 20, 50];

const POPULAR_MEDICINES = [
  'Dolo 650',
  'Paracetamol',
  'Amoxicillin',
  'Amlodipine',
  'Metformin',
  'Azithromycin',
  'Pantoprazole',
  'Cetirizine',
  'Ibuprofen'
];

export default function MedicineSearch({ onSelectPharmacyForNav, onNavigateToConnect, initialQuery = '' }: MedicineSearchProps) {
  const [pharmacies, setPharmacies] = useState<Pharmacy[]>([]);
  const [query, setQuery] = useState(initialQuery);

  useEffect(() => {
    if (initialQuery) {
      setQuery(initialQuery);
    }
  }, [initialQuery]);
  const [selectedRadius, setSelectedRadius] = useState<number>(5); // Default radius: 5 km
  const [filterInStockOnly, setFilterInStockOnly] = useState(false);
  const [viewMode, setViewMode] = useState<'both' | 'list' | 'map'>('both');
  const [selectedPharmacyId, setSelectedPharmacyId] = useState<string | null>(null);

  // Geolocation & Status State (restores cached location if available)
  const [userCoords, setUserCoords] = useState<{ lat: number; lng: number } | null>(() => {
    const cached = getLastKnownUserLocation();
    return cached ? cached.coords : null;
  });
  const [detectedAddress, setDetectedAddress] = useState<string>(() => {
    const cached = getLastKnownUserLocation();
    return cached ? cached.address : '';
  });
  const [localityName, setLocalityName] = useState<string>(() => {
    const cached = getLastKnownUserLocation();
    return cached ? cached.city : 'Srikakulam';
  });
  const [gpsAccuracy, setGpsAccuracy] = useState<number | null>(null);
  const [locationStatus, setLocationStatus] = useState<'detecting' | 'confirmed' | 'denied' | 'unavailable' | 'manual'>(() => {
    const cached = getLastKnownUserLocation();
    return cached ? 'confirmed' : 'detecting';
  });
  const [locationError, setLocationError] = useState<string | null>(null);
  const [isFetchingOSM, setIsFetchingOSM] = useState<boolean>(false);

  // Manual city / PIN code entry
  const [isEditingLocation, setIsEditingLocation] = useState<boolean>(false);
  const [customAddressInput, setCustomAddressInput] = useState<string>('');
  const [isGeocodingManual, setIsGeocodingManual] = useState<boolean>(false);

  const watchIdRef = useRef<number | null>(null);
  const cardRefs = useRef<{ [key: string]: HTMLDivElement | null }>({});

  // 1. Initial Load & Live Location Detection
  useEffect(() => {
    detectGPSLocation();

    if (typeof navigator !== 'undefined' && 'geolocation' in navigator) {
      try {
        watchIdRef.current = navigator.geolocation.watchPosition(
          async (pos) => {
            const { latitude, longitude, accuracy } = pos.coords;
            setUserCoords({ lat: latitude, lng: longitude });
            setGpsAccuracy(Math.round(accuracy));
            
            const addrResult = await reverseGeocode(latitude, longitude);
            setDetectedAddress(addrResult.address);
            if (addrResult.city) setLocalityName(addrResult.city);
            setLocationStatus('confirmed');
            setLocationError(null);
            saveLastKnownUserLocation({ lat: latitude, lng: longitude }, addrResult.address, addrResult.city || 'Local');
          },
          () => {},
          { enableHighAccuracy: true, timeout: 15000, maximumAge: 10000 }
        );
      } catch {}
    }

    return () => {
      if (watchIdRef.current !== null && typeof navigator !== 'undefined' && 'geolocation' in navigator) {
        navigator.geolocation.clearWatch(watchIdRef.current);
      }
    };
  }, []);

  // 2. Fetch / Generate real nearby pharmacies whenever userCoords change
  useEffect(() => {
    if (!userCoords) return;

    let isMounted = true;
    async function loadNearbyStores() {
      setIsFetchingOSM(true);
      const liveStores = await getLiveNearbyPharmacies(userCoords!.lat, userCoords!.lng, localityName, 25);
      if (!isMounted) return;
      setPharmacies(liveStores);
      setIsFetchingOSM(false);
    }

    loadNearbyStores();

    return () => {
      isMounted = false;
    };
  }, [userCoords, localityName]);

  // Detect GPS Location function
  const detectGPSLocation = () => {
    if (typeof navigator === 'undefined' || !('geolocation' in navigator)) {
      setLocationStatus('unavailable');
      setLocationError('Geolocation is not supported by your browser.');
      return;
    }

    setLocationStatus('detecting');
    setLocationError(null);

    navigator.geolocation.getCurrentPosition(
      async (position) => {
        const { latitude, longitude, accuracy } = position.coords;
        setUserCoords({ lat: latitude, lng: longitude });
        setGpsAccuracy(Math.round(accuracy));

        const addrResult = await reverseGeocode(latitude, longitude);
        setDetectedAddress(addrResult.address);
        if (addrResult.city) setLocalityName(addrResult.city);
        setLocationStatus('confirmed');
        saveLastKnownUserLocation({ lat: latitude, lng: longitude }, addrResult.address, addrResult.city || 'Local');
      },
      (error) => {
        if (error.code === error.PERMISSION_DENIED) {
          setLocationStatus('denied');
          setLocationError('Location permission required to detect live nearby pharmacies.');
        } else {
          setLocationStatus('unavailable');
          setLocationError('GPS signal unavailable. Please select your city or enter a PIN code.');
        }

        if (!userCoords) {
          const cached = getLastKnownUserLocation();
          if (cached) {
            setUserCoords(cached.coords);
            setDetectedAddress(cached.address);
            setLocalityName(cached.city);
          } else {
            setUserCoords({ lat: 18.2969, lng: 83.8967 });
            setDetectedAddress('Seven Roads Junction, Srikakulam, Andhra Pradesh 532001');
            setLocalityName('Srikakulam');
          }
        }
      },
      { enableHighAccuracy: true, timeout: 10000, maximumAge: 0 }
    );
  };

  // Handle manual city selection or PIN code entry
  const handleSelectCityPreset = (preset: CityPreset) => {
    setUserCoords({ lat: preset.lat, lng: preset.lng });
    setDetectedAddress(preset.address);
    setLocalityName(preset.name);
    setLocationStatus('manual');
    setLocationError(null);
    setGpsAccuracy(null);
    setIsEditingLocation(false);
    saveLastKnownUserLocation({ lat: preset.lat, lng: preset.lng }, preset.address, preset.name);
  };

  const handleManualAddressSubmit = async (e: React.FormEvent) => {
    e.preventDefault();
    if (!customAddressInput.trim()) return;

    setIsGeocodingManual(true);
    const geocoded = await geocodeCityOrPincode(customAddressInput.trim());
    setIsGeocodingManual(false);

    if (geocoded) {
      setUserCoords({ lat: geocoded.lat, lng: geocoded.lng });
      setDetectedAddress(geocoded.address);
      setLocalityName(geocoded.name);
      setLocationStatus('manual');
      setLocationError(null);
      setGpsAccuracy(null);
      setIsEditingLocation(false);
      saveLastKnownUserLocation({ lat: geocoded.lat, lng: geocoded.lng }, geocoded.address, geocoded.name);
    } else {
      setDetectedAddress(customAddressInput.trim());
      setLocalityName(customAddressInput.trim());
      setLocationStatus('manual');
      setIsEditingLocation(false);
    }
  };

  // Active Coordinates (defaults to Srikakulam center if none)
  const activeCoords = userCoords || { lat: 18.2969, lng: 83.8967 };

  // Compute live distances for all pharmacies relative to activeCoords
  const pharmaciesWithDistance = pharmacies.map(ph => {
    const computedDistance = calculateDistanceKm(activeCoords.lat, activeCoords.lng, ph.lat, ph.lng);
    const travelTime = calculateTravelTime(computedDistance);
    return {
      ...ph,
      computedDistance: computedDistance || ph.distanceKm,
      travelTime
    };
  });

  // Check medicine database verification & alternatives
  const verifiedMed = query.trim() ? findLocalMedicine(query.trim()) : null;
  const medicineAlternatives = query.trim() ? findMedicineAlternatives(query.trim()) : [];

  // Filter function by radius and query
  const filterByRadius = (radiusKm: number) => {
    const q = query.trim().toLowerCase();
    const isSearching = q.length > 0;

    return pharmaciesWithDistance.filter(ph => {
      // Distance filter
      if (ph.computedDistance > radiusKm) return false;

      // Query filter
      if (isSearching) {
        const nameMatch = ph.name.toLowerCase().includes(q) || ph.address.toLowerCase().includes(q) || ph.city.toLowerCase().includes(q);
        const medMatch = ph.medicines.some(m => {
          const mMatch = m.name.toLowerCase().includes(q) || m.genericName.toLowerCase().includes(q);
          if (!mMatch) return false;
          if (filterInStockOnly) return m.stockStatus === 'In Stock' || m.stockStatus === 'Low Stock';
          return true;
        });

        if (!nameMatch && !medMatch) return false;
      } else if (filterInStockOnly) {
        const hasStock = ph.medicines.some(m => m.stockStatus === 'In Stock' || m.stockStatus === 'Low Stock');
        if (!hasStock) return false;
      }

      return true;
    });
  };

  // 3. AUTO-RADIUS EXPANSION ENGINE
  let initialMatches = filterByRadius(selectedRadius);
  let effectiveRadius = selectedRadius;
  let isAutoExpanded = false;

  if (initialMatches.length === 0) {
    const largerRadii = RADIUS_OPTIONS.filter(r => r > selectedRadius);
    for (const nextR of largerRadii) {
      const expandedMatches = filterByRadius(nextR);
      if (expandedMatches.length > 0) {
        initialMatches = expandedMatches;
        effectiveRadius = nextR;
        isAutoExpanded = true;
        break;
      }
    }
  }

  // Sort by nearest distance
  const sortedNearbyPharmacies = initialMatches.sort((a, b) => a.computedDistance - b.computedDistance);

  // Handle marker selection -> scroll to card
  const handleMarkerClick = (phId: string) => {
    setSelectedPharmacyId(phId);
    if (cardRefs.current[phId]) {
      cardRefs.current[phId]?.scrollIntoView({ behavior: 'smooth', block: 'center' });
    }
  };

  return (
    <div className="space-y-6 pb-20 md:pb-8 animate-fade-in max-w-5xl mx-auto">
      
      {/* 1. LOCATION PERMISSION DENIED BANNER */}
      {locationStatus === 'denied' && (
        <div className="bg-rose-50 dark:bg-rose-950/40 border-2 border-rose-400 dark:border-rose-800 rounded-3xl p-5 sm:p-6 shadow-md space-y-4 animate-fade-in">
          <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-4">
            <div className="flex items-start gap-3">
              <div className="w-10 h-10 rounded-2xl bg-rose-500/20 text-rose-600 dark:text-rose-400 flex items-center justify-center shrink-0 font-bold">
                <AlertCircle className="w-5 h-5 animate-bounce" />
              </div>
              <div className="space-y-1">
                <h3 className="text-sm sm:text-base font-black text-rose-900 dark:text-rose-200">
                  Location permission required to find nearby pharmacies.
                </h3>
                <p className="text-xs text-rose-700 dark:text-rose-300 font-medium">
                  Please grant device location access in your browser, or manually select your city or PIN code below to search nearest pharmacies.
                </p>
              </div>
            </div>

            <button
              onClick={detectGPSLocation}
              className="px-4 py-2.5 bg-rose-600 hover:bg-rose-700 text-white rounded-2xl text-xs font-black transition cursor-pointer shadow-xs flex items-center justify-center gap-2 shrink-0 self-start sm:self-auto"
            >
              <RefreshCw className="w-4 h-4" />
              <span>Retry GPS Location</span>
            </button>
          </div>

          <div className="pt-3 border-t border-rose-200 dark:border-rose-900/60 space-y-2">
            <span className="text-xs font-bold text-slate-700 dark:text-slate-200">
              Or manually select a City or enter PIN code:
            </span>
            <div className="flex flex-wrap items-center gap-1.5">
              {CITY_PRESETS.map((city) => (
                <button
                  key={city.name}
                  onClick={() => handleSelectCityPreset(city)}
                  className="px-3 py-1.5 bg-white dark:bg-slate-800 hover:bg-slate-100 dark:hover:bg-slate-700 text-slate-700 dark:text-slate-200 border border-slate-300 dark:border-slate-700 rounded-xl text-xs font-bold transition cursor-pointer"
                >
                  {city.name} ({city.pincode})
                </button>
              ))}
            </div>
          </div>
        </div>
      )}

      {/* 2. GPS UNAVAILABLE BANNER */}
      {locationStatus === 'unavailable' && (
        <div className="bg-amber-50 dark:bg-amber-950/40 border-2 border-amber-400 dark:border-amber-800 rounded-3xl p-5 sm:p-6 shadow-md space-y-4 animate-fade-in">
          <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-4">
            <div className="flex items-start gap-3">
              <div className="w-10 h-10 rounded-2xl bg-amber-500/20 text-amber-600 dark:text-amber-400 flex items-center justify-center shrink-0 font-bold">
                <Compass className="w-5 h-5 animate-pulse" />
              </div>
              <div className="space-y-1">
                <h3 className="text-sm sm:text-base font-black text-amber-900 dark:text-amber-200">
                  GPS location signal unavailable
                </h3>
                <p className="text-xs text-amber-700 dark:text-amber-300 font-medium">
                  {locationError || 'Could not acquire device coordinates. Select a city or enter your PIN code to calculate distances.'}
                </p>
              </div>
            </div>

            <button
              onClick={detectGPSLocation}
              className="px-4 py-2.5 bg-amber-600 hover:bg-amber-700 text-white rounded-2xl text-xs font-black transition cursor-pointer shadow-xs flex items-center justify-center gap-2 shrink-0 self-start sm:self-auto"
            >
              <LocateFixed className="w-4 h-4" />
              <span>Retry GPS</span>
            </button>
          </div>

          <div className="pt-3 border-t border-amber-200 dark:border-amber-900/60 space-y-2">
            <span className="text-xs font-bold text-slate-700 dark:text-slate-200">
              Select your city or enter PIN code:
            </span>
            <div className="flex flex-wrap items-center gap-1.5">
              {CITY_PRESETS.map((city) => (
                <button
                  key={city.name}
                  onClick={() => handleSelectCityPreset(city)}
                  className="px-3 py-1.5 bg-white dark:bg-slate-800 hover:bg-slate-100 dark:hover:bg-slate-700 text-slate-700 dark:text-slate-200 border border-slate-300 dark:border-slate-700 rounded-xl text-xs font-bold transition cursor-pointer"
                >
                  {city.name} ({city.pincode})
                </button>
              ))}
            </div>
          </div>
        </div>
      )}

      {/* 3. MAIN LOCATION STATUS & REAL-TIME CONTROLS BAR */}
      <div className="bg-white dark:bg-slate-900 border border-slate-200/90 dark:border-slate-800 rounded-3xl p-4 sm:p-5 shadow-xs transition-all">
        <div className="flex flex-col lg:flex-row lg:items-center justify-between gap-4">
          
          {/* Left: Location Pin & Address Details */}
          <div className="flex items-center gap-3.5 min-w-0">
            <div className="relative shrink-0">
              <div className="w-11 h-11 rounded-2xl bg-teal-50 dark:bg-teal-950/40 text-[#0bbbb6] border border-[#0bbbb6]/30 flex items-center justify-center shadow-2xs">
                <MapPin className="w-5 h-5 text-[#0bbbb6]" />
              </div>
              <span className={`absolute -bottom-0.5 -right-0.5 w-3 h-3 border-2 border-white dark:border-slate-900 rounded-full ${
                locationStatus === 'confirmed' 
                  ? 'bg-emerald-500 ring-2 ring-emerald-400/30' 
                  : locationStatus === 'manual'
                  ? 'bg-blue-500 ring-2 ring-blue-400/30'
                  : 'bg-amber-500 animate-ping'
              }`} />
            </div>

            <div className="min-w-0 space-y-0.5">
              <div className="flex flex-wrap items-center gap-2">
                <span className="text-xs sm:text-sm font-black text-slate-900 dark:text-white truncate">
                  {localityName || 'Your Location'}
                </span>

                <span className={`inline-flex items-center gap-1 px-2.5 py-0.5 rounded-full text-[11px] font-bold border ${
                  locationStatus === 'confirmed' 
                    ? 'bg-emerald-50 text-emerald-700 dark:bg-emerald-950/60 dark:text-emerald-300 border-emerald-200 dark:border-emerald-800/60'
                    : locationStatus === 'manual'
                    ? 'bg-blue-50 text-blue-700 dark:bg-blue-950/60 dark:text-blue-300 border-blue-200 dark:border-blue-800/60'
                    : locationStatus === 'detecting'
                    ? 'bg-teal-50 text-teal-700 dark:bg-teal-950/60 dark:text-teal-300 border-teal-200 dark:border-teal-800/60'
                    : 'bg-amber-50 text-amber-700 dark:bg-amber-950/60 dark:text-amber-300 border-amber-200 dark:border-amber-800/60'
                }`}>
                  <span className={`w-1.5 h-1.5 rounded-full ${
                    locationStatus === 'confirmed' ? 'bg-emerald-500' : locationStatus === 'manual' ? 'bg-blue-500' : 'bg-amber-500'
                  }`} />
                  {locationStatus === 'confirmed' && 'Live GPS Active'}
                  {locationStatus === 'manual' && 'Manual City'}
                  {locationStatus === 'detecting' && 'Detecting GPS...'}
                  {(locationStatus === 'denied' || locationStatus === 'unavailable') && 'Location Needed'}
                </span>

                {isFetchingOSM && (
                  <span className="inline-flex items-center gap-1 px-2.5 py-0.5 rounded-full text-[11px] font-bold bg-teal-50 dark:bg-teal-950/60 text-[#0bbbb6] dark:text-teal-300 border border-teal-200/80 dark:border-teal-800/60 animate-pulse">
                    <Sparkles className="w-3 h-3 text-[#0bbbb6]" />
                    <span>Updating nearby stores...</span>
                  </span>
                )}
              </div>

              <p className="text-xs text-slate-500 dark:text-slate-400 font-medium truncate max-w-xl">
                {detectedAddress || (locationStatus === 'detecting' ? 'Acquiring device GPS coordinates...' : 'Select location to find nearest pharmacies')}
              </p>
            </div>
          </div>

          {/* Right: Actions & View Switcher */}
          <div className="flex flex-wrap sm:flex-nowrap items-center gap-2 self-start sm:self-auto shrink-0">
            <button
              onClick={detectGPSLocation}
              disabled={locationStatus === 'detecting'}
              title="Recenter map to device GPS location"
              className="px-3 py-2 bg-slate-50 hover:bg-slate-100 dark:bg-slate-800 dark:hover:bg-slate-700 text-slate-700 dark:text-slate-200 border border-slate-200 dark:border-slate-700 rounded-xl text-xs font-bold transition cursor-pointer flex items-center gap-1.5 shadow-2xs active:scale-95"
            >
              <LocateFixed className={`w-3.5 h-3.5 text-[#0bbbb6] ${locationStatus === 'detecting' ? 'animate-spin' : ''}`} />
              <span>{locationStatus === 'detecting' ? 'Detecting...' : 'Recenter GPS'}</span>
            </button>

            <button
              onClick={() => setIsEditingLocation(!isEditingLocation)}
              className={`px-3 py-2 border rounded-xl text-xs font-bold transition cursor-pointer flex items-center gap-1.5 shadow-2xs active:scale-95 ${
                isEditingLocation
                  ? 'bg-teal-50 border-[#0bbbb6] text-[#0bbbb6] dark:bg-teal-950/60 dark:text-teal-300'
                  : 'bg-slate-50 hover:bg-slate-100 dark:bg-slate-800 dark:hover:bg-slate-700 text-slate-700 dark:text-slate-200 border-slate-200 dark:border-slate-700'
              }`}
            >
              <Edit3 className="w-3.5 h-3.5 text-[#0bbbb6]" />
              <span>Change City/PIN</span>
            </button>

            {/* Segmented Control: Map + List vs Map Only vs List Only */}
            <div className="flex items-center bg-slate-100 dark:bg-slate-800 p-1 rounded-xl border border-slate-200/80 dark:border-slate-700 shadow-2xs">
              <button
                onClick={() => setViewMode('both')}
                className={`px-3 py-1.5 rounded-lg text-xs font-bold transition flex items-center gap-1.5 cursor-pointer ${
                  viewMode === 'both'
                    ? 'bg-white dark:bg-slate-700 text-slate-900 dark:text-white shadow-xs'
                    : 'text-slate-500 dark:text-slate-400 hover:text-slate-900 dark:hover:text-white'
                }`}
              >
                <span>Split View</span>
              </button>
              <button
                onClick={() => setViewMode('map')}
                className={`px-3 py-1.5 rounded-lg text-xs font-bold transition flex items-center gap-1.5 cursor-pointer ${
                  viewMode === 'map'
                    ? 'bg-white dark:bg-slate-700 text-slate-900 dark:text-white shadow-xs'
                    : 'text-slate-500 dark:text-slate-400 hover:text-slate-900 dark:hover:text-white'
                }`}
              >
                <span>Map Only</span>
              </button>
              <button
                onClick={() => setViewMode('list')}
                className={`px-3 py-1.5 rounded-lg text-xs font-bold transition flex items-center gap-1.5 cursor-pointer ${
                  viewMode === 'list'
                    ? 'bg-white dark:bg-slate-700 text-slate-900 dark:text-white shadow-xs'
                    : 'text-slate-500 dark:text-slate-400 hover:text-slate-900 dark:hover:text-white'
                }`}
              >
                <span>List Only</span>
              </button>
            </div>
          </div>
        </div>

        {/* INLINE MANUAL CITY OR PIN CODE FORM */}
        {isEditingLocation && (
          <div className="mt-4 pt-4 border-t border-slate-200 dark:border-slate-800 space-y-3 animate-fade-in">
            <form onSubmit={handleManualAddressSubmit} className="flex flex-col sm:flex-row items-center gap-2">
              <div className="relative flex-1 w-full">
                <Building2 className="w-4 h-4 text-slate-400 absolute left-3.5 top-3" />
                <input
                  type="text"
                  value={customAddressInput}
                  onChange={e => setCustomAddressInput(e.target.value)}
                  placeholder="Enter City name or 6-digit PIN Code (e.g. 532001, Vizianagaram, Visakhapatnam)..."
                  className="w-full pl-10 pr-4 py-2.5 bg-slate-50 dark:bg-slate-800 border border-slate-200 dark:border-slate-700 rounded-xl text-xs text-slate-900 dark:text-white placeholder-slate-400 focus:outline-none focus:ring-2 focus:ring-[#0bbbb6]"
                />
              </div>

              <button
                type="submit"
                disabled={isGeocodingManual}
                className="w-full sm:w-auto px-4 py-2.5 bg-[#0bbbb6] hover:bg-[#0aa6a1] text-white rounded-xl text-xs font-bold transition cursor-pointer flex items-center justify-center gap-1.5 shrink-0 shadow-xs"
              >
                {isGeocodingManual ? <RefreshCw className="w-4 h-4 animate-spin" /> : <Check className="w-4 h-4" />}
                <span>Set Location</span>
              </button>
            </form>

            <div className="flex flex-wrap items-center gap-1.5 pt-1">
              <span className="text-[11px] font-bold text-slate-500 dark:text-slate-400 mr-1">Quick Select City:</span>
              {CITY_PRESETS.map((city) => (
                <button
                  key={city.name}
                  onClick={() => handleSelectCityPreset(city)}
                  className={`px-2.5 py-1 rounded-lg text-[11px] font-semibold border transition cursor-pointer ${
                    localityName === city.name
                      ? 'bg-teal-50 dark:bg-teal-950/50 text-[#0bbbb6] border-[#0bbbb6]/40 font-bold'
                      : 'bg-slate-50 hover:bg-slate-100 dark:bg-slate-800 dark:hover:bg-slate-700 text-slate-700 dark:text-slate-300 border-slate-200 dark:border-slate-700'
                  }`}
                >
                  {city.name} ({city.pincode})
                </button>
              ))}
            </div>
          </div>
        )}
      </div>

      {/* SEARCH HEADER & RADIUS CONTROLS */}
      <div className="bg-white dark:bg-slate-900 border border-slate-200/80 dark:border-slate-800 rounded-3xl p-6 sm:p-8 space-y-5 shadow-xs">
        <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-4">
          <div>
            <h1 className="text-xl sm:text-2xl font-extrabold text-slate-900 dark:text-white flex items-center gap-2">
              <Pill className="w-6 h-6 text-[#0bbbb6]" />
              <span>Find Nearby Pharmacies</span>
            </h1>
            <p className="text-xs sm:text-sm text-slate-500 dark:text-slate-400 font-medium mt-1">
              Search a medicine or view sorted nearby verified medical stores around your live location
            </p>
          </div>

          {onNavigateToConnect && (
            <button
              onClick={onNavigateToConnect}
              className="px-4 py-2 bg-teal-50 hover:bg-teal-100 dark:bg-teal-950/40 dark:hover:bg-teal-950/70 border border-[#0bbbb6]/30 text-[#0bbbb6] dark:text-teal-300 rounded-2xl text-xs font-bold transition shrink-0 cursor-pointer"
            >
              + Partner Pharmacy
            </button>
          )}
        </div>

        {/* Search Input Bar */}
        <div className="relative">
          <Search className="w-5 h-5 text-slate-400 absolute left-4 top-3.5" />
          <input
            type="text"
            value={query}
            onChange={e => setQuery(e.target.value)}
            placeholder="Search medicine name (e.g. Dolo 650, Paracetamol, Amoxicillin, Amlodipine)..."
            className="w-full pl-11 pr-10 py-3.5 bg-slate-50 dark:bg-slate-800 border border-slate-200 dark:border-slate-700 rounded-2xl text-xs sm:text-sm focus:outline-none focus:ring-2 focus:ring-[#0bbbb6] dark:text-white font-medium shadow-2xs"
          />
          {query && (
            <button
              onClick={() => setQuery('')}
              className="absolute right-3.5 top-3.5 text-xs text-slate-400 hover:text-slate-600 dark:hover:text-white font-bold p-1 bg-slate-200 dark:bg-slate-700 rounded-full"
            >
              ✕
            </button>
          )}
        </div>

        {/* Quick Search Medicine Pills */}
        <div className="space-y-1.5">
          <div className="text-[11px] font-bold text-slate-400 dark:text-slate-500 uppercase tracking-wider">
            Popular Quick Search:
          </div>
          <div className="flex flex-wrap items-center gap-2">
            {POPULAR_MEDICINES.map((med) => (
              <button
                key={med}
                onClick={() => setQuery(med)}
                className={`px-3 py-1.5 rounded-full text-xs font-semibold border transition cursor-pointer ${
                  query.toLowerCase() === med.toLowerCase()
                    ? 'bg-[#0bbbb6] text-white border-[#0bbbb6] shadow-xs'
                    : 'bg-slate-50 dark:bg-slate-800/80 text-slate-700 dark:text-slate-300 border-slate-200 dark:border-slate-700 hover:border-[#0bbbb6]'
                }`}
              >
                {med}
              </button>
            ))}
          </div>
        </div>

        {/* Verified Medicine Info Badge */}
        {query.trim() && (
          <div className="pt-2 border-t border-slate-100 dark:border-slate-800 animate-fade-in">
            {verifiedMed ? (
              <div className="p-3.5 bg-emerald-50 dark:bg-emerald-950/40 border border-emerald-300 dark:border-emerald-800/80 rounded-2xl flex flex-col sm:flex-row sm:items-center justify-between gap-2 text-xs">
                <div className="flex items-center gap-2">
                  <CheckCircle2 className="w-4 h-4 text-emerald-600 dark:text-emerald-400 shrink-0" />
                  <span className="font-extrabold text-emerald-950 dark:text-emerald-200">
                    Verified Medicine: <span className="underline">{verifiedMed.name}</span> ({verifiedMed.genericName})
                  </span>
                  <span className="hidden sm:inline px-2 py-0.5 rounded-full bg-emerald-200/60 dark:bg-emerald-900/60 text-emerald-900 dark:text-emerald-300 font-bold text-[10px]">
                    {verifiedMed.category}
                  </span>
                </div>
                <div className="text-[11px] font-semibold text-emerald-800 dark:text-emerald-300">
                  Primary Uses: {verifiedMed.uses.slice(0, 2).join(', ')}
                </div>
              </div>
            ) : (
              <div className="p-3 bg-slate-100 dark:bg-slate-800/60 border border-slate-200 dark:border-slate-700 rounded-2xl flex items-center gap-2 text-xs font-semibold text-slate-600 dark:text-slate-300">
                <Sparkles className="w-4 h-4 text-[#0bbbb6] shrink-0" />
                <span>Searching pharmacy inventories for <strong className="text-slate-900 dark:text-white">"{query}"</strong>...</span>
              </div>
            )}
          </div>
        )}

        {/* DISTANCE RADIUS FILTER SELECTOR (5, 10, 15, 20, 50 km) */}
        <div className="pt-3 border-t border-slate-100 dark:border-slate-800 space-y-2">
          <div className="flex items-center justify-between">
            <span className="text-xs font-bold text-slate-700 dark:text-slate-300 flex items-center gap-1.5">
              <Sliders className="w-3.5 h-3.5 text-[#0bbbb6]" />
              <span>Search Radius:</span>
            </span>
            <span className="text-xs font-extrabold text-[#0bbbb6]">
              Selected: {selectedRadius} km {isAutoExpanded && `(Auto-Expanded to ${effectiveRadius} km)`}
            </span>
          </div>

          <div className="flex flex-wrap items-center gap-2">
            {RADIUS_OPTIONS.map((radius) => (
              <button
                key={radius}
                onClick={() => setSelectedRadius(radius)}
                className={`px-3.5 py-1.5 rounded-2xl text-xs font-extrabold border transition cursor-pointer ${
                  selectedRadius === radius
                    ? 'bg-[#0bbbb6] text-white border-[#0bbbb6] shadow-2xs'
                    : 'bg-slate-100 dark:bg-slate-800 text-slate-700 dark:text-slate-300 border-slate-200 dark:border-slate-700 hover:border-[#0bbbb6]'
                }`}
              >
                {radius} km
              </button>
            ))}

            <button
              onClick={() => setFilterInStockOnly(!filterInStockOnly)}
              className={`ml-auto px-3 py-1.5 rounded-2xl text-xs font-bold transition flex items-center gap-1.5 cursor-pointer ${
                filterInStockOnly
                  ? 'bg-emerald-600 text-white shadow-xs'
                  : 'bg-slate-100 dark:bg-slate-800 text-slate-600 dark:text-slate-300 hover:bg-slate-200 dark:hover:bg-slate-700'
              }`}
            >
              <Filter className="w-3.5 h-3.5" />
              <span>Confirmed In Stock</span>
            </button>
          </div>
        </div>
      </div>

      {/* AUTO-RADIUS EXPANSION BANNER */}
      {isAutoExpanded && (
        <div className="bg-teal-50 dark:bg-teal-950/60 border border-[#0bbbb6]/40 rounded-3xl p-4 sm:p-5 shadow-xs flex items-center gap-3 animate-fade-in">
          <Sparkles className="w-5 h-5 text-[#0bbbb6] shrink-0 animate-pulse" />
          <div className="text-xs sm:text-sm font-bold text-teal-950 dark:text-teal-200">
            No pharmacies were found directly within <span className="underline">{selectedRadius} km</span>. Auto-expanded search radius to <span className="underline font-black text-[#0bbbb6]">{effectiveRadius} km</span> to show the nearest available pharmacies!
          </div>
        </div>
      )}

      {/* AUTHENTIC GOOGLE MAPS INTERACTIVE VIEW */}
      {(viewMode === 'map' || viewMode === 'both') && (
        <GoogleMapsView
          userCoords={activeCoords}
          pharmacies={sortedNearbyPharmacies}
          selectedPharmacyId={selectedPharmacyId}
          onSelectPharmacy={(ph) => {
            setSelectedPharmacyId(ph.id);
            handleMarkerClick(ph.id);
          }}
          onNavigate={(ph) => {
            if (onSelectPharmacyForNav) {
              onSelectPharmacyForNav(ph);
            }
          }}
          searchedMedicineName={query}
          radiusKm={effectiveRadius}
          userAddressLabel={localityName || 'Your Location'}
        />
      )}

      {/* PHARMACIES CARDS LIST (SORTED BY NEAREST DISTANCE) */}
      {(viewMode === 'list' || viewMode === 'both') && (
        <div className="space-y-4">
          <div className="flex items-center justify-between px-1">
            <h2 className="text-sm font-extrabold text-slate-800 dark:text-slate-200 flex items-center gap-2">
              <span>Nearby Pharmacies ({sortedNearbyPharmacies.length})</span>
              <span className="text-xs font-semibold text-slate-400">Sorted by nearest distance</span>
            </h2>
          </div>

          {/* ABSOLUTELY NO PHARMACIES FOUND FALLBACK MESSAGE & ALTERNATIVES RECOMMENDATIONS */}
          {sortedNearbyPharmacies.length === 0 ? (
            <div className="bg-white dark:bg-slate-900 border border-slate-200/80 dark:border-slate-800 rounded-3xl p-6 sm:p-10 text-center space-y-6 shadow-xs animate-fade-in">
              <div className="w-14 h-14 rounded-3xl bg-amber-100 dark:bg-amber-950/80 text-amber-600 dark:text-amber-400 flex items-center justify-center mx-auto">
                <AlertCircle className="w-8 h-8 animate-bounce" />
              </div>

              <div className="space-y-2 max-w-lg mx-auto">
                <h3 className="text-base sm:text-lg font-black text-slate-900 dark:text-white">
                  {query.trim()
                    ? `"${query}" is currently unavailable in nearby pharmacies within ${effectiveRadius} km.`
                    : `No pharmacies found within ${effectiveRadius} km of your current location.`}
                </h3>
                <p className="text-xs sm:text-sm font-medium text-slate-500 dark:text-slate-400">
                  {query.trim()
                    ? 'None of the medical stores in this radius have this specific medicine in stock right now. Consider searching for generic alternatives below or expanding your search radius.'
                    : 'Try selecting a different city or PIN code, or retry your GPS location scan.'}
                </p>
              </div>

              {/* RECOMMENDED ALTERNATIVES LIST */}
              {query.trim() && medicineAlternatives.length > 0 && (
                <div className="pt-4 border-t border-slate-100 dark:border-slate-800 text-left space-y-3 max-w-xl mx-auto">
                  <span className="text-xs font-black uppercase tracking-wider text-[#0bbbb6] flex items-center gap-1.5">
                    <Sparkles className="w-4 h-4" />
                    <span>Recommended Generic Alternatives & Substitutes:</span>
                  </span>

                  <div className="grid grid-cols-1 sm:grid-cols-2 gap-2.5">
                    {medicineAlternatives.slice(0, 4).map((alt) => (
                      <button
                        key={alt.id}
                        onClick={() => setQuery(alt.name)}
                        className="p-3 bg-slate-50 hover:bg-teal-50 dark:bg-slate-800 dark:hover:bg-teal-950/50 border border-slate-200 dark:border-slate-700 hover:border-[#0bbbb6] rounded-2xl text-left transition cursor-pointer group"
                      >
                        <div className="text-xs font-bold text-slate-900 dark:text-white group-hover:text-[#0bbbb6] flex items-center justify-between">
                          <span>{alt.name}</span>
                          <span className="text-[10px] font-extrabold text-[#0bbbb6]">Search →</span>
                        </div>
                        <div className="text-[11px] font-medium text-slate-500 dark:text-slate-400 mt-0.5">
                          Generic: {alt.genericName}
                        </div>
                        <div className="text-[10px] text-emerald-600 dark:text-emerald-400 font-bold mt-1">
                          Uses: {alt.uses.slice(0, 2).join(', ')}
                        </div>
                      </button>
                    ))}
                  </div>
                </div>
              )}

              <div className="flex flex-wrap justify-center items-center gap-3 pt-2">
                <button
                  onClick={() => setIsEditingLocation(true)}
                  className="px-5 py-2.5 bg-[#0bbbb6] hover:bg-[#0aa6a1] text-white rounded-2xl text-xs font-bold transition cursor-pointer shadow-xs flex items-center gap-2"
                >
                  <Edit3 className="w-4 h-4" />
                  <span>Select City / PIN Code</span>
                </button>

                <button
                  onClick={detectGPSLocation}
                  className="px-5 py-2.5 bg-slate-100 dark:bg-slate-800 hover:bg-slate-200 dark:hover:bg-slate-700 text-slate-800 dark:text-slate-200 rounded-2xl text-xs font-bold transition cursor-pointer flex items-center gap-2"
                >
                  <RefreshCw className="w-4 h-4 text-[#0bbbb6]" />
                  <span>Retry GPS Detection</span>
                </button>
              </div>
            </div>
          ) : (
          sortedNearbyPharmacies.map((ph, index) => {
            const q = query.trim().toLowerCase();
            const matchedMed = q
              ? ph.medicines.find(m => m.name.toLowerCase().includes(q) || m.genericName.toLowerCase().includes(q))
              : null;

            const isStockConfirmed = matchedMed 
              ? (matchedMed.stockStatus === 'In Stock' || matchedMed.stockStatus === 'Low Stock')
              : true;

            const isSelected = selectedPharmacyId === ph.id;

            // Google Maps Directions link using exact coordinates
            const mapsUrl = getGoogleMapsNavigationUrl(ph.lat, ph.lng, activeCoords.lat, activeCoords.lng);

            return (
              <div
                key={ph.id}
                ref={el => cardRefs.current[ph.id] = el}
                className={`bg-white dark:bg-slate-900 border rounded-3xl p-5 sm:p-6 shadow-xs space-y-4 transition ${
                  isSelected 
                    ? 'border-2 border-[#0bbbb6] ring-2 ring-[#0bbbb6]/30 dark:ring-[#0bbbb6]/20' 
                    : 'border-slate-200/80 dark:border-slate-800 hover:border-[#0bbbb6]/50'
                }`}
              >
                {/* Header: Pharmacy Name, Rating, Distance, Travel Time */}
                <div className="flex flex-col sm:flex-row sm:items-start justify-between gap-3">
                  <div className="space-y-1">
                    <div className="flex flex-wrap items-center gap-2">
                      <h3 className="text-base sm:text-lg font-extrabold text-slate-900 dark:text-white">
                        {ph.name}
                      </h3>

                      {index === 0 && (
                        <span className="px-2.5 py-0.5 rounded-full text-[10px] font-black bg-[#0bbbb6] text-white shadow-2xs">
                          ★ Nearest Pharmacy
                        </span>
                      )}

                      {ph.rating && (
                        <span className="px-2 py-0.5 rounded-full text-[10px] font-black bg-amber-100 dark:bg-amber-950/80 text-amber-800 dark:text-amber-300 border border-amber-300/40 flex items-center gap-1">
                          <Star className="w-3 h-3 fill-amber-500 text-amber-500" />
                          <span>{ph.rating} / 5</span>
                        </span>
                      )}

                      <span className={`px-2.5 py-0.5 rounded-full text-[10px] font-extrabold border ${
                        ph.isOpen 
                          ? 'bg-emerald-100 dark:bg-emerald-950/60 text-emerald-800 dark:text-emerald-300 border-emerald-300/40'
                          : 'bg-rose-100 dark:bg-rose-950/60 text-rose-800 dark:text-rose-300 border-rose-300/40'
                      }`}>
                        {ph.isOpen ? '🟢 Open Now' : '🔴 Closed'} ({ph.openHours})
                      </span>
                    </div>

                    <div className="flex flex-wrap items-center gap-2 text-xs font-semibold pt-0.5">
                      <span className="px-2.5 py-1 rounded-xl bg-teal-50 dark:bg-teal-950/60 text-[#0bbbb6] dark:text-teal-300 border border-[#0bbbb6]/30 font-black flex items-center gap-1">
                        <MapPin className="w-3.5 h-3.5" />
                        <span>{ph.computedDistance} km away</span>
                      </span>

                      <span className="px-2.5 py-1 rounded-xl bg-slate-100 dark:bg-slate-800 text-slate-700 dark:text-slate-300 font-bold flex items-center gap-1">
                        <Car className="w-3.5 h-3.5 text-[#0bbbb6]" />
                        <span>{ph.travelTime.formatted}</span>
                      </span>
                    </div>

                    <p className="text-xs text-slate-500 dark:text-slate-400 font-medium pt-1">
                      📌 {ph.address}, {ph.city}
                    </p>
                  </div>

                  <div className="text-xs text-slate-600 dark:text-slate-300 font-bold shrink-0 self-start sm:self-auto">
                    📞 <a href={`tel:${ph.phone}`} className="hover:text-[#0bbbb6] underline">{ph.phone}</a>
                  </div>
                </div>

                {/* Medicine Stock & Availability Status */}
                {q && matchedMed ? (
                  <div className="p-3 bg-teal-50/70 dark:bg-teal-950/40 border border-[#0bbbb6]/30 rounded-2xl flex flex-col sm:flex-row sm:items-center justify-between gap-2">
                    <div className="flex items-center gap-2">
                      <Pill className="w-4 h-4 text-[#0bbbb6]" />
                      <span className="text-xs font-bold text-slate-800 dark:text-slate-200">
                        {matchedMed.name} ({matchedMed.dosage}) — ₹{matchedMed.price}
                      </span>
                    </div>

                    {isStockConfirmed ? (
                      <span className="px-2.5 py-1 bg-emerald-100 dark:bg-emerald-950 text-emerald-800 dark:text-emerald-300 text-[10px] font-black rounded-full flex items-center gap-1 border border-emerald-300/50 self-start sm:self-auto">
                        <CheckCircle2 className="w-3.5 h-3.5 text-emerald-600" />
                        <span>Medicine Available ({matchedMed.quantity} units in stock)</span>
                      </span>
                    ) : (
                      <span className="px-2.5 py-1 bg-amber-100 dark:bg-amber-950 text-amber-800 dark:text-amber-300 text-[10px] font-black rounded-full flex items-center gap-1 border border-amber-300/50 self-start sm:self-auto">
                        <AlertCircle className="w-3.5 h-3.5 text-amber-600" />
                        <span>Low Stock</span>
                      </span>
                    )}
                  </div>
                ) : (
                  <div className="flex items-center gap-2 text-[11px] font-bold text-slate-500 dark:text-slate-400">
                    <span className="px-2 py-0.5 rounded-full bg-slate-100 dark:bg-slate-800 text-slate-700 dark:text-slate-300">
                      Stock: {ph.medicines.length} Essential Medicines Verified
                    </span>
                  </div>
                )}

                {/* ACTION BUTTONS: Call & Navigation */}
                <div className="flex items-center gap-3 pt-2 border-t border-slate-100 dark:border-slate-800">
                  <a
                    href={`tel:${ph.phone}`}
                    className="flex-1 px-4 py-2.5 bg-slate-100 hover:bg-slate-200 dark:bg-slate-800 dark:hover:bg-slate-700 text-slate-800 dark:text-slate-100 rounded-2xl text-xs font-bold transition flex items-center justify-center gap-2"
                  >
                    <Phone className="w-4 h-4 text-slate-600 dark:text-slate-300" />
                    <span>Call Store</span>
                  </a>

                  <a
                    href={mapsUrl}
                    target="_blank"
                    rel="noopener noreferrer"
                    className="flex-1 px-4 py-2.5 bg-[#0bbbb6] hover:bg-[#0aa6a1] text-white rounded-2xl text-xs font-bold transition flex items-center justify-center gap-2 shadow-xs cursor-pointer"
                  >
                    <ExternalLink className="w-4 h-4" />
                    <span>Google Maps Directions</span>
                  </a>

                  {onSelectPharmacyForNav && (
                    <button
                      onClick={() => onSelectPharmacyForNav(ph)}
                      className="px-3.5 py-2.5 bg-teal-50 hover:bg-teal-100 dark:bg-teal-950/40 text-[#0bbbb6] border border-[#0bbbb6]/30 rounded-2xl text-xs font-bold transition flex items-center gap-1.5 cursor-pointer"
                      title="In-app Navigation"
                    >
                      <Navigation className="w-3.5 h-3.5" />
                      <span className="hidden sm:inline">Directions</span>
                    </button>
                  )}
                </div>
              </div>
            );
          })
        )}
        </div>
      )}

    </div>
  );
}
