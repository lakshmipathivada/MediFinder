import React, { useEffect, useRef, useState } from 'react';
import L from 'leaflet';
import { 
  Navigation, 
  Phone, 
  Clock, 
  Star, 
  X, 
  Layers, 
  LocateFixed, 
  Plus, 
  Minus, 
  Maximize2, 
  Minimize2,
  CheckCircle2, 
  AlertCircle, 
  Pill,
  Store,
  Compass
} from 'lucide-react';
import { Pharmacy } from '../types';

export type TravelTimeType = string | { driveMinutes: number; walkMinutes: number; formatted: string };

export type PharmacyWithDistance = Pharmacy & { 
  computedDistance: number; 
  travelTime?: TravelTimeType;
};

interface GoogleMapsViewProps {
  userCoords: { lat: number; lng: number };
  pharmacies: PharmacyWithDistance[];
  selectedPharmacyId?: string | null;
  onSelectPharmacy?: (ph: Pharmacy) => void;
  onNavigate?: (ph: Pharmacy) => void;
  searchedMedicineName?: string;
  radiusKm?: number;
  userAddressLabel?: string;
}

export function formatTravelTime(tt?: TravelTimeType) {
  if (!tt) return '4 min drive';
  if (typeof tt === 'string') return tt;
  return `${tt.formatted} drive`;
}

export default function GoogleMapsView({
  userCoords,
  pharmacies,
  selectedPharmacyId,
  onSelectPharmacy,
  onNavigate,
  searchedMedicineName = '',
  radiusKm = 5,
  userAddressLabel = 'Your Location'
}: GoogleMapsViewProps) {
  const mapContainerRef = useRef<HTMLDivElement>(null);
  const mapInstanceRef = useRef<L.Map | null>(null);
  const markersLayerRef = useRef<L.LayerGroup | null>(null);
  const tileLayerRef = useRef<L.TileLayer | null>(null);

  const [mapType, setMapType] = useState<'streets' | 'satellite'>('streets');
  const [activePharmacy, setActivePharmacy] = useState<PharmacyWithDistance | null>(null);
  const [isFullscreen, setIsFullscreen] = useState(false);

  // Sync active pharmacy with selectedPharmacyId prop
  useEffect(() => {
    if (selectedPharmacyId) {
      const found = pharmacies.find(p => p.id === selectedPharmacyId);
      if (found) {
        setActivePharmacy(found);
        if (mapInstanceRef.current) {
          mapInstanceRef.current.flyTo([found.lat, found.lng], 15, { duration: 0.8 });
        }
      }
    }
  }, [selectedPharmacyId, pharmacies]);

  // 1. Initialize Leaflet Map
  useEffect(() => {
    if (!mapContainerRef.current) return;

    if (!mapInstanceRef.current) {
      const map = L.map(mapContainerRef.current, {
        center: [userCoords.lat, userCoords.lng],
        zoom: 14,
        zoomControl: false, // We render authentic Google Maps styled floating zoom controls
        attributionControl: false
      });

      // Google Maps Direct Raster Tiles: 100% Genuine Google Maps with zero watermarks and no API keys required
      const tileUrl = mapType === 'streets'
        ? 'https://mt{s}.google.com/vt/lyrs=m&x={x}&y={y}&z={z}'
        : 'https://mt{s}.google.com/vt/lyrs=y&x={x}&y={y}&z={z}';

      tileLayerRef.current = L.tileLayer(tileUrl, {
        maxZoom: 20,
        subdomains: ['0', '1', '2', '3']
      }).addTo(map);

      markersLayerRef.current = L.layerGroup().addTo(map);
      mapInstanceRef.current = map;
    }

    return () => {
      if (mapInstanceRef.current) {
        mapInstanceRef.current.remove();
        mapInstanceRef.current = null;
      }
    };
  }, []);

  // 2. Switch Tile Layers (Google Street Style vs Satellite Hybrid)
  useEffect(() => {
    if (!mapInstanceRef.current || !tileLayerRef.current) return;

    mapInstanceRef.current.removeLayer(tileLayerRef.current);
    const tileUrl = mapType === 'streets'
      ? 'https://mt{s}.google.com/vt/lyrs=m&x={x}&y={y}&z={z}'
      : 'https://mt{s}.google.com/vt/lyrs=y&x={x}&y={y}&z={z}';

    tileLayerRef.current = L.tileLayer(tileUrl, {
      maxZoom: 20,
      subdomains: ['0', '1', '2', '3']
    }).addTo(mapInstanceRef.current);
  }, [mapType]);

  // 3. Render Custom Google Maps Style Markers
  useEffect(() => {
    const map = mapInstanceRef.current;
    const markersLayer = markersLayerRef.current;
    if (!map || !markersLayer) return;

    markersLayer.clearLayers();

    // A. Render Google Maps Blue Pulse User Marker
    const userMarkerHtml = `
      <div class="gm-user-marker">
        <div class="gm-user-pulse"></div>
        <div class="gm-user-dot"></div>
      </div>
    `;

    const userIcon = L.divIcon({
      html: userMarkerHtml,
      className: '',
      iconSize: [32, 32],
      iconAnchor: [16, 16]
    });

    L.marker([userCoords.lat, userCoords.lng], { icon: userIcon, zIndexOffset: 1000 })
      .bindTooltip(`<div class="font-bold text-xs py-0.5 px-1">${userAddressLabel} (You)</div>`, {
        direction: 'top',
        offset: [0, -12]
      })
      .addTo(markersLayer);

    // B. Search Radius Circle (Google Maps translucent blue radius)
    L.circle([userCoords.lat, userCoords.lng], {
      radius: radiusKm * 1000,
      color: '#1a73e8',
      weight: 1.5,
      opacity: 0.6,
      fillColor: '#1a73e8',
      fillOpacity: 0.04,
      dashArray: '4, 6'
    }).addTo(markersLayer);

    // C. Render Google Maps Teardrop Markers for Pharmacies
    const bounds = L.latLngBounds([[userCoords.lat, userCoords.lng]]);

    pharmacies.forEach((ph) => {
      bounds.extend([ph.lat, ph.lng]);

      // Stock status for searched medicine
      const medMatch = searchedMedicineName.trim()
        ? ph.medicines.find(m => 
            m.name.toLowerCase().includes(searchedMedicineName.toLowerCase()) || 
            m.genericName.toLowerCase().includes(searchedMedicineName.toLowerCase())
          )
        : null;

      const isInStock = medMatch 
        ? medMatch.stockStatus === 'In Stock' 
        : ph.medicines.some(m => m.stockStatus === 'In Stock');

      const isSelected = activePharmacy?.id === ph.id;
      const is24h = ph.openHours.toLowerCase().includes('24');

      // Authentic Google Maps Teardrop Pin SVG
      const pinColor = isSelected ? '#1a73e8' : (isInStock ? '#0bbbb6' : '#ea4335');
      const badgeDotColor = isInStock ? '#34a853' : '#ea4335';

      const pharmacyPinHtml = `
        <div class="gm-pharmacy-pin flex flex-col items-center">
          <!-- Floating Status Badge -->
          <div class="mb-0.5 px-2 py-0.5 rounded-full bg-white/95 text-slate-900 border border-slate-200/80 shadow-md text-[10px] font-extrabold flex items-center gap-1 whitespace-nowrap">
            <span class="w-2 h-2 rounded-full" style="background-color: ${badgeDotColor}"></span>
            <span>${ph.computedDistance} km</span>
            ${is24h ? '<span class="text-rose-600 font-black">24h</span>' : ''}
          </div>

          <!-- Google Maps Teardrop Pin -->
          <div class="relative flex items-center justify-center filter drop-shadow-md">
            <svg width="30" height="38" viewBox="0 0 30 38" fill="none" xmlns="http://www.w3.org/2000/svg">
              <path d="M15 0C6.71573 0 0 6.71573 0 15C0 24.5 15 38 15 38C15 38 30 24.5 30 15C30 6.71573 23.2843 0 15 0Z" fill="${pinColor}"/>
              <circle cx="15" cy="14" r="9" fill="white"/>
            </svg>
            <div class="absolute top-[8px] flex items-center justify-center">
              <svg width="12" height="12" viewBox="0 0 24 24" fill="none" stroke="${pinColor}" stroke-width="3" stroke-linecap="round" stroke-linejoin="round">
                <line x1="12" y1="5" x2="12" y2="19"></line>
                <line x1="5" y1="12" x2="19" y2="12"></line>
              </svg>
            </div>
          </div>
        </div>
      `;

      const pharmacyIcon = L.divIcon({
        html: pharmacyPinHtml,
        className: '',
        iconSize: [44, 52],
        iconAnchor: [22, 50]
      });

      const marker = L.marker([ph.lat, ph.lng], { icon: pharmacyIcon, zIndexOffset: isSelected ? 900 : 500 })
        .addTo(markersLayer);

      marker.on('click', () => {
        setActivePharmacy(ph);
        if (onSelectPharmacy) onSelectPharmacy(ph);
        map.flyTo([ph.lat, ph.lng], 15, { duration: 0.6 });
      });
    });

    // Auto-fit bounds comfortably if we have coordinates
    if (pharmacies.length > 0) {
      map.fitBounds(bounds, { padding: [40, 40], maxZoom: 15 });
    }
  }, [pharmacies, userCoords, searchedMedicineName, activePharmacy?.id, radiusKm]);

  const handleZoomIn = () => {
    mapInstanceRef.current?.zoomIn();
  };

  const handleZoomOut = () => {
    mapInstanceRef.current?.zoomOut();
  };

  const handleRecenter = () => {
    if (mapInstanceRef.current) {
      mapInstanceRef.current.flyTo([userCoords.lat, userCoords.lng], 14, { duration: 0.8 });
    }
  };

  const handleToggleFullscreen = () => {
    setIsFullscreen(!isFullscreen);
    setTimeout(() => {
      mapInstanceRef.current?.invalidateSize();
    }, 200);
  };

  // Medicine stock details for active pharmacy
  const activeMedMatch = activePharmacy && searchedMedicineName.trim()
    ? activePharmacy.medicines.find(m => 
        m.name.toLowerCase().includes(searchedMedicineName.toLowerCase()) || 
        m.genericName.toLowerCase().includes(searchedMedicineName.toLowerCase())
      )
    : null;

  return (
    <div className={`relative overflow-hidden rounded-3xl border border-slate-200/80 dark:border-slate-800 bg-slate-100 dark:bg-slate-900 shadow-xl transition-all duration-300 ${
      isFullscreen ? 'fixed inset-4 z-50 rounded-2xl shadow-2xl' : 'w-full h-[460px] sm:h-[520px]'
    }`}>
      
      {/* 1. Leaflet Interactive Map Container */}
      <div ref={mapContainerRef} className="w-full h-full" />

      {/* 2. Top-Left: Google Maps Style Layer Switcher */}
      <div className="absolute top-3.5 left-3.5 z-30 flex items-center bg-white dark:bg-slate-900 rounded-2xl shadow-md border border-slate-200/80 dark:border-slate-700 p-1">
        <button
          onClick={() => setMapType('streets')}
          className={`px-3 py-1.5 rounded-xl text-xs font-bold transition cursor-pointer flex items-center gap-1.5 ${
            mapType === 'streets'
              ? 'bg-[#1a73e8] text-white shadow-xs'
              : 'text-slate-600 dark:text-slate-300 hover:bg-slate-100 dark:hover:bg-slate-800'
          }`}
        >
          <Layers className="w-3.5 h-3.5" />
          <span>Map</span>
        </button>
        <button
          onClick={() => setMapType('satellite')}
          className={`px-3 py-1.5 rounded-xl text-xs font-bold transition cursor-pointer flex items-center gap-1.5 ${
            mapType === 'satellite'
              ? 'bg-[#1a73e8] text-white shadow-xs'
              : 'text-slate-600 dark:text-slate-300 hover:bg-slate-100 dark:hover:bg-slate-800'
          }`}
        >
          <span>Satellite</span>
        </button>
      </div>

      {/* 3. Top-Right: Range & Status Banner */}
      <div className="absolute top-3.5 right-3.5 z-30 hidden sm:flex items-center gap-2 px-3 py-1.5 bg-white/95 dark:bg-slate-900/95 backdrop-blur-md rounded-2xl border border-slate-200/80 dark:border-slate-700 shadow-md text-xs font-bold text-slate-700 dark:text-slate-200">
        <Compass className="w-3.5 h-3.5 text-[#0bbbb6]" />
        <span>{pharmacies.length} Pharmacies</span>
        <span className="text-slate-300 dark:text-slate-600">•</span>
        <span className="text-[#1a73e8]">{radiusKm} km radius</span>
      </div>

      {/* 4. Bottom-Right: Google Maps Floating Action Buttons */}
      <div className="absolute bottom-4 right-4 z-30 flex flex-col gap-2">
        {/* Recenter on GPS */}
        <button
          onClick={handleRecenter}
          className="w-10 h-10 bg-white dark:bg-slate-900 text-slate-700 dark:text-slate-200 hover:text-[#1a73e8] rounded-2xl shadow-md border border-slate-200/80 dark:border-slate-700 flex items-center justify-center transition cursor-pointer active:scale-95"
          title="Recenter on My Location"
        >
          <LocateFixed className="w-5 h-5 text-[#1a73e8]" />
        </button>

        {/* Zoom Controls */}
        <div className="flex flex-col bg-white dark:bg-slate-900 rounded-2xl shadow-md border border-slate-200/80 dark:border-slate-700 overflow-hidden">
          <button
            onClick={handleZoomIn}
            className="w-10 h-10 text-slate-700 dark:text-slate-200 hover:bg-slate-100 dark:hover:bg-slate-800 flex items-center justify-center transition cursor-pointer border-b border-slate-100 dark:border-slate-800"
            title="Zoom In"
          >
            <Plus className="w-4 h-4 font-bold" />
          </button>
          <button
            onClick={handleZoomOut}
            className="w-10 h-10 text-slate-700 dark:text-slate-200 hover:bg-slate-100 dark:hover:bg-slate-800 flex items-center justify-center transition cursor-pointer"
            title="Zoom Out"
          >
            <Minus className="w-4 h-4 font-bold" />
          </button>
        </div>

        {/* Fullscreen Toggle */}
        <button
          onClick={handleToggleFullscreen}
          className="w-10 h-10 bg-white dark:bg-slate-900 text-slate-700 dark:text-slate-200 hover:text-[#1a73e8] rounded-2xl shadow-md border border-slate-200/80 dark:border-slate-700 flex items-center justify-center transition cursor-pointer active:scale-95"
          title={isFullscreen ? 'Exit Fullscreen' : 'Fullscreen'}
        >
          {isFullscreen ? <Minimize2 className="w-4 h-4" /> : <Maximize2 className="w-4 h-4" />}
        </button>
      </div>

      {/* 5. Google Maps Floating Place Detail Card (When a marker is active) */}
      {activePharmacy && (
        <div className="absolute bottom-4 left-4 right-16 sm:right-auto sm:max-w-md z-30 bg-white dark:bg-slate-900 border border-slate-200/90 dark:border-slate-700 rounded-3xl p-4 shadow-2xl animate-fade-in space-y-3">
          <div className="flex items-start justify-between gap-3">
            <div className="flex items-start gap-3">
              <div className="w-10 h-10 rounded-2xl bg-[#0bbbb6]/10 text-[#0bbbb6] flex items-center justify-center font-bold shrink-0 mt-0.5">
                <Store className="w-5 h-5" />
              </div>
              <div>
                <div className="flex items-center gap-1.5 flex-wrap">
                  <h4 className="text-sm font-extrabold text-slate-900 dark:text-white leading-snug">
                    {activePharmacy.name}
                  </h4>
                  {activePharmacy.rating && (
                    <span className="inline-flex items-center gap-0.5 px-1.5 py-0.2 bg-amber-50 dark:bg-amber-950/60 border border-amber-200 dark:border-amber-900 text-amber-700 dark:text-amber-300 rounded-md text-[10px] font-bold">
                      <Star className="w-2.5 h-2.5 fill-amber-400 text-amber-400" />
                      <span>{activePharmacy.rating}</span>
                    </span>
                  )}
                </div>
                <p className="text-xs text-slate-500 dark:text-slate-400 font-medium line-clamp-1 mt-0.5">
                  {activePharmacy.address}
                </p>
              </div>
            </div>

            <button
              onClick={() => setActivePharmacy(null)}
              className="p-1.5 text-slate-400 hover:text-slate-600 dark:hover:text-white rounded-full hover:bg-slate-100 dark:hover:bg-slate-800 transition cursor-pointer"
            >
              <X className="w-4 h-4" />
            </button>
          </div>

          {/* Stock & Timing Info */}
          <div className="flex flex-wrap items-center gap-2 text-xs font-semibold">
            {activeMedMatch ? (
              <span className={`px-2.5 py-0.5 rounded-full flex items-center gap-1 text-[11px] font-bold ${
                activeMedMatch.stockStatus === 'In Stock'
                  ? 'bg-emerald-50 dark:bg-emerald-950/60 text-emerald-700 dark:text-emerald-300 border border-emerald-200 dark:border-emerald-800'
                  : 'bg-rose-50 dark:bg-rose-950/60 text-rose-700 dark:text-rose-300 border border-rose-200 dark:border-rose-800'
              }`}>
                <CheckCircle2 className="w-3 h-3" />
                <span>{searchedMedicineName}: {activeMedMatch.stockStatus} (₹{activeMedMatch.price})</span>
              </span>
            ) : (
              <span className="px-2.5 py-0.5 rounded-full bg-emerald-50 dark:bg-emerald-950/60 text-emerald-700 dark:text-emerald-300 border border-emerald-200 dark:border-emerald-800 text-[11px] font-bold">
                {activePharmacy.medicines.length} Medicines in Stock
              </span>
            )}

            <span className="px-2 py-0.5 rounded-full bg-slate-100 dark:bg-slate-800 text-slate-600 dark:text-slate-300 text-[10px]">
              {activePharmacy.openHours}
            </span>

            <span className="text-[#1a73e8] font-bold text-[11px]">
              {activePharmacy.computedDistance} km away ({formatTravelTime(activePharmacy.travelTime)})
            </span>
          </div>

          {/* Action Buttons */}
          <div className="pt-1 flex items-center gap-2">
            <button
              onClick={() => onNavigate && onNavigate(activePharmacy)}
              className="flex-1 py-2 px-3 bg-[#1a73e8] hover:bg-[#1557b0] text-white rounded-xl text-xs font-bold transition shadow-xs flex items-center justify-center gap-1.5 cursor-pointer"
            >
              <Navigation className="w-3.5 h-3.5" />
              <span>Directions</span>
            </button>

            <a
              href={`tel:${activePharmacy.phone}`}
              className="flex-1 py-2 px-3 bg-slate-100 hover:bg-slate-200 dark:bg-slate-800 dark:hover:bg-slate-700 text-slate-700 dark:text-slate-200 rounded-xl text-xs font-bold transition flex items-center justify-center gap-1.5"
            >
              <Phone className="w-3.5 h-3.5 text-[#0bbbb6]" />
              <span>Call Store</span>
            </a>
          </div>
        </div>
      )}

    </div>
  );
}
