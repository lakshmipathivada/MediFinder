import React, { useEffect, useRef, useState } from 'react';
import * as THREE from 'three';
import { ShieldCheck } from 'lucide-react';

export default function Hero3DMedicineScene() {
  const containerRef = useRef<HTMLDivElement>(null);
  const canvasRef = useRef<HTMLCanvasElement>(null);
  const [isHovered, setIsHovered] = useState(false);

  useEffect(() => {
    const container = containerRef.current;
    const canvas = canvasRef.current;
    if (!container || !canvas) return;

    // Scene, Camera, Renderer
    const scene = new THREE.Scene();
    
    const width = container.clientWidth || 300;
    const height = container.clientHeight || 280;

    const camera = new THREE.PerspectiveCamera(45, width / height, 0.1, 100);
    camera.position.set(0, 0, 4.2);

    const renderer = new THREE.WebGLRenderer({
      canvas,
      alpha: true,
      antialias: true,
      powerPreference: 'high-performance'
    });
    renderer.setSize(width, height);
    renderer.setPixelRatio(Math.min(window.devicePixelRatio, 2));

    // Master Group for mouse parallax
    const masterGroup = new THREE.Group();
    scene.add(masterGroup);

    // 1. CAPSULE ASSEMBLY
    const capsuleGroup = new THREE.Group();
    masterGroup.add(capsuleGroup);

    // Materials
    const tealMaterial = new THREE.MeshStandardMaterial({
      color: 0x0bbbb6,
      roughness: 0.18,
      metalness: 0.2
    });

    const whiteMaterial = new THREE.MeshStandardMaterial({
      color: 0xffffff,
      roughness: 0.2,
      metalness: 0.08
    });

    const silverRingMaterial = new THREE.MeshStandardMaterial({
      color: 0xe2e8f0,
      roughness: 0.12,
      metalness: 0.85
    });

    const radius = 0.58;
    const halfHeight = 0.35;

    // Top Dome (Teal)
    const topDomeGeo = new THREE.SphereGeometry(radius, 32, 16, 0, Math.PI * 2, 0, Math.PI / 2);
    const topDome = new THREE.Mesh(topDomeGeo, tealMaterial);
    topDome.position.y = halfHeight;
    capsuleGroup.add(topDome);

    // Top Cylinder Body (Teal)
    const topCylGeo = new THREE.CylinderGeometry(radius, radius, halfHeight, 32, 1, true);
    const topCyl = new THREE.Mesh(topCylGeo, tealMaterial);
    topCyl.position.y = halfHeight / 2;
    capsuleGroup.add(topCyl);

    // Center Metallic Divider Ring
    const ringGeo = new THREE.CylinderGeometry(radius + 0.015, radius + 0.015, 0.06, 32);
    const ring = new THREE.Mesh(ringGeo, silverRingMaterial);
    ring.position.y = 0;
    capsuleGroup.add(ring);

    // Bottom Cylinder Body (White)
    const botCylGeo = new THREE.CylinderGeometry(radius, radius, halfHeight, 32, 1, true);
    const botCyl = new THREE.Mesh(botCylGeo, whiteMaterial);
    botCyl.position.y = -halfHeight / 2;
    capsuleGroup.add(botCyl);

    // Bottom Dome (White)
    const botDomeGeo = new THREE.SphereGeometry(radius, 32, 16, 0, Math.PI * 2, Math.PI / 2, Math.PI / 2);
    const botDome = new THREE.Mesh(botDomeGeo, whiteMaterial);
    botDome.position.y = -halfHeight;
    capsuleGroup.add(botDome);

    // Initial artistic tilt of capsule
    capsuleGroup.rotation.z = Math.PI / 6; // 30 deg tilt
    capsuleGroup.rotation.x = Math.PI / 10;

    // 2. ORBITING GLOWING CROSS (+)
    const crossGroup = new THREE.Group();
    const crossMat = new THREE.MeshStandardMaterial({
      color: 0x0bbbb6,
      emissive: 0x078e8a,
      emissiveIntensity: 0.8,
      roughness: 0.2,
      metalness: 0.3
    });
    const crossArm1 = new THREE.Mesh(new THREE.BoxGeometry(0.32, 0.1, 0.1), crossMat);
    const crossArm2 = new THREE.Mesh(new THREE.BoxGeometry(0.1, 0.32, 0.1), crossMat);
    crossGroup.add(crossArm1);
    crossGroup.add(crossArm2);
    masterGroup.add(crossGroup);

    // 3. GLOWING ORBITAL RINGS
    const ring1Geo = new THREE.TorusGeometry(1.25, 0.012, 16, 64);
    const ring1Mat = new THREE.MeshBasicMaterial({
      color: 0x33c7bf,
      transparent: true,
      opacity: 0.45
    });
    const orbitalRing1 = new THREE.Mesh(ring1Geo, ring1Mat);
    orbitalRing1.rotation.x = Math.PI / 3;
    orbitalRing1.rotation.y = Math.PI / 8;
    masterGroup.add(orbitalRing1);

    const ring2Geo = new THREE.TorusGeometry(1.42, 0.009, 16, 64);
    const ring2Mat = new THREE.MeshBasicMaterial({
      color: 0x10b981,
      transparent: true,
      opacity: 0.3
    });
    const orbitalRing2 = new THREE.Mesh(ring2Geo, ring2Mat);
    orbitalRing2.rotation.x = -Math.PI / 4;
    orbitalRing2.rotation.z = Math.PI / 6;
    masterGroup.add(orbitalRing2);

    // 4. FLOATING PARTICLES
    const particlesCount = 14;
    const particlesGeo = new THREE.SphereGeometry(0.035, 12, 8);
    const particleMat = new THREE.MeshBasicMaterial({
      color: 0x0bbbb6,
      transparent: true,
      opacity: 0.75
    });

    const particles: { mesh: THREE.Mesh; angle: number; speed: number; radius: number; yOffset: number }[] = [];
    for (let i = 0; i < particlesCount; i++) {
      const pMesh = new THREE.Mesh(particlesGeo, particleMat);
      const angle = (i / particlesCount) * Math.PI * 2;
      const r = 0.9 + Math.random() * 0.7;
      const yOffset = (Math.random() - 0.5) * 1.4;
      pMesh.position.set(Math.cos(angle) * r, yOffset, Math.sin(angle) * r);
      masterGroup.add(pMesh);
      particles.push({ mesh: pMesh, angle, speed: 0.4 + Math.random() * 0.5, radius: r, yOffset });
    }

    // 5. LIGHTING
    const ambientLight = new THREE.AmbientLight(0xffffff, 1.2);
    scene.add(ambientLight);

    const mainLight = new THREE.DirectionalLight(0xffffff, 2.0);
    mainLight.position.set(3, 4, 3);
    scene.add(mainLight);

    const tealRimLight = new THREE.PointLight(0x0bbbb6, 3.5, 8);
    tealRimLight.position.set(-3, -1, 2);
    scene.add(tealRimLight);

    const fillLight = new THREE.PointLight(0x10b981, 2.0, 6);
    fillLight.position.set(2, -3, 1);
    scene.add(fillLight);

    // MOUSE PARALLAX & TILT TRACKING
    let targetRotationX = 0;
    let targetRotationY = 0;
    let currentRotationX = 0;
    let currentRotationY = 0;
    let extraSpin = 0;

    const handleMouseMove = (e: MouseEvent) => {
      const rect = container.getBoundingClientRect();
      const x = ((e.clientX - rect.left) / rect.width) * 2 - 1;
      const y = -(((e.clientY - rect.top) / rect.height) * 2 - 1);
      targetRotationY = x * 0.45;
      targetRotationX = y * 0.35;
    };

    const handleMouseLeave = () => {
      targetRotationX = 0;
      targetRotationY = 0;
    };

    container.addEventListener('mousemove', handleMouseMove);
    container.addEventListener('mouseleave', handleMouseLeave);

    // CLICK BOOST SPIN
    const handleClick = () => {
      extraSpin += 2.2;
    };
    canvas.addEventListener('click', handleClick);

    // ANIMATION LOOP
    const clock = new THREE.Clock();
    let animId: number;

    const animate = () => {
      animId = requestAnimationFrame(animate);
      const elapsedTime = clock.getElapsedTime();

      // Smooth mouse lerp
      currentRotationX += (targetRotationX - currentRotationX) * 0.08;
      currentRotationY += (targetRotationY - currentRotationY) * 0.08;

      masterGroup.rotation.x = currentRotationX;
      masterGroup.rotation.y = currentRotationY;

      // Extra spin decay
      if (extraSpin > 0.01) {
        capsuleGroup.rotation.y += extraSpin;
        extraSpin *= 0.92;
      }

      // Smooth breathing bobbing
      capsuleGroup.position.y = Math.sin(elapsedTime * 1.6) * 0.1;
      capsuleGroup.rotation.y += 0.008;

      // Orbiting Cross movement
      const crossAngle = elapsedTime * 0.85;
      crossGroup.position.x = Math.cos(crossAngle) * 1.35;
      crossGroup.position.z = Math.sin(crossAngle) * 1.35;
      crossGroup.position.y = Math.sin(elapsedTime * 2.2) * 0.28;
      crossGroup.rotation.x = elapsedTime * 1.2;
      crossGroup.rotation.y = elapsedTime * 1.5;

      // Rings subtle rotation
      orbitalRing1.rotation.z = elapsedTime * 0.22;
      orbitalRing2.rotation.z = -elapsedTime * 0.18;

      // Particles orbiting
      particles.forEach((p) => {
        p.angle += 0.008 * p.speed;
        p.mesh.position.x = Math.cos(p.angle) * p.radius;
        p.mesh.position.z = Math.sin(p.angle) * p.radius;
        p.mesh.position.y = p.yOffset + Math.sin(elapsedTime * 2 + p.angle) * 0.08;
      });

      renderer.render(scene, camera);
    };

    animate();

    // RESIZE LISTENER
    const handleResize = () => {
      if (!container) return;
      const w = container.clientWidth || 300;
      const h = container.clientHeight || 280;
      camera.aspect = w / h;
      camera.updateProjectionMatrix();
      renderer.setSize(w, h);
    };

    window.addEventListener('resize', handleResize);

    return () => {
      cancelAnimationFrame(animId);
      window.removeEventListener('resize', handleResize);
      container.removeEventListener('mousemove', handleMouseMove);
      container.removeEventListener('mouseleave', handleMouseLeave);
      canvas.removeEventListener('click', handleClick);

      // Clean up Three.js resources
      topDomeGeo.dispose();
      topCylGeo.dispose();
      ringGeo.dispose();
      botCylGeo.dispose();
      botDomeGeo.dispose();
      ring1Geo.dispose();
      ring2Geo.dispose();
      particlesGeo.dispose();
      tealMaterial.dispose();
      whiteMaterial.dispose();
      silverRingMaterial.dispose();
      crossMat.dispose();
      ring1Mat.dispose();
      ring2Mat.dispose();
      particleMat.dispose();
      renderer.dispose();
    };
  }, []);

  return (
    <div
      ref={containerRef}
      onMouseEnter={() => setIsHovered(true)}
      onMouseLeave={() => setIsHovered(false)}
      className="relative w-full h-[240px] sm:h-[260px] flex items-center justify-center select-none"
    >
      {/* Interactive 3D Canvas */}
      <canvas
        ref={canvasRef}
        className="w-full h-full cursor-grab active:cursor-grabbing drop-shadow-xl"
      />

      {/* Floating Pill Badge 1: 100% Genuine */}
      <div className={`absolute top-2 right-2 sm:right-4 bg-white/90 dark:bg-slate-900/90 backdrop-blur-md border border-teal-200/80 dark:border-teal-800/80 px-2.5 py-1 rounded-full shadow-xs flex items-center gap-1.5 transition-all duration-300 pointer-events-none ${isHovered ? 'scale-105 -translate-y-0.5' : ''}`}>
        <ShieldCheck className="w-3.5 h-3.5 text-[#0bbbb6]" />
        <span className="text-[10px] font-extrabold text-slate-800 dark:text-slate-200 uppercase tracking-wider">
          100% Genuine
        </span>
      </div>

      {/* Floating Pill Badge 2: Live Stock Near You */}
      <div className={`absolute bottom-2 left-2 sm:left-4 bg-white/90 dark:bg-slate-900/90 backdrop-blur-md border border-emerald-200/80 dark:border-emerald-800/80 px-2.5 py-1 rounded-full shadow-xs flex items-center gap-1.5 transition-all duration-300 pointer-events-none ${isHovered ? 'scale-105 translate-y-0.5' : ''}`}>
        <span className="w-2 h-2 rounded-full bg-emerald-500 animate-pulse" />
        <span className="text-[10px] font-extrabold text-slate-800 dark:text-slate-200 uppercase tracking-wider">
          Live Stock
        </span>
      </div>

      {/* Subtle Interaction Hint Badge */}
      <div className="absolute bottom-1 right-2 sm:right-4 text-[9px] font-bold text-slate-400 dark:text-slate-500 uppercase tracking-widest pointer-events-none opacity-70">
        ✦ Interactive 3D
      </div>
    </div>
  );
}
