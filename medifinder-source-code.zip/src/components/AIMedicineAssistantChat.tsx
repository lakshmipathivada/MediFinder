import React, { useState, useRef, useEffect } from 'react';
import { 
  Send, 
  Sparkles, 
  Bot, 
  User, 
  RefreshCw, 
  Copy, 
  Check, 
  Volume2, 
  VolumeX, 
  ThumbsUp, 
  ThumbsDown,
  Zap,
  ArrowRight
} from 'lucide-react';
import { AISecurityService } from '../services/aiSecurityService';

interface Message {
  id: string;
  sender: 'user' | 'ai';
  text: string;
  timestamp: string;
  suggestions?: string[];
  feedback?: 'like' | 'dislike';
}

interface QuickAskQuestion {
  id: string;
  icon: string;
  badge: string;
  shortLabel: string;
  question: string;
  description: string;
}

const QUICK_ASK_QUESTIONS: QuickAskQuestion[] = [
  {
    id: 'dolo-food',
    icon: '🍽️',
    badge: 'Food & Timing',
    shortLabel: 'Dolo after food?',
    question: 'Can I take Dolo 650 after food?',
    description: 'Safe timing, stomach comfort, and absorption tips'
  },
  {
    id: 'azithral-dose',
    icon: '💊',
    badge: 'Antibiotics',
    shortLabel: 'Azithral 500 dosage',
    question: 'What is the dosage and course for Azithral 500?',
    description: 'Daily schedule, full course duration, and stomach rules'
  },
  {
    id: 'metformin-rules',
    icon: '🥣',
    badge: 'Diabetes Care',
    shortLabel: 'Metformin food rules',
    question: 'What are the food rules and timing for Metformin?',
    description: 'Taking with meals to avoid nausea and digestive upset'
  },
  {
    id: 'missed-dose',
    icon: '⏰',
    badge: 'Dose Advice',
    shortLabel: 'Missed a dose?',
    question: 'What should I do if I miss a dose of my medicine?',
    description: 'Safe action steps and why you should never take double'
  },
  {
    id: 'alcohol-paracetamol',
    icon: '🚫',
    badge: 'Safety Alert',
    shortLabel: 'Alcohol + Paracetamol?',
    question: 'Can I drink alcohol with Paracetamol or Dolo?',
    description: 'Critical liver warnings and safe waiting periods'
  },
  {
    id: 'headache-painkiller',
    icon: '⚡',
    badge: 'Fast Relief',
    shortLabel: 'Headache painkiller advice',
    question: 'What is a safe over-the-counter painkiller for headache?',
    description: 'Quick relief options, maximum daily limits, and caution'
  }
];

function parseAiResponse(raw: string): { mainText: string; suggestions: string[] } {
  if (!raw) return { mainText: '', suggestions: [] };
  
  const match = raw.match(/(?:Suggestions|Follow-ups):\s*(.*)$/im);
  if (!match) {
    return { mainText: raw.trim(), suggestions: [] };
  }
  
  const mainText = raw.replace(/(?:Suggestions|Follow-ups):\s*(.*)$/im, '').trim();
  const suggestionsRaw = match[1];
  const suggestions = suggestionsRaw
    .split('|')
    .map(s => s.trim().replace(/^\[|\]$/g, '').trim())
    .filter(s => s.length > 0 && s.length < 65);

  return { mainText, suggestions };
}

export default function AIMedicineAssistantChat({ 
  isEmbedded = false,
  initialPrompt = ''
}: { 
  isEmbedded?: boolean;
  initialPrompt?: string;
}) {
  const [messages, setMessages] = useState<Message[]>([
    {
      id: 'welcome-1',
      sender: 'ai',
      text: "Hi! I am your MediFinder AI Assistant 👋 Ask me any medicine or health question — I give quick, simple, and easy-to-understand answers!",
      timestamp: new Date().toLocaleTimeString([], { hour: '2-digit', minute: '2-digit' }),
      suggestions: ['Can I take Dolo after food?', 'Azithral 500 dosage', 'Safe painkiller advice']
    }
  ]);
  const [input, setInput] = useState('');
  const [loading, setLoading] = useState(false);
  const [copiedId, setCopiedId] = useState<string | null>(null);
  const [speakingId, setSpeakingId] = useState<string | null>(null);
  const messagesEndRef = useRef<HTMLDivElement>(null);

  const scrollToBottom = () => {
    messagesEndRef.current?.scrollIntoView({ behavior: 'smooth' });
  };

  useEffect(() => {
    scrollToBottom();
  }, [messages, loading]);

  // Clean up speech synthesis on unmount
  useEffect(() => {
    return () => {
      if (typeof window !== 'undefined' && 'speechSynthesis' in window) {
        window.speechSynthesis.cancel();
      }
    };
  }, []);

  // Handle incoming initial prompt from other screens (e.g. HomeScreen chips)
  useEffect(() => {
    if (initialPrompt && initialPrompt.trim()) {
      handleSendPrompt(initialPrompt.trim());
    }
  }, [initialPrompt]);

  const handleCopyText = (text: string, id: string) => {
    navigator.clipboard.writeText(text);
    setCopiedId(id);
    setTimeout(() => setCopiedId(null), 2000);
  };

  const handleSpeak = (text: string, id: string) => {
    if (typeof window === 'undefined' || !('speechSynthesis' in window)) return;
    
    if (speakingId === id) {
      window.speechSynthesis.cancel();
      setSpeakingId(null);
      return;
    }

    window.speechSynthesis.cancel();
    const cleanSpeech = text
      .replace(/💡\s*Tip:?/gi, 'Tip:')
      .replace(/[*#•-]/g, '')
      .trim();

    const utterance = new SpeechSynthesisUtterance(cleanSpeech);
    utterance.rate = 1.05;
    utterance.pitch = 1.0;
    utterance.onend = () => setSpeakingId(null);
    utterance.onerror = () => setSpeakingId(null);
    setSpeakingId(id);
    window.speechSynthesis.speak(utterance);
  };

  const handleFeedback = (id: string, type: 'like' | 'dislike') => {
    setMessages(prev => prev.map(m => m.id === id ? { ...m, feedback: type } : m));
  };

  const handleSendPrompt = (promptText: string) => {
    setInput(promptText);
    executeSend(promptText);
  };

  const handleSend = (e?: React.FormEvent) => {
    if (e) e.preventDefault();
    if (!input.trim() || loading) return;
    executeSend(input.trim());
  };

  const executeSend = async (userText: string) => {
    const userMsg: Message = {
      id: 'usr-' + Date.now(),
      sender: 'user',
      text: userText,
      timestamp: new Date().toLocaleTimeString([], { hour: '2-digit', minute: '2-digit' })
    };

    setMessages(prev => [...prev, userMsg]);
    setInput('');
    setLoading(true);

    try {
      let rawAiReply = '';

      const historyPayload = messages
        .filter(m => m.id !== 'welcome-1')
        .map(m => ({ sender: m.sender, text: m.text }));

      // Secure query with input sanitization, rate-limiting, and runtime key protection
      const secureResult = await AISecurityService.executeSecureChat(userText, historyPayload);

      if (secureResult.success && secureResult.reply) {
        rawAiReply = secureResult.reply;
      } else if (secureResult.error) {
        // Render rate-limit cooldown or security rejection warning directly to user
        const warnMsg: Message = {
          id: 'ai-warn-' + Date.now(),
          sender: 'ai',
          text: `⚠️ ${secureResult.error}`,
          suggestions: ['Safe painkiller advice', 'Can I take Dolo after food?'],
          timestamp: new Date().toLocaleTimeString([], { hour: '2-digit', minute: '2-digit' })
        };
        setMessages(prev => [...prev, warnMsg]);
        return;
      } else {
        rawAiReply = `I am currently operating in offline mode. Please check your medicine box or ask your pharmacist for exact instructions.\n\n💡 Tip: Always take medicines with plenty of plain water.\nSuggestions: Safe dosage? | Food instructions?`;
      }

      const { mainText, suggestions } = parseAiResponse(rawAiReply);

      const aiMsg: Message = {
        id: 'ai-' + Date.now(),
        sender: 'ai',
        text: mainText,
        suggestions,
        timestamp: new Date().toLocaleTimeString([], { hour: '2-digit', minute: '2-digit' })
      };
      setMessages(prev => [...prev, aiMsg]);
    } catch {
      const errorMsg: Message = {
        id: 'ai-err-' + Date.now(),
        sender: 'ai',
        text: "I couldn't process that right now. Please ask again or consult your local pharmacist.",
        suggestions: ['Can I take Dolo after food?', 'Azithral 500 dosage'],
        timestamp: new Date().toLocaleTimeString([], { hour: '2-digit', minute: '2-digit' })
      };
      setMessages(prev => [...prev, errorMsg]);
    } finally {
      setLoading(false);
    }
  };

  // Helper to render formatted markdown-style text safely and simply
  const renderFormattedText = (text: string) => {
    const lines = text.split('\n');
    return lines.map((line, idx) => {
      // Tip box (💡 Tip: ...)
      if (line.includes('💡') || line.toLowerCase().startsWith('tip:')) {
        return (
          <div key={idx} className="my-2 p-2.5 bg-teal-50 dark:bg-teal-950/40 border border-teal-200 dark:border-teal-800/80 rounded-xl text-xs font-semibold text-teal-800 dark:text-teal-200 flex items-start gap-1.5">
            <span className="shrink-0 text-sm">💡</span>
            <span>{renderBoldText(line.replace(/💡\s*/g, ''))}</span>
          </div>
        );
      }

      // Bullet points (• or -)
      if (line.trim().startsWith('•') || line.trim().startsWith('-')) {
        const bulletText = line.trim().replace(/^[•\-]\s*/, '');
        return (
          <div key={idx} className="flex items-start gap-2 ml-1 my-1 text-xs sm:text-sm">
            <span className="text-[#0bbbb6] font-black shrink-0 mt-0.5">•</span>
            <span className="font-medium text-slate-800 dark:text-slate-100">
              {renderBoldText(bulletText)}
            </span>
          </div>
        );
      }

      if (!line.trim()) {
        return <div key={idx} className="h-1" />;
      }

      return (
        <p key={idx} className="text-xs sm:text-sm leading-relaxed font-medium text-slate-800 dark:text-slate-100 my-0.5">
          {renderBoldText(line)}
        </p>
      );
    });
  };

  // Helper to parse **bold** markup
  const renderBoldText = (str: string) => {
    const parts = str.split(/(\*\*.*?\*\*)/g);
    return parts.map((part, i) => {
      if (part.startsWith('**') && part.endsWith('**')) {
        return <strong key={i} className="font-black text-slate-900 dark:text-white">{part.slice(2, -2)}</strong>;
      }
      return part;
    });
  };

  return (
    <div className={`flex flex-col ${isEmbedded ? 'h-[calc(100vh-140px)]' : 'h-[620px]'} max-w-3xl mx-auto bg-white dark:bg-slate-900 border border-slate-200/80 dark:border-slate-800 rounded-3xl overflow-hidden shadow-xs animate-fade-in`}>
      
      {/* Header */}
      <div className="p-4 border-b border-slate-200/80 dark:border-slate-800 bg-slate-50/90 dark:bg-slate-950/90 backdrop-blur-md flex items-center justify-between">
        <div className="flex items-center gap-3">
          <div className="w-10 h-10 rounded-2xl bg-gradient-to-br from-[#0bbbb6] to-teal-600 text-white flex items-center justify-center font-bold shadow-xs">
            <Bot className="w-5 h-5" />
          </div>
          <div>
            <h2 className="text-sm font-extrabold text-slate-900 dark:text-white flex items-center gap-2">
              <span>MediFinder AI</span>
              <span className="inline-flex items-center gap-1 px-2 py-0.2 rounded-full text-[10px] font-black bg-emerald-100 dark:bg-emerald-950/60 text-emerald-700 dark:text-emerald-300 border border-emerald-300/40">
                <span className="w-1.5 h-1.5 rounded-full bg-emerald-500 animate-pulse" />
                Fast & Live
              </span>
            </h2>
            <p className="text-[11px] text-slate-500 dark:text-slate-400 font-medium">
              Simple, easy-to-understand medicine guidance
            </p>
          </div>
        </div>

        <button
          onClick={() => {
            if (typeof window !== 'undefined' && 'speechSynthesis' in window) {
              window.speechSynthesis.cancel();
            }
            setSpeakingId(null);
            setMessages([messages[0]]);
          }}
          className="p-2 text-slate-400 hover:text-slate-600 dark:hover:text-slate-200 rounded-xl hover:bg-slate-200/50 dark:hover:bg-slate-800 transition cursor-pointer"
          title="Clear chat"
        >
          <RefreshCw className="w-4 h-4" />
        </button>
      </div>

      {/* Quick Ask Top Carousel Bar */}
      <div className="px-4 py-3 sm:py-3.5 min-h-[62px] bg-gradient-to-r from-teal-50/90 via-white to-emerald-50/80 dark:from-slate-900 dark:via-slate-900 dark:to-teal-950/40 border-b border-teal-200/80 dark:border-slate-800 flex items-center gap-2.5 overflow-x-auto no-scrollbar shadow-xs">
        <div className="h-10 flex items-center gap-2 px-3.5 py-2 rounded-full bg-gradient-to-r from-amber-500/20 to-orange-500/20 text-amber-900 dark:text-amber-200 border-2 border-amber-400/60 text-xs font-black tracking-wider uppercase shrink-0 shadow-xs">
          <Zap className="w-4 h-4 text-amber-600 dark:text-amber-400 fill-amber-500" />
          <span>Quick Ask:</span>
        </div>
        
        {QUICK_ASK_QUESTIONS.map((item) => (
          <button
            key={item.id}
            onClick={() => handleSendPrompt(item.question)}
            disabled={loading}
            title={item.question}
            className="h-10 group flex items-center gap-2 px-4 py-2 bg-white dark:bg-slate-800 hover:bg-[#0bbbb6] dark:hover:bg-[#0bbbb6] text-slate-800 dark:text-slate-100 hover:text-white dark:hover:text-white border-2 border-teal-200/90 dark:border-slate-700 hover:border-[#0bbbb6] dark:hover:border-[#0bbbb6] rounded-full text-xs sm:text-[13px] font-extrabold transition-all duration-200 whitespace-nowrap shrink-0 cursor-pointer shadow-xs hover:shadow-md active:scale-95 disabled:opacity-50"
          >
            <span className="text-base shrink-0">{item.icon}</span>
            <span className="font-bold">{item.shortLabel}</span>
            <ArrowRight className="w-3.5 h-3.5 opacity-40 group-hover:opacity-100 group-hover:translate-x-0.5 transition-all text-slate-500 group-hover:text-white" />
          </button>
        ))}
      </div>

      {/* Messages Feed */}
      <div className="flex-grow p-4 sm:p-5 overflow-y-auto space-y-4">
        {messages.map((m) => (
          <div
            key={m.id}
            className={`flex items-start gap-2.5 sm:gap-3 ${m.sender === 'user' ? 'flex-row-reverse' : 'flex-row'}`}
          >
            <div className={`w-8 h-8 rounded-full flex items-center justify-center text-xs font-bold shrink-0 mt-0.5 ${
              m.sender === 'user' 
                ? 'bg-[#0bbbb6] text-white shadow-2xs' 
                : 'bg-slate-800 text-[#0bbbb6] border border-teal-500/30 shadow-2xs'
            }`}>
              {m.sender === 'user' ? <User className="w-4 h-4" /> : <Bot className="w-4 h-4" />}
            </div>

            <div className={`max-w-[85%] sm:max-w-[78%] rounded-2xl p-3.5 sm:p-4 space-y-2 ${
              m.sender === 'user'
                ? 'bg-[#0bbbb6] text-white rounded-tr-none font-medium shadow-xs'
                : 'bg-slate-50 dark:bg-slate-800/90 text-slate-800 dark:text-slate-100 rounded-tl-none border border-slate-200/80 dark:border-slate-700/80 shadow-xs'
            }`}>
              {m.sender === 'user' ? (
                <p className="text-xs sm:text-sm leading-relaxed whitespace-pre-wrap font-semibold">
                  {m.text}
                </p>
              ) : (
                <div className="space-y-1">
                  {renderFormattedText(m.text)}
                </div>
              )}

              {/* Interactive Follow-up Suggestion Chips */}
              {m.sender === 'ai' && m.suggestions && m.suggestions.length > 0 && (
                <div className="pt-3 border-t border-slate-200/80 dark:border-slate-700/80 space-y-2">
                  <div className="flex items-center gap-1.5">
                    <span className="inline-flex items-center gap-1 px-2 py-0.5 rounded-md bg-teal-100/80 dark:bg-teal-950/80 text-[#078e8a] dark:text-teal-300 text-[10px] font-black uppercase tracking-wider border border-teal-300/40">
                      <Sparkles className="w-3 h-3 text-[#0bbbb6]" />
                      Suggested Next
                    </span>
                    <span className="text-[11px] text-slate-500 dark:text-slate-400 font-semibold">
                      Tap to follow up:
                    </span>
                  </div>
                  <div className="flex flex-wrap items-center gap-2">
                    {m.suggestions.map((sug, sIdx) => (
                      <button
                        key={sIdx}
                        onClick={() => handleSendPrompt(sug)}
                        disabled={loading}
                        className="group px-3 py-1.5 bg-gradient-to-r from-teal-50 to-white dark:from-slate-800 dark:to-slate-900 hover:from-[#0bbbb6] hover:to-teal-600 text-slate-800 dark:text-slate-100 hover:text-white dark:hover:text-white border-2 border-teal-200/80 dark:border-slate-700 hover:border-[#0bbbb6] rounded-xl text-xs font-bold transition-all duration-200 shadow-xs hover:shadow-md active:scale-95 cursor-pointer flex items-center gap-1.5"
                      >
                        <span className="text-teal-600 dark:text-teal-400 group-hover:text-white text-xs">💬</span>
                        <span>{sug}</span>
                        <ArrowRight className="w-3.5 h-3.5 text-teal-600 dark:text-teal-400 group-hover:text-white group-hover:translate-x-0.5 transition-transform shrink-0" />
                      </button>
                    ))}
                  </div>
                </div>
              )}

              {/* Interactive Toolbar for AI replies: Voice, Copy, Feedback */}
              <div className={`flex items-center justify-between gap-2 pt-1 text-[10px] font-semibold ${m.sender === 'user' ? 'text-teal-100 justify-end' : 'text-slate-400'}`}>
                {m.sender === 'ai' ? (
                  <div className="flex items-center gap-2">
                    {/* Speak / Stop Button */}
                    <button
                      onClick={() => handleSpeak(m.text, m.id)}
                      className={`inline-flex items-center gap-1 px-1.5 py-0.5 rounded-lg transition cursor-pointer ${
                        speakingId === m.id 
                          ? 'bg-[#0bbbb6] text-white font-bold animate-pulse' 
                          : 'hover:text-[#0bbbb6] dark:hover:text-teal-300'
                      }`}
                      title={speakingId === m.id ? "Stop voice" : "Listen to advice"}
                    >
                      {speakingId === m.id ? (
                        <>
                          <VolumeX className="w-3 h-3" />
                          <span>Stop</span>
                        </>
                      ) : (
                        <>
                          <Volume2 className="w-3 h-3" />
                          <span>Listen</span>
                        </>
                      )}
                    </button>

                    {/* Copy Button */}
                    <button
                      onClick={() => handleCopyText(m.text, m.id)}
                      className="inline-flex items-center gap-1 hover:text-[#0bbbb6] dark:hover:text-teal-300 transition cursor-pointer"
                      title="Copy response"
                    >
                      {copiedId === m.id ? (
                        <>
                          <Check className="w-3 h-3 text-emerald-500" />
                          <span className="text-emerald-500 font-bold">Copied</span>
                        </>
                      ) : (
                        <>
                          <Copy className="w-3 h-3" />
                          <span>Copy</span>
                        </>
                      )}
                    </button>

                    {/* Thumbs Up / Down Feedback */}
                    <div className="flex items-center gap-1 pl-1 border-l border-slate-200 dark:border-slate-700">
                      <button
                        onClick={() => handleFeedback(m.id, 'like')}
                        className={`p-0.8 rounded hover:text-emerald-600 transition cursor-pointer ${m.feedback === 'like' ? 'text-emerald-600 font-bold' : ''}`}
                        title="Helpful"
                      >
                        <ThumbsUp className="w-2.8 h-2.8" />
                      </button>
                      <button
                        onClick={() => handleFeedback(m.id, 'dislike')}
                        className={`p-0.8 rounded hover:text-rose-600 transition cursor-pointer ${m.feedback === 'dislike' ? 'text-rose-600 font-bold' : ''}`}
                        title="Not helpful"
                      >
                        <ThumbsDown className="w-2.8 h-2.8" />
                      </button>
                    </div>
                  </div>
                ) : null}

                <span>{m.timestamp}</span>
              </div>
            </div>
          </div>
        ))}

        {/* Quick Ask Questions Card Launcher Hub (Shown when starting conversation) */}
        {messages.length <= 1 && (
          <div className="mt-2 mb-2 p-4 sm:p-5 rounded-3xl bg-gradient-to-br from-teal-500/10 via-emerald-500/5 to-cyan-500/10 dark:from-teal-950/40 dark:via-slate-900/60 dark:to-cyan-950/30 border-2 border-teal-500/30 dark:border-teal-500/20 shadow-xs animate-fade-in space-y-3.5">
            <div className="flex items-center justify-between">
              <div className="flex items-center gap-2.5">
                <div className="w-8 h-8 rounded-xl bg-gradient-to-tr from-amber-500 to-orange-500 text-white flex items-center justify-center font-black shadow-xs">
                  <Zap className="w-4 h-4 fill-white" />
                </div>
                <div>
                  <h3 className="text-xs sm:text-sm font-extrabold text-slate-900 dark:text-white flex items-center gap-1.5">
                    <span>Popular Quick Questions</span>
                    <span className="text-[10px] font-black uppercase px-2 py-0.5 rounded-full bg-amber-500/20 text-amber-800 dark:text-amber-300 border border-amber-500/30">
                      1-Tap Answers
                    </span>
                  </h3>
                  <p className="text-[11px] text-slate-600 dark:text-slate-400 font-medium">
                    Tap any question below for an immediate, simplified clinical guide
                  </p>
                </div>
              </div>
            </div>

            <div className="grid grid-cols-1 sm:grid-cols-2 gap-2.5">
              {QUICK_ASK_QUESTIONS.map((item) => (
                <button
                  key={item.id}
                  onClick={() => handleSendPrompt(item.question)}
                  disabled={loading}
                  className="p-3 bg-white dark:bg-slate-800/90 hover:bg-gradient-to-br hover:from-teal-50 hover:to-white dark:hover:from-teal-950/60 dark:hover:to-slate-800 border-2 border-slate-200/80 dark:border-slate-700/80 hover:border-[#0bbbb6] dark:hover:border-[#0bbbb6] rounded-2xl text-left transition-all duration-200 shadow-xs hover:shadow-md cursor-pointer group flex flex-col justify-between disabled:opacity-50"
                >
                  <div className="space-y-1.5">
                    <div className="flex items-center justify-between">
                      <span className="w-7 h-7 rounded-xl bg-teal-50 dark:bg-teal-950/80 border border-teal-200/60 dark:border-teal-800 flex items-center justify-center text-sm shadow-2xs">
                        {item.icon}
                      </span>
                      <span className="text-[10px] font-extrabold uppercase tracking-wider px-2 py-0.5 rounded-md bg-slate-100 dark:bg-slate-700/80 text-slate-600 dark:text-slate-300 group-hover:bg-[#0bbbb6]/15 group-hover:text-[#0bbbb6] dark:group-hover:text-teal-300 transition">
                        {item.badge}
                      </span>
                    </div>
                    <h4 className="text-xs sm:text-sm font-black text-slate-900 dark:text-white group-hover:text-[#0bbbb6] transition leading-snug">
                      {item.question}
                    </h4>
                    <p className="text-[11px] text-slate-500 dark:text-slate-400 font-medium leading-relaxed">
                      {item.description}
                    </p>
                  </div>

                  <div className="mt-2.5 pt-2 border-t border-slate-100 dark:border-slate-700/50 flex items-center justify-between text-[11px] font-extrabold text-[#0bbbb6]">
                    <span>Ask this now</span>
                    <ArrowRight className="w-3.5 h-3.5 group-hover:translate-x-1 transition-transform" />
                  </div>
                </button>
              ))}
            </div>
          </div>
        )}

        {/* Ultra-fast live typing indicator */}
        {loading && (
          <div className="flex items-center gap-2.5 animate-fade-in">
            <div className="w-8 h-8 rounded-full bg-slate-800 text-[#0bbbb6] border border-teal-500/30 flex items-center justify-center shrink-0 shadow-2xs">
              <Sparkles className="w-4 h-4 animate-spin text-[#0bbbb6]" />
            </div>
            <div className="bg-slate-100 dark:bg-slate-800/90 rounded-2xl px-3.5 py-2.5 text-xs text-slate-600 dark:text-slate-300 font-bold border border-slate-200 dark:border-slate-700 flex items-center gap-2">
              <span className="flex gap-1">
                <span className="w-1.5 h-1.5 bg-[#0bbbb6] rounded-full animate-bounce" style={{ animationDelay: '0ms' }} />
                <span className="w-1.5 h-1.5 bg-[#0bbbb6] rounded-full animate-bounce" style={{ animationDelay: '150ms' }} />
                <span className="w-1.5 h-1.5 bg-[#0bbbb6] rounded-full animate-bounce" style={{ animationDelay: '300ms' }} />
              </span>
              <span>Thinking...</span>
            </div>
          </div>
        )}

        <div ref={messagesEndRef} />
      </div>

      {/* Input Form */}
      <form onSubmit={handleSend} className="p-3 bg-white dark:bg-slate-900 border-t border-slate-200/80 dark:border-slate-800 flex items-center gap-2">
        <input
          type="text"
          value={input}
          onChange={(e) => setInput(e.target.value)}
          placeholder="Ask a question (e.g. Can I take Dolo after food?)..."
          className="flex-grow px-4 py-2.5 bg-slate-50 dark:bg-slate-800 border border-slate-200 dark:border-slate-700 rounded-2xl text-xs sm:text-sm focus:outline-none focus:ring-2 focus:ring-[#0bbbb6] dark:text-white font-medium"
        />
        <button
          type="submit"
          disabled={!input.trim() || loading}
          className="px-4 py-2.5 bg-[#0bbbb6] hover:bg-[#0aa6a1] disabled:opacity-50 text-white rounded-2xl font-bold transition cursor-pointer flex items-center gap-1.5 shadow-2xs shrink-0"
        >
          <Send className="w-4 h-4" />
          <span className="hidden sm:inline text-xs">Send</span>
        </button>
      </form>

    </div>
  );
}
