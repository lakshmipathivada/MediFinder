import React, { useState } from 'react';
import { Play, Pause, X, Tv, Volume2, VolumeX, ShieldCheck } from 'lucide-react';
import { VoiceAssistant } from '../services/voiceAssistant';

export default function AIVideoTour({ onClose }: { onClose: () => void }) {
  const [isPlaying, setIsPlaying] = useState(false);
  const [isMuted, setIsMuted] = useState(false);

  const tourScript = [
    "Welcome to MediFinder! Your intelligent medicine reminder and pharmacy discovery companion.",
    "First, MediFinder lets you set precise background medicine reminders with custom dosage times and food instructions.",
    "Even when your phone is locked or the app is closed, high-priority notifications ring with alarm chimes and voice alerts.",
    "Second, search real-time medicine availability across local pharmacies with distance calculations.",
    "Third, ask our AI assistant any medical query regarding drug dosages or food guidelines.",
    "Stay healthy with MediFinder!"
  ];

  const handlePlay = () => {
    setIsPlaying(true);
    if (!isMuted) {
      VoiceAssistant.speak(tourScript.join(' '));
    }
  };

  const handlePause = () => {
    setIsPlaying(false);
    VoiceAssistant.stop();
  };

  const handleClose = () => {
    VoiceAssistant.stop();
    onClose();
  };

  return (
    <div className="fixed inset-0 z-50 bg-slate-950/80 backdrop-blur-md flex items-center justify-center p-4 animate-fade-in">
      <div className="bg-white dark:bg-slate-900 border border-slate-200/80 dark:border-slate-800 rounded-3xl max-w-xl w-full p-6 space-y-5 shadow-2xl relative">
        
        <button
          onClick={handleClose}
          className="absolute top-4 right-4 p-2 text-slate-400 hover:text-slate-600 dark:hover:text-white rounded-full hover:bg-slate-100 dark:hover:bg-slate-800 transition"
        >
          <X className="w-5 h-5" />
        </button>

        <div className="flex items-center gap-3">
          <div className="p-2.5 bg-[#0bbbb6]/10 text-[#0bbbb6] rounded-2xl">
            <Tv className="w-6 h-6" />
          </div>
          <div>
            <h2 className="text-lg font-extrabold text-slate-900 dark:text-white">
              MediFinder Presentation Tour
            </h2>
            <p className="text-xs text-slate-500 dark:text-slate-400 font-medium">
              Interactive voice presentation & application overview
            </p>
          </div>
        </div>

        {/* Simulated Video Canvas */}
        <div className="relative aspect-video bg-gradient-to-br from-slate-900 via-teal-950 to-slate-950 rounded-2xl overflow-hidden border border-slate-800 flex flex-col justify-between p-6 text-white shadow-inner">
          <div className="flex items-center justify-between text-xs font-bold text-teal-400">
            <span className="flex items-center gap-1.5">
              <ShieldCheck className="w-4 h-4" />
              <span>MediFinder Tour</span>
            </span>
            <span className="px-2 py-0.5 rounded-full bg-teal-500/20 border border-teal-500/30 text-[10px]">
              HD Audio
            </span>
          </div>

          <div className="text-center space-y-2 max-w-md mx-auto">
            <div className="w-16 h-16 rounded-full bg-[#0bbbb6]/20 text-[#0bbbb6] flex items-center justify-center mx-auto border border-[#0bbbb6]/40 animate-pulse">
              <Tv className="w-8 h-8" />
            </div>
            <p className="text-xs sm:text-sm font-semibold leading-relaxed text-teal-100">
              {isPlaying ? "Playing voice presentation..." : "Tap play to listen to the presentation guide"}
            </p>
          </div>

          <div className="flex items-center justify-between">
            <button
              onClick={isPlaying ? handlePause : handlePlay}
              className="px-4 py-2 bg-[#0bbbb6] hover:bg-[#0aa6a1] text-white rounded-xl text-xs font-bold flex items-center gap-2 cursor-pointer transition shadow-md"
            >
              {isPlaying ? <Pause className="w-4 h-4" /> : <Play className="w-4 h-4" />}
              <span>{isPlaying ? "Pause Tour" : "Play Presentation"}</span>
            </button>

            <button
              onClick={() => setIsMuted(!isMuted)}
              className="p-2 bg-slate-800 text-slate-300 hover:text-white rounded-xl transition"
            >
              {isMuted ? <VolumeX className="w-4 h-4" /> : <Volume2 className="w-4 h-4" />}
            </button>
          </div>
        </div>

        <div className="pt-2 text-right">
          <button
            onClick={handleClose}
            className="px-5 py-2.5 bg-slate-100 hover:bg-slate-200 dark:bg-slate-800 dark:hover:bg-slate-700 text-slate-700 dark:text-slate-200 rounded-2xl text-xs font-bold transition cursor-pointer"
          >
            Close Tour
          </button>
        </div>

      </div>
    </div>
  );
}
