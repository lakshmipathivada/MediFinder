import React, { useState } from 'react';
import { Navigation, X, MapPin, Phone, Clock, Compass, AlertCircle } from 'lucide-react';
import { Pharmacy } from '../types';
import { getGoogleMapsNavigationUrl, isValidCoordinate } from '../services/locationService';

export default function PharmacyStreetNavigationModal({
  pharmacy,
  userCoords,
  onClose
}: {
  pharmacy: Pharmacy;
  userCoords?: { lat: number; lng: number } | null;
  onClose: () => void;
}) {
  const [navError, setNavError] = useState<string | null>(null);

  const hasValidCoords = isValidCoordinate(pharmacy.lat, pharmacy.lng);
  const mapsUrl = getGoogleMapsNavigationUrl(pharmacy.lat, pharmacy.lng, userCoords?.lat, userCoords?.lng);

  const handleOpenNavigation = (e: React.MouseEvent) => {
    if (!hasValidCoords) {
      e.preventDefault();
      setNavError('Unable to start navigation: Invalid latitude or longitude coordinates for this pharmacy.');
    }
  };

  return (
    <div className="fixed inset-0 z-50 bg-slate-950/80 backdrop-blur-md flex items-center justify-center p-4 animate-fade-in">
      <div className="bg-white dark:bg-slate-900 border border-slate-200/80 dark:border-slate-800 rounded-3xl max-w-xl w-full p-6 space-y-5 shadow-2xl relative">
        
        <button
          onClick={onClose}
          className="absolute top-4 right-4 p-2 text-slate-400 hover:text-slate-600 dark:hover:text-white rounded-full hover:bg-slate-100 dark:hover:bg-slate-800 transition"
        >
          <X className="w-5 h-5" />
        </button>

        <div className="flex items-center gap-3">
          <div className="p-2.5 bg-[#0bbbb6]/10 text-[#0bbbb6] rounded-2xl">
            <Compass className="w-6 h-6" />
          </div>
          <div>
            <h2 className="text-lg font-extrabold text-slate-900 dark:text-white">
              Turn-by-Turn Pharmacy Navigation
            </h2>
            <p className="text-xs text-slate-500 dark:text-slate-400 font-medium">
              Live GPS routing to {pharmacy.name}
            </p>
          </div>
        </div>

        {navError && (
          <div className="p-3 bg-rose-50 dark:bg-rose-950/40 border border-rose-300 dark:border-rose-800 rounded-2xl text-xs font-bold text-rose-800 dark:text-rose-300 flex items-center gap-2">
            <AlertCircle className="w-4 h-4 text-rose-600 shrink-0" />
            <span>{navError}</span>
          </div>
        )}

        {/* Map placeholder canvas */}
        <div className="relative aspect-video bg-slate-100 dark:bg-slate-800 rounded-2xl border border-slate-200 dark:border-slate-700 overflow-hidden flex flex-col items-center justify-center text-center p-6 space-y-3">
          <div className="w-14 h-14 rounded-full bg-[#0bbbb6]/20 text-[#0bbbb6] flex items-center justify-center border border-[#0bbbb6]/40">
            <Navigation className="w-7 h-7 animate-bounce" />
          </div>

          <div className="space-y-1">
            <div className="text-sm font-bold text-slate-900 dark:text-white">
              {pharmacy.name}
            </div>
            <div className="text-xs text-slate-500 dark:text-slate-400 font-medium">
              {pharmacy.address} • {pharmacy.distanceKm} km away
            </div>
            <div className="text-[11px] font-mono text-[#0bbbb6]">
              Exact GPS Target: {pharmacy.lat.toFixed(5)}°, {pharmacy.lng.toFixed(5)}°
            </div>
          </div>
        </div>

        <div className="flex items-center justify-between pt-2">
          <a
            href={mapsUrl}
            onClick={handleOpenNavigation}
            target="_blank"
            rel="noopener noreferrer"
            className="px-5 py-2.5 bg-[#0bbbb6] hover:bg-[#0aa6a1] text-white rounded-2xl text-xs font-bold transition flex items-center gap-2 cursor-pointer shadow-md"
          >
            <Navigation className="w-4 h-4" />
            <span>Open Google Maps</span>
          </a>

          <button
            onClick={onClose}
            className="px-4 py-2.5 bg-slate-100 hover:bg-slate-200 dark:bg-slate-800 dark:hover:bg-slate-700 text-slate-700 dark:text-slate-200 rounded-2xl text-xs font-bold transition cursor-pointer"
          >
            Done
          </button>
        </div>

      </div>
    </div>
  );
}
