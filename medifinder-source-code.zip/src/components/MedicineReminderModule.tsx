import React, { useState, useEffect } from 'react';
import { 
  Bell, 
  Plus, 
  Pill, 
  Clock, 
  CheckCircle2, 
  XCircle, 
  AlertCircle, 
  Volume2, 
  VolumeX, 
  Trash2, 
  Edit, 
  Power, 
  ShieldCheck, 
  Check, 
  X, 
  Zap, 
  Calendar,
  Sparkles,
  Info,
  RotateCcw,
  Radio,
  Smartphone,
  ShieldAlert,
  HelpCircle,
  Download
} from 'lucide-react';
import { reminderStore } from '../services/reminderStore';
import { VoiceAssistant, AlarmChimeEngine, AlarmToneType } from '../services/voiceAssistant';
import { PushNotificationService } from '../services/pushNotificationService';
import { firestoreSyncService, SyncState } from '../services/firestoreSyncService';
import { NativeAlarmBridge } from '../services/nativeAlarmBridge';
import { BackgroundAudioKeepAlive } from '../services/backgroundAudioKeepAlive';
import { MedicineReminder, DoseLog } from '../types';

interface MedicineReminderModuleProps {
  currentUser: { name: string; phone: string };
  initialSubTab?: 'schedule' | 'reminders' | 'add' | 'history';
}

export default function MedicineReminderModule({
  currentUser,
  initialSubTab = 'schedule'
}: MedicineReminderModuleProps) {
  const [subTab, setSubTab] = useState<'schedule' | 'reminders' | 'add' | 'history'>(initialSubTab);
  const [reminders, setReminders] = useState<MedicineReminder[]>([]);
  const [logs, setLogs] = useState<DoseLog[]>([]);
  const [currentTime, setCurrentTime] = useState(new Date());

  // Active Alarm ringing overlay state
  const [activeAlarm, setActiveAlarm] = useState<{ reminder: MedicineReminder; timeSlot: string } | null>(null);

  // Form state for creating/editing reminders
  const [editingReminder, setEditingReminder] = useState<MedicineReminder | null>(null);
  const [medicineName, setMedicineName] = useState('');
  const [medicineType, setMedicineType] = useState('Tablet');
  const [dosage, setDosage] = useState('1 tablet');
  const [times, setTimes] = useState<string[]>(['08:00']);
  const [foodInstruction, setFoodInstruction] = useState('After Food');
  const [frequency, setFrequency] = useState('Daily');
  const [notes, setNotes] = useState('');

  // Notification Permission & Web Push state
  const [notificationPermission, setNotificationPermission] = useState<NotificationPermission>('default');
  const [isPushEnabled, setIsPushEnabled] = useState<boolean>(() => PushNotificationService.isLocallyEnabled());
  const [isSubscribingPush, setIsSubscribingPush] = useState<boolean>(false);
  const [testCountdown, setTestCountdown] = useState<number | null>(null);
  const [pushStatusMessage, setPushStatusMessage] = useState<string | null>(null);
  const [cloudSyncState, setCloudSyncState] = useState<SyncState>(() => firestoreSyncService.getStatus());

  // Background Audio Guard & Native Capacitor Alarm states
  const [isBackgroundGuardActive, setIsBackgroundGuardActive] = useState<boolean>(() => BackgroundAudioKeepAlive.isActive());
  const [deferredInstallPrompt, setDeferredInstallPrompt] = useState<any>(null);
  const [isNativeApp, setIsNativeApp] = useState<boolean>(() => NativeAlarmBridge.isNativeApp());
  const [showDiagnosticModal, setShowDiagnosticModal] = useState<boolean>(false);

  useEffect(() => {
    const unsubGuard = BackgroundAudioKeepAlive.onStatusChange((active) => {
      setIsBackgroundGuardActive(active);
    });

    const handleBeforeInstall = (e: any) => {
      e.preventDefault();
      setDeferredInstallPrompt(e);
    };
    if (typeof window !== 'undefined') {
      window.addEventListener('beforeinstallprompt', handleBeforeInstall);
    }

    if (NativeAlarmBridge.isNativeApp()) {
      NativeAlarmBridge.initAlarmChannels();
      NativeAlarmBridge.addActionListener((actionId, extra) => {
        if (actionId === 'take_dose' && extra?.reminderId) {
          reminderStore.recordDoseAction(
            currentUser.phone,
            extra.reminderId,
            extra.timeSlot || '08:00',
            'taken_on_time',
            extra.medicineName
          );
        } else if (actionId === 'snooze_10' && extra?.reminderId) {
          reminderStore.snoozeReminder(currentUser.phone, extra.reminderId, 10);
        }
      });
    }

    return () => {
      unsubGuard();
      if (typeof window !== 'undefined') {
        window.removeEventListener('beforeinstallprompt', handleBeforeInstall);
      }
    };
  }, [currentUser.phone]);

  const handleToggleBackgroundGuard = async () => {
    const active = await BackgroundAudioKeepAlive.toggle();
    setIsBackgroundGuardActive(active);
  };

  const handleInstallApp = async () => {
    if (deferredInstallPrompt) {
      deferredInstallPrompt.prompt();
      const choice = await deferredInstallPrompt.userChoice;
      if (choice.outcome === 'accepted') {
        setDeferredInstallPrompt(null);
      }
    }
  };

  useEffect(() => {
    const unsub = firestoreSyncService.onStatusChange((s) => setCloudSyncState(s));
    return unsub;
  }, []);
  
  // Alarm Tone Sound Style state
  const [alarmTone, setAlarmTone] = useState<AlarmToneType>(() => AlarmChimeEngine.getAlarmTone());
  const [isPlayingPreview, setIsPlayingPreview] = useState<boolean>(false);

  const handleSelectAlarmTone = (tone: AlarmToneType) => {
    AlarmChimeEngine.setAlarmTone(tone);
    setAlarmTone(tone);
    setIsPlayingPreview(true);
    AlarmChimeEngine.preview(tone);
    setTimeout(() => setIsPlayingPreview(false), 2800);
  };

  useEffect(() => {
    if (typeof window !== 'undefined' && 'Notification' in window) {
      setNotificationPermission(Notification.permission);
      PushNotificationService.getExistingSubscription().then(sub => {
        if (sub && Notification.permission === 'granted') {
          setIsPushEnabled(true);
        }
      });
    }
  }, []);

  const loadData = () => {
    const currentReminders = reminderStore.getReminders(currentUser.phone);
    setReminders(currentReminders);
    setLogs(reminderStore.getLogs(currentUser.phone));
    PushNotificationService.syncReminders(currentUser.phone, currentReminders);
  };

  useEffect(() => {
    loadData();
    const unsubscribe = reminderStore.subscribe(loadData);
    return unsubscribe;
  }, [currentUser.phone]);

  const handleEnablePushReminders = async () => {
    setIsSubscribingPush(true);
    setPushStatusMessage(null);
    const result = await PushNotificationService.subscribe(currentUser.phone, reminders);
    setIsSubscribingPush(false);
    if (result.success) {
      setIsPushEnabled(true);
      setNotificationPermission('granted');
      setPushStatusMessage('✅ Background Alerts Active! Reminders will ring even when app/browser is closed.');
    } else {
      setPushStatusMessage(`⚠️ Could not activate: ${result.error}`);
    }
  };

  const handleTriggerTestAlert = async () => {
    setIsSubscribingPush(true);
    setPushStatusMessage('⚡ Scheduling test background alert in 5 seconds...');
    
    const res = await PushNotificationService.sendTestNotification(5);
    setIsSubscribingPush(false);

    if (res.success) {
      setTestCountdown(5);
      setPushStatusMessage('🚀 Alert scheduled! YOU CAN SAFELY CLOSE THIS TAB RIGHT NOW to test.');
      
      let count = 5;
      const interval = setInterval(() => {
        count -= 1;
        if (count > 0) {
          setTestCountdown(count);
        } else {
          clearInterval(interval);
          setTestCountdown(null);
          setPushStatusMessage('🎉 Test alert sent! Check your Windows Notification or notification shade.');
        }
      }, 1000);
    } else {
      setPushStatusMessage(`⚠️ Could not schedule test: ${res.error}`);
    }
  };

  // Update clock every second
  useEffect(() => {
    const timer = setInterval(() => {
      setCurrentTime(new Date());
    }, 1000);
    return () => clearInterval(timer);
  }, []);

  // Listen for Service Worker background notification click actions
  useEffect(() => {
    if (typeof window !== 'undefined' && 'serviceWorker' in navigator) {
      const handleMessage = (event: MessageEvent) => {
        if (event.data && event.data.type === 'NOTIFICATION_ACTION') {
          const { action, reminderId, timeSlot } = event.data;
          const rem = reminders.find(r => r.id === reminderId);
          if (rem) {
            if (action === 'take') {
              reminderStore.recordDoseAction(currentUser.phone, rem.id, timeSlot || '08:00', 'taken_on_time');
            } else if (action === 'skip') {
              reminderStore.recordDoseAction(currentUser.phone, rem.id, timeSlot || '08:00', 'skipped');
            } else if (action === 'snooze') {
              reminderStore.snoozeReminder(currentUser.phone, rem.id, 10);
            }
          }
        }
      };
      navigator.serviceWorker.addEventListener('message', handleMessage);
      return () => navigator.serviceWorker.removeEventListener('message', handleMessage);
    }
  }, [reminders, currentUser.phone]);

  // Unlock AudioContext & SpeechSynthesis on user tap
  useEffect(() => {
    const unlockAudio = () => {
      // Only prime the audio engine if no alarm is actively ringing
      if (!activeAlarm) {
        AlarmChimeEngine.start();
        AlarmChimeEngine.stop();
      } else {
        AlarmChimeEngine.start();
      }
      if (typeof window !== 'undefined' && 'speechSynthesis' in window) {
        window.speechSynthesis.resume();
      }
      window.removeEventListener('click', unlockAudio);
      window.removeEventListener('touchstart', unlockAudio);
    };
    window.addEventListener('click', unlockAudio);
    window.addEventListener('touchstart', unlockAudio);
    return () => {
      window.removeEventListener('click', unlockAudio);
      window.removeEventListener('touchstart', unlockAudio);
    };
  }, [activeAlarm]);

  // Background timer check loop for reminders
  useEffect(() => {
    if (activeAlarm) return;

    const hours = currentTime.getHours().toString().padStart(2, '0');
    const minutes = currentTime.getMinutes().toString().padStart(2, '0');
    const currentSlot = `${hours}:${minutes}`;
    const seconds = currentTime.getSeconds();

    if (seconds !== 0) return; // Trigger on exact minute boundary

    reminders.forEach((rem) => {
      if (!rem.active) return;
      if (rem.snoozedUntil && Date.now() < rem.snoozedUntil) return;

      const matchesTime = rem.times.includes(currentSlot);
      const isSnoozeExpired = rem.snoozedUntil && Date.now() >= rem.snoozedUntil;

      if (matchesTime || isSnoozeExpired) {
        if (isSnoozeExpired) {
          reminderStore.clearSnooze(currentUser.phone, rem.id);
        }
        triggerAlarm(rem, currentSlot);
      }
    });
  }, [currentTime, reminders, activeAlarm, currentUser.phone]);

  const triggerAlarm = (rem: MedicineReminder, timeSlot: string) => {
    setActiveAlarm({ reminder: rem, timeSlot });

    if (typeof window !== 'undefined' && 'Notification' in window && Notification.permission === 'granted') {
      try {
        new Notification(`⏰ Medicine Alarm: ${rem.medicineName}`, {
          body: `Time to take ${rem.dosage} (${rem.foodInstruction || 'As scheduled'}).`,
          icon: '/icon.svg',
          tag: `med-alarm-${rem.id}-${timeSlot}`,
          requireInteraction: true
        });
      } catch (e) {
        console.warn('Notification error:', e);
      }
    }
  };

  // Check URL parameters on mount / reminders load for deep linking (?alarmId=... or ?autoRing=1 or ?test=1)
  useEffect(() => {
    if (typeof window === 'undefined') return;
    const params = new URLSearchParams(window.location.search);
    const alarmId = params.get('alarmId');
    const timeSlot = params.get('timeSlot') || '08:00';
    const autoRing = params.get('autoRing');
    const isTest = params.get('test');

    if (alarmId || autoRing || isTest) {
      const fallbackRem: MedicineReminder = {
        id: alarmId || 'test-dolo-650',
        userPhone: 'demo',
        medicineName: 'Dolo 650',
        medicineType: 'tablet',
        dosage: '1 tablet (650mg)',
        times: [timeSlot],
        foodInstruction: 'After Food',
        frequency: 'Daily',
        startDate: new Date().toISOString().split('T')[0],
        active: true,
        notes: 'Take with plenty of water.',
        createdAt: Date.now()
      };
      const target = (alarmId && reminders.find(r => r.id === alarmId)) || reminders[0] || fallbackRem;
      triggerAlarm(target, timeSlot);
      window.history.replaceState({}, document.title, window.location.pathname);
    }
  }, [reminders]);

  // Sound, voice loop and title flashing while activeAlarm is ringing
  useEffect(() => {
    if (!activeAlarm) {
      AlarmChimeEngine.stop();
      VoiceAssistant.stop();
      if (typeof document !== 'undefined') {
        document.title = 'MediFinder - Health & Care Companion';
      }
      return;
    }

    // 1. Immediately start continuous loud alarm clock sound & screen wake lock
    BackgroundAudioKeepAlive.acquireScreenWakeLock();
    AlarmChimeEngine.start();

    // 2. Announce with voice assistant
    VoiceAssistant.speakDoseReminder(
      activeAlarm.reminder.medicineName,
      activeAlarm.reminder.dosage,
      activeAlarm.reminder.foodInstruction,
      currentUser.name
    );

    // 3. Flash browser tab title every 800ms to grab attention even if minimized
    let titleToggle = false;
    const titleTimer = setInterval(() => {
      titleToggle = !titleToggle;
      if (typeof document !== 'undefined') {
        document.title = titleToggle
          ? `🚨⏰ ALARM: ${activeAlarm.reminder.medicineName} ⏰🚨`
          : `💊 TIME TO TAKE YOUR DOSE! (${activeAlarm.timeSlot}) 💊`;
      }
    }, 800);

    // 4. Re-announce dose instructions every 12 seconds while alarm is ringing
    const voiceRepeatTimer = setInterval(() => {
      VoiceAssistant.speakDoseReminder(
        activeAlarm.reminder.medicineName,
        activeAlarm.reminder.dosage,
        activeAlarm.reminder.foodInstruction,
        currentUser.name
      );
    }, 12000);

    return () => {
      clearInterval(titleTimer);
      clearInterval(voiceRepeatTimer);
      BackgroundAudioKeepAlive.releaseScreenWakeLock();
      AlarmChimeEngine.stop();
      VoiceAssistant.stop();
      if (typeof document !== 'undefined') {
        document.title = 'MediFinder - Health & Care Companion';
      }
    };
  }, [activeAlarm, currentUser.name]);

  const requestNotificationPermission = async () => {
    if (typeof window !== 'undefined' && 'Notification' in window) {
      const res = await Notification.requestPermission();
      setNotificationPermission(res);
    }
  };

  const handleSaveReminder = (e: React.FormEvent) => {
    e.preventDefault();
    if (!medicineName.trim()) return;

    if (editingReminder) {
      reminderStore.updateReminder(currentUser.phone, {
        ...editingReminder,
        medicineName: medicineName.trim(),
        medicineType,
        dosage,
        times,
        foodInstruction,
        frequency,
        notes
      });
    } else {
      reminderStore.addReminder(currentUser.phone, {
        medicineName: medicineName.trim(),
        medicineType,
        dosage,
        times,
        foodInstruction,
        frequency,
        startDate: new Date().toISOString().split('T')[0],
        active: true,
        notes
      });
    }

    // Reset form
    setEditingReminder(null);
    setMedicineName('');
    setTimes(['08:00']);
    setNotes('');
    setSubTab('schedule');
  };

  const handleEditClick = (rem: MedicineReminder) => {
    setEditingReminder(rem);
    setMedicineName(rem.medicineName);
    setMedicineType(rem.medicineType);
    setDosage(rem.dosage);
    setTimes(rem.times);
    setFoodInstruction(rem.foodInstruction);
    setFrequency(rem.frequency);
    setNotes(rem.notes || '');
    setSubTab('add');
  };

  const handleMarkTaken = (rem: MedicineReminder, timeSlot: string) => {
    AlarmChimeEngine.stop();
    VoiceAssistant.stop();
    reminderStore.recordDoseAction(currentUser.phone, rem.id, timeSlot, 'taken_on_time');
    setActiveAlarm(null);
  };

  const handleDirectSkip = (rem: MedicineReminder, timeSlot: string) => {
    AlarmChimeEngine.stop();
    VoiceAssistant.stop();
    reminderStore.recordDoseAction(currentUser.phone, rem.id, timeSlot, 'skipped');
    setActiveAlarm(null);
  };

  const handleSnooze = (rem: MedicineReminder, minutes: number) => {
    AlarmChimeEngine.stop();
    VoiceAssistant.stop();
    reminderStore.snoozeReminder(currentUser.phone, rem.id, minutes);
    setActiveAlarm(null);
  };

  const handleAddTimeSlot = () => {
    setTimes([...times, '12:00']);
  };

  const handleRemoveTimeSlot = (idx: number) => {
    if (times.length <= 1) return;
    setTimes(times.filter((_, i) => i !== idx));
  };

  const handleUpdateTimeSlot = (idx: number, val: string) => {
    const updated = [...times];
    updated[idx] = val;
    setTimes(updated);
  };

  const todayStr = new Date().toISOString().split('T')[0];
  const todayLogs = logs.filter(l => l.date === todayStr);

  return (
    <div className="space-y-6 pb-20 md:pb-8 animate-fade-in max-w-5xl mx-auto">
      
      {/* BACKGROUND PUSH REMINDERS BANNER (WORKS EVEN WHEN APP IS CLOSED) */}
      <div className={`border rounded-3xl p-4 sm:p-5 shadow-xs transition-all ${
        isPushEnabled 
          ? 'bg-gradient-to-r from-emerald-500/10 via-teal-500/10 to-emerald-500/10 border-emerald-500/30' 
          : 'bg-gradient-to-r from-teal-500/10 via-blue-500/10 to-teal-500/10 border-[#0bbbb6]/30'
      }`}>
        <div className="flex flex-col sm:flex-row items-center justify-between gap-4">
          <div className="flex items-center gap-3.5">
            <div className={`w-11 h-11 rounded-2xl flex items-center justify-center shrink-0 shadow-xs ${
              isPushEnabled ? 'bg-emerald-500 text-white' : 'bg-[#0bbbb6] text-white'
            }`}>
              <Bell className={`w-5 h-5 ${isPushEnabled ? '' : 'animate-bounce'}`} />
            </div>
            <div>
              <div className="flex flex-wrap items-center gap-2">
                <h4 className="text-xs sm:text-sm font-black text-slate-900 dark:text-white">
                  Background Reminders & Alarms
                </h4>
                <span className={`px-2 py-0.5 rounded-full text-[10px] font-extrabold border ${
                  isPushEnabled
                    ? 'bg-emerald-100 dark:bg-emerald-950/80 text-emerald-700 dark:text-emerald-300 border-emerald-300 dark:border-emerald-800'
                    : 'bg-amber-100 dark:bg-amber-950/80 text-amber-700 dark:text-amber-300 border-amber-300 dark:border-amber-800'
                }`}>
                  {isPushEnabled ? '🟢 Active & Scheduled' : '⚪ Not Activated'}
                </span>
                <span className={`px-2 py-0.5 rounded-full text-[10px] font-extrabold border flex items-center gap-1 ${
                  cloudSyncState === 'synced'
                    ? 'bg-blue-100 dark:bg-blue-950/80 text-blue-700 dark:text-blue-300 border-blue-300 dark:border-blue-800'
                    : cloudSyncState === 'syncing' || cloudSyncState === 'connecting'
                    ? 'bg-indigo-100 dark:bg-indigo-950/80 text-indigo-700 dark:text-indigo-300 border-indigo-300 dark:border-indigo-800 animate-pulse'
                    : 'bg-slate-100 dark:bg-slate-800 text-slate-600 dark:text-slate-400 border-slate-300 dark:border-slate-700'
                }`}>
                  <span>
                    {cloudSyncState === 'synced'
                      ? '☁️ Cloud Synced'
                      : cloudSyncState === 'syncing'
                      ? '🔄 Syncing Cloud...'
                      : cloudSyncState === 'connecting'
                      ? '⚡ Connecting Cloud...'
                      : '💾 Local Cache'}
                  </span>
                </span>
                <span className={`px-2 py-0.5 rounded-full text-[10px] font-extrabold border flex items-center gap-1 ${
                  isBackgroundGuardActive
                    ? 'bg-teal-100 dark:bg-teal-950/80 text-teal-800 dark:text-teal-200 border-teal-300 dark:border-teal-800'
                    : 'bg-slate-100 dark:bg-slate-800 text-slate-600 dark:text-slate-400 border-slate-300 dark:border-slate-700'
                }`}>
                  <Radio className={`w-3 h-3 ${isBackgroundGuardActive ? 'text-teal-600 dark:text-teal-300 animate-pulse' : ''}`} />
                  <span>{isBackgroundGuardActive ? '🔊 Audio Guard ON' : '🔈 Guard Off'}</span>
                </span>
                {isNativeApp && (
                  <span className="px-2 py-0.5 rounded-full text-[10px] font-extrabold border bg-purple-100 dark:bg-purple-950/80 text-purple-700 dark:text-purple-300 border-purple-300 dark:border-purple-800 flex items-center gap-1">
                    <Smartphone className="w-3 h-3 text-purple-600" />
                    <span>📱 Native AlarmManager</span>
                  </span>
                )}
              </div>
              <p className="text-[11px] text-slate-500 dark:text-slate-400 font-medium mt-0.5">
                {isPushEnabled
                  ? 'Your scheduled medicine doses trigger loud digital alarms and voice announcements on Windows/Android even if this tab is closed.'
                  : 'Enable Closed-Tab alerts to wake your device and sound alarms on time, even when MediFinder is closed.'}
              </p>
              {pushStatusMessage && (
                <p className="text-[11px] font-bold text-[#0bbbb6] dark:text-teal-300 mt-1 animate-fade-in">
                  {pushStatusMessage}
                </p>
              )}
              {isPushEnabled && (
                <div className="mt-2 text-[10px] text-slate-600 dark:text-slate-300 bg-white/70 dark:bg-slate-900/60 p-2 rounded-xl border border-emerald-500/20 flex items-start gap-1.5">
                  <span className="text-amber-500 shrink-0">💡</span>
                  <span>
                    <strong>How Closed-Tab Alarms Work:</strong> Closed tabs sound system notification chimes with intense vibration. <strong>Tap the notification</strong> to instantly launch continuous ringing. For uninterrupted 24/7 background audio without clicking, keep <strong>Audio Guard ON</strong> in a minimized tab.
                  </span>
                </div>
              )}
            </div>
          </div>

          <div className="flex flex-wrap items-center gap-2 shrink-0 self-stretch sm:self-auto justify-end">
            <button
              onClick={handleToggleBackgroundGuard}
              className={`px-3 py-2 rounded-2xl text-xs font-bold transition cursor-pointer flex items-center gap-1.5 active:scale-95 border ${
                isBackgroundGuardActive
                  ? 'bg-teal-600 text-white border-teal-500 shadow-xs'
                  : 'bg-white dark:bg-slate-800 hover:bg-slate-50 dark:hover:bg-slate-700 text-slate-700 dark:text-slate-300 border-slate-300 dark:border-slate-700'
              }`}
              title="Keeps mobile and browser audio active in the background"
            >
              <Radio className="w-3.5 h-3.5" />
              <span>{isBackgroundGuardActive ? 'Guard: Active' : 'Enable Audio Guard'}</span>
            </button>

            {deferredInstallPrompt && (
              <button
                onClick={handleInstallApp}
                className="px-3 py-2 bg-gradient-to-r from-purple-600 to-indigo-600 hover:from-purple-700 hover:to-indigo-700 text-white rounded-2xl text-xs font-black shadow-xs transition cursor-pointer flex items-center gap-1.5 active:scale-95"
                title="Install MediFinder as a standalone app"
              >
                <Download className="w-3.5 h-3.5" />
                <span>Install App</span>
              </button>
            )}

            <button
              onClick={() => setShowDiagnosticModal(true)}
              className="p-2 rounded-2xl bg-white/80 dark:bg-slate-800/80 hover:bg-white dark:hover:bg-slate-700 text-slate-600 dark:text-slate-300 border border-slate-200 dark:border-slate-700 transition cursor-pointer"
              title="Alarm Reliability Guide & Help"
            >
              <HelpCircle className="w-4 h-4" />
            </button>

            {!isPushEnabled ? (
              <button
                onClick={handleEnablePushReminders}
                disabled={isSubscribingPush}
                className="px-4 py-2.5 bg-[#0bbbb6] hover:bg-[#0aa6a1] text-white rounded-2xl text-xs font-black shadow-xs transition cursor-pointer flex items-center gap-2 active:scale-95"
              >
                <Zap className="w-4 h-4" />
                <span>{isSubscribingPush ? 'Enabling...' : 'Enable Closed-Tab Alerts'}</span>
              </button>
            ) : (
              <button
                onClick={handleTriggerTestAlert}
                disabled={testCountdown !== null}
                className="px-4 py-2 bg-emerald-600 hover:bg-emerald-700 text-white rounded-2xl text-xs font-black shadow-xs transition cursor-pointer flex items-center gap-2 active:scale-95"
              >
                <Clock className="w-4 h-4" />
                <span>
                  {testCountdown !== null
                    ? `Close Tab Now! Alert in ${testCountdown}s...`
                    : 'Test Alert (Try Closing Tab!)'}
                </span>
              </button>
            )}
          </div>
        </div>
      </div>


      {/* ALARM RINGTONE & SOUND STYLE SELECTOR */}
      <div className="bg-white dark:bg-slate-900 border border-slate-200/80 dark:border-slate-800 rounded-3xl p-4 sm:p-5 flex flex-col sm:flex-row items-center justify-between gap-4 shadow-xs">
        <div className="flex items-center gap-3">
          <div className="w-10 h-10 rounded-2xl bg-amber-500/10 text-amber-600 dark:text-amber-400 flex items-center justify-center shrink-0 border border-amber-200 dark:border-amber-800">
            <Bell className="w-5 h-5 animate-bounce" />
          </div>
          <div>
            <div className="flex items-center gap-2">
              <h4 className="text-xs font-black text-slate-900 dark:text-white uppercase tracking-wider">
                Alarm Ringing Sound Style
              </h4>
              <span className="px-2 py-0.5 rounded-full text-[10px] font-bold bg-amber-100 dark:bg-amber-950/60 text-amber-700 dark:text-amber-300 border border-amber-300 dark:border-amber-800">
                {alarmTone === 'digital' ? '⏰ Digital Alarm (Loud)' : 
                 alarmTone === 'bell' ? '🔔 Twin Bell' : 
                 alarmTone === 'siren' ? '🚨 Siren' : '🎵 Melodic'}
              </span>
            </div>
            <p className="text-[11px] text-slate-500 dark:text-slate-400 font-medium mt-0.5">
              Select how your medicine alarm rings when doses are due
            </p>
          </div>
        </div>

        <div className="flex flex-wrap items-center gap-2 shrink-0 justify-end">
          <button
            onClick={() => handleSelectAlarmTone('digital')}
            className={`px-3 py-1.5 rounded-2xl text-xs font-bold transition flex items-center gap-1 cursor-pointer ${
              alarmTone === 'digital'
                ? 'bg-amber-600 text-white shadow-xs'
                : 'bg-slate-100 dark:bg-slate-800 text-slate-700 dark:text-slate-300 hover:bg-slate-200'
            }`}
          >
            <span>⏰ Digital Clock</span>
          </button>

          <button
            onClick={() => handleSelectAlarmTone('bell')}
            className={`px-3 py-1.5 rounded-2xl text-xs font-bold transition flex items-center gap-1 cursor-pointer ${
              alarmTone === 'bell'
                ? 'bg-amber-600 text-white shadow-xs'
                : 'bg-slate-100 dark:bg-slate-800 text-slate-700 dark:text-slate-300 hover:bg-slate-200'
            }`}
          >
            <span>🔔 Ringing Bell</span>
          </button>

          <button
            onClick={() => handleSelectAlarmTone('siren')}
            className={`px-3 py-1.5 rounded-2xl text-xs font-bold transition flex items-center gap-1 cursor-pointer ${
              alarmTone === 'siren'
                ? 'bg-amber-600 text-white shadow-xs'
                : 'bg-slate-100 dark:bg-slate-800 text-slate-700 dark:text-slate-300 hover:bg-slate-200'
            }`}
          >
            <span>🚨 Siren</span>
          </button>

          <button
            onClick={() => handleSelectAlarmTone('melody')}
            className={`px-3 py-1.5 rounded-2xl text-xs font-bold transition flex items-center gap-1 cursor-pointer ${
              alarmTone === 'melody'
                ? 'bg-amber-600 text-white shadow-xs'
                : 'bg-slate-100 dark:bg-slate-800 text-slate-700 dark:text-slate-300 hover:bg-slate-200'
            }`}
          >
            <span>🎵 Melodic</span>
          </button>

          <button
            onClick={() => handleSelectAlarmTone(alarmTone)}
            disabled={isPlayingPreview}
            className="px-3 py-1.5 bg-amber-50 hover:bg-amber-100 dark:bg-amber-950/40 text-amber-800 dark:text-amber-200 border border-amber-200 dark:border-amber-800 rounded-2xl text-xs font-extrabold transition cursor-pointer flex items-center gap-1"
          >
            <Volume2 className="w-3.5 h-3.5" />
            <span>{isPlayingPreview ? '🔊 Ringing...' : '🔊 Test Alarm Ring'}</span>
          </button>
        </div>
      </div>

      {/* SUB-TAB NAVIGATION SEGMENTED BAR */}
      <div className="flex bg-slate-200/80 dark:bg-slate-800 p-1.5 rounded-3xl shadow-inner max-w-xl mx-auto">
        <button
          onClick={() => setSubTab('schedule')}
          className={`flex-1 py-2 rounded-2xl text-xs font-bold transition flex items-center justify-center gap-1.5 cursor-pointer ${
            subTab === 'schedule'
              ? 'bg-white dark:bg-slate-900 text-slate-900 dark:text-white shadow-xs'
              : 'text-slate-600 dark:text-slate-400 hover:text-slate-900'
          }`}
        >
          <Clock className="w-3.5 h-3.5 text-[#0bbbb6]" />
          <span>Today Schedule</span>
        </button>

        <button
          onClick={() => setSubTab('reminders')}
          className={`flex-1 py-2 rounded-2xl text-xs font-bold transition flex items-center justify-center gap-1.5 cursor-pointer ${
            subTab === 'reminders'
              ? 'bg-white dark:bg-slate-900 text-slate-900 dark:text-white shadow-xs'
              : 'text-slate-600 dark:text-slate-400 hover:text-slate-900'
          }`}
        >
          <Pill className="w-3.5 h-3.5 text-indigo-500" />
          <span>All Medicines ({reminders.length})</span>
        </button>

        <button
          onClick={() => {
            setEditingReminder(null);
            setMedicineName('');
            setSubTab('add');
          }}
          className={`flex-1 py-2 rounded-2xl text-xs font-bold transition flex items-center justify-center gap-1.5 cursor-pointer ${
            subTab === 'add'
              ? 'bg-white dark:bg-slate-900 text-slate-900 dark:text-white shadow-xs'
              : 'text-slate-600 dark:text-slate-400 hover:text-slate-900'
          }`}
        >
          <Plus className="w-3.5 h-3.5 text-emerald-500" />
          <span>{editingReminder ? 'Edit Medicine' : 'Add Medicine'}</span>
        </button>

        <button
          onClick={() => setSubTab('history')}
          className={`flex-1 py-2 rounded-2xl text-xs font-bold transition flex items-center justify-center gap-1.5 cursor-pointer ${
            subTab === 'history'
              ? 'bg-white dark:bg-slate-900 text-slate-900 dark:text-white shadow-xs'
              : 'text-slate-600 dark:text-slate-400 hover:text-slate-900'
          }`}
        >
          <Calendar className="w-3.5 h-3.5 text-purple-500" />
          <span>Dose History</span>
        </button>
      </div>

      {/* SUB-TAB 1: TODAY SCHEDULE */}
      {subTab === 'schedule' && (
        <div className="space-y-4">
          <div className="flex items-center justify-between px-1">
            <h3 className="text-xs font-black uppercase tracking-wider text-slate-400">
              Today's Prescribed Doses
            </h3>
            <span className="text-xs font-bold text-slate-500">
              Current Time: {currentTime.toLocaleTimeString([], { hour: '2-digit', minute: '2-digit', second: '2-digit' })}
            </span>
          </div>

          {reminders.length === 0 ? (
            <div className="bg-white dark:bg-slate-900 border border-slate-200/80 dark:border-slate-800 rounded-3xl p-10 text-center space-y-3">
              <Pill className="w-10 h-10 text-slate-300 dark:text-slate-600 mx-auto" />
              <p className="text-sm font-bold text-slate-600 dark:text-slate-400">
                No active medicine schedule set up yet.
              </p>
              <button
                onClick={() => setSubTab('add')}
                className="px-4 py-2 bg-[#0bbbb6] text-white rounded-2xl text-xs font-bold shadow-xs cursor-pointer"
              >
                + Add Your First Medicine
              </button>
            </div>
          ) : (
            <div className="space-y-3">
              {reminders.map((rem) => (
                <div
                  key={rem.id}
                  className="bg-white dark:bg-slate-900 border border-slate-200/80 dark:border-slate-800 rounded-3xl p-5 shadow-xs space-y-3"
                >
                  <div className="flex items-start justify-between gap-3">
                    <div className="flex items-start gap-3">
                      <div className="w-11 h-11 rounded-2xl bg-[#0bbbb6]/10 text-[#0bbbb6] flex items-center justify-center shrink-0">
                        <Pill className="w-5.5 h-5.5" />
                      </div>
                      <div>
                        <h4 className="text-base font-extrabold text-slate-900 dark:text-white">
                          {rem.medicineName}
                        </h4>
                        <p className="text-xs text-slate-500 font-medium">
                          {rem.dosage} • {rem.foodInstruction} • {rem.frequency}
                        </p>
                      </div>
                    </div>

                    <button
                      onClick={() => triggerAlarm(rem, rem.times[0] || '08:00')}
                      className="px-3 py-1.5 bg-amber-50 dark:bg-amber-950/40 border border-amber-200 dark:border-amber-800 text-amber-700 dark:text-amber-300 rounded-2xl text-xs font-bold flex items-center gap-1.5 transition cursor-pointer"
                      title="Test alarm sound & voice alert immediately"
                    >
                      <Volume2 className="w-3.5 h-3.5" />
                      <span>Ring Alarm Now</span>
                    </button>
                  </div>

                  <div className="flex flex-wrap items-center gap-2 pt-1 border-t border-slate-100 dark:border-slate-800">
                    <span className="text-xs font-bold text-slate-400 mr-1">Time Slots:</span>
                    {rem.times.map((t) => {
                      const log = todayLogs.find(l => l.reminderId === rem.id && l.scheduledTimeSlot === t);
                      const isTaken = log && (log.status === 'taken_on_time' || log.status === 'taken_late');

                      return (
                        <div
                          key={t}
                          className={`px-3 py-1 rounded-2xl text-xs font-bold flex items-center gap-2 ${
                            isTaken
                              ? 'bg-emerald-50 text-emerald-700 border border-emerald-200 dark:bg-emerald-950/50 dark:text-emerald-300 dark:border-emerald-800'
                              : 'bg-slate-50 text-slate-700 border border-slate-200 dark:bg-slate-800 dark:text-slate-200 dark:border-slate-700'
                          }`}
                        >
                          <span>{t}</span>
                          {!isTaken && (
                            <button
                              onClick={() => handleMarkTaken(rem, t)}
                              className="text-[10px] bg-[#0bbbb6] text-white px-2 py-0.5 rounded-full hover:bg-[#0aa6a1] transition cursor-pointer"
                            >
                              Take
                            </button>
                          )}
                          {isTaken && <Check className="w-3.5 h-3.5 text-emerald-600" />}
                        </div>
                      );
                    })}
                  </div>
                </div>
              ))}
            </div>
          )}
        </div>
      )}

      {/* SUB-TAB 2: ALL MEDICINES LIST */}
      {subTab === 'reminders' && (
        <div className="space-y-4">
          <div className="flex items-center justify-between px-1">
            <h3 className="text-xs font-black uppercase tracking-wider text-slate-400">
              Saved Medicine Reminders ({reminders.length})
            </h3>
            <button
              onClick={() => {
                setEditingReminder(null);
                setMedicineName('');
                setSubTab('add');
              }}
              className="px-3 py-1.5 bg-[#0bbbb6] text-white rounded-2xl text-xs font-bold flex items-center gap-1 cursor-pointer"
            >
              <Plus className="w-3.5 h-3.5" />
              <span>Add Medicine</span>
            </button>
          </div>

          <div className="space-y-3">
            {reminders.map((rem) => (
              <div
                key={rem.id}
                className="bg-white dark:bg-slate-900 border border-slate-200/80 dark:border-slate-800 rounded-3xl p-5 shadow-xs flex flex-col sm:flex-row sm:items-center justify-between gap-4"
              >
                <div className="space-y-1">
                  <div className="flex items-center gap-2">
                    <h4 className="text-base font-extrabold text-slate-900 dark:text-white">
                      {rem.medicineName}
                    </h4>
                    <span className="px-2 py-0.5 bg-slate-100 dark:bg-slate-800 text-slate-600 dark:text-slate-300 text-[10px] font-bold rounded-full">
                      {rem.medicineType}
                    </span>
                  </div>
                  <p className="text-xs text-slate-500 font-medium">
                    Dosage: {rem.dosage} • {rem.foodInstruction} • {rem.frequency}
                  </p>
                  <p className="text-[11px] text-slate-400 font-semibold">
                    Times: {rem.times.join(', ')}
                  </p>
                </div>

                <div className="flex items-center gap-2 shrink-0">
                  <button
                    onClick={() => reminderStore.toggleActive(currentUser.phone, rem.id)}
                    className={`px-3 py-1.5 rounded-2xl text-xs font-bold transition flex items-center gap-1 cursor-pointer ${
                      rem.active
                        ? 'bg-emerald-50 text-emerald-700 border border-emerald-200 dark:bg-emerald-950/40 dark:text-emerald-300'
                        : 'bg-slate-100 text-slate-400'
                    }`}
                  >
                    <Power className="w-3.5 h-3.5" />
                    <span>{rem.active ? 'Active' : 'Paused'}</span>
                  </button>

                  <button
                    onClick={() => handleEditClick(rem)}
                    className="p-2 bg-slate-100 hover:bg-slate-200 dark:bg-slate-800 text-slate-700 dark:text-slate-200 rounded-xl transition cursor-pointer"
                  >
                    <Edit className="w-4 h-4" />
                  </button>

                  <button
                    onClick={() => reminderStore.deleteReminder(currentUser.phone, rem.id)}
                    className="p-2 bg-rose-50 hover:bg-rose-100 text-rose-600 rounded-xl transition cursor-pointer"
                  >
                    <Trash2 className="w-4 h-4" />
                  </button>
                </div>
              </div>
            ))}
          </div>
        </div>
      )}

      {/* SUB-TAB 3: ADD/EDIT FORM */}
      {subTab === 'add' && (
        <div className="bg-white dark:bg-slate-900 border border-slate-200/80 dark:border-slate-800 rounded-3xl p-6 sm:p-8 space-y-6 shadow-xs max-w-2xl mx-auto">
          <div className="flex items-center gap-3">
            <div className="w-12 h-12 rounded-2xl bg-teal-500/10 text-[#0bbbb6] flex items-center justify-center font-bold">
              <Pill className="w-6 h-6" />
            </div>
            <div>
              <h3 className="text-xl font-extrabold text-slate-900 dark:text-white">
                {editingReminder ? 'Edit Medicine Reminder' : 'Add New Medicine Reminder'}
              </h3>
              <p className="text-xs text-slate-500 dark:text-slate-400 font-medium">
                Configure background alarm times, dosage & voice alerts
              </p>
            </div>
          </div>

          <form onSubmit={handleSaveReminder} className="space-y-4">
            <div>
              <label className="block text-xs font-bold text-slate-700 dark:text-slate-300 mb-1">
                Medicine Name *
              </label>
              <input
                type="text"
                required
                value={medicineName}
                onChange={e => setMedicineName(e.target.value)}
                placeholder="e.g. Paracetamol, Amoxicillin, Metformin"
                className="w-full px-4 py-2.5 bg-slate-50 dark:bg-slate-800 border border-slate-200 dark:border-slate-700 rounded-2xl text-xs sm:text-sm focus:outline-none focus:ring-2 focus:ring-[#0bbbb6] dark:text-white font-medium"
              />
            </div>

            <div className="grid grid-cols-2 gap-3">
              <div>
                <label className="block text-xs font-bold text-slate-700 dark:text-slate-300 mb-1">
                  Medicine Form
                </label>
                <select
                  value={medicineType}
                  onChange={e => setMedicineType(e.target.value)}
                  className="w-full px-4 py-2.5 bg-slate-50 dark:bg-slate-800 border border-slate-200 dark:border-slate-700 rounded-2xl text-xs sm:text-sm focus:outline-none focus:ring-2 focus:ring-[#0bbbb6] dark:text-white font-medium"
                >
                  <option value="Tablet">Tablet</option>
                  <option value="Capsule">Capsule</option>
                  <option value="Syrup">Syrup</option>
                  <option value="Injection">Injection</option>
                  <option value="Drops">Drops</option>
                  <option value="Ointment">Ointment</option>
                </select>
              </div>

              <div>
                <label className="block text-xs font-bold text-slate-700 dark:text-slate-300 mb-1">
                  Dosage per dose
                </label>
                <input
                  type="text"
                  value={dosage}
                  onChange={e => setDosage(e.target.value)}
                  placeholder="e.g. 1 tablet, 5ml, 500mg"
                  className="w-full px-4 py-2.5 bg-slate-50 dark:bg-slate-800 border border-slate-200 dark:border-slate-700 rounded-2xl text-xs sm:text-sm focus:outline-none focus:ring-2 focus:ring-[#0bbbb6] dark:text-white font-medium"
                />
              </div>
            </div>

            <div className="grid grid-cols-2 gap-3">
              <div>
                <label className="block text-xs font-bold text-slate-700 dark:text-slate-300 mb-1">
                  Food Instruction
                </label>
                <select
                  value={foodInstruction}
                  onChange={e => setFoodInstruction(e.target.value)}
                  className="w-full px-4 py-2.5 bg-slate-50 dark:bg-slate-800 border border-slate-200 dark:border-slate-700 rounded-2xl text-xs sm:text-sm focus:outline-none focus:ring-2 focus:ring-[#0bbbb6] dark:text-white font-medium"
                >
                  <option value="After Food">After Food</option>
                  <option value="Before Food">Before Food</option>
                  <option value="With Food">With Food</option>
                  <option value="Empty Stomach">Empty Stomach</option>
                </select>
              </div>

              <div>
                <label className="block text-xs font-bold text-slate-700 dark:text-slate-300 mb-1">
                  Frequency
                </label>
                <select
                  value={frequency}
                  onChange={e => setFrequency(e.target.value)}
                  className="w-full px-4 py-2.5 bg-slate-50 dark:bg-slate-800 border border-slate-200 dark:border-slate-700 rounded-2xl text-xs sm:text-sm focus:outline-none focus:ring-2 focus:ring-[#0bbbb6] dark:text-white font-medium"
                >
                  <option value="Daily">Daily</option>
                  <option value="Twice Daily">Twice Daily</option>
                  <option value="Thrice Daily">Thrice Daily</option>
                  <option value="Weekly">Weekly</option>
                  <option value="As Needed">As Needed</option>
                </select>
              </div>
            </div>

            {/* TIME SLOTS SELECTION */}
            <div className="space-y-2">
              <div className="flex items-center justify-between">
                <label className="block text-xs font-bold text-slate-700 dark:text-slate-300">
                  Alarm Scheduled Time Slots *
                </label>
                <button
                  type="button"
                  onClick={handleAddTimeSlot}
                  className="text-xs font-bold text-[#0bbbb6] hover:text-[#0aa6a1] flex items-center gap-1 cursor-pointer"
                >
                  + Add Time Slot
                </button>
              </div>

              <div className="space-y-2">
                {times.map((t, idx) => (
                  <div key={idx} className="flex items-center gap-2">
                    <input
                      type="time"
                      required
                      value={t}
                      onChange={e => handleUpdateTimeSlot(idx, e.target.value)}
                      className="flex-grow px-4 py-2 bg-slate-50 dark:bg-slate-800 border border-slate-200 dark:border-slate-700 rounded-2xl text-xs sm:text-sm focus:outline-none focus:ring-2 focus:ring-[#0bbbb6] dark:text-white font-bold"
                    />
                    {times.length > 1 && (
                      <button
                        type="button"
                        onClick={() => handleRemoveTimeSlot(idx)}
                        className="p-2 text-rose-500 hover:bg-rose-50 rounded-xl transition"
                      >
                        <X className="w-4 h-4" />
                      </button>
                    )}
                  </div>
                ))}
              </div>
            </div>

            <div>
              <label className="block text-xs font-bold text-slate-700 dark:text-slate-300 mb-1">
                Doctor Notes & Special Instructions
              </label>
              <textarea
                value={notes}
                onChange={e => setNotes(e.target.value)}
                placeholder="e.g. Take with a full glass of water. Avoid dairy products."
                rows={2}
                className="w-full px-4 py-2.5 bg-slate-50 dark:bg-slate-800 border border-slate-200 dark:border-slate-700 rounded-2xl text-xs sm:text-sm focus:outline-none focus:ring-2 focus:ring-[#0bbbb6] dark:text-white font-medium"
              />
            </div>

            <div className="flex items-center gap-3 pt-2">
              <button
                type="submit"
                className="flex-1 py-3 bg-[#0bbbb6] hover:bg-[#0aa6a1] text-white font-bold rounded-2xl text-xs sm:text-sm shadow-md transition cursor-pointer flex items-center justify-center gap-2"
              >
                <Check className="w-4 h-4" />
                <span>Save Medicine Reminder</span>
              </button>
            </div>
          </form>
        </div>
      )}

      {/* SUB-TAB 4: DOSE HISTORY */}
      {subTab === 'history' && (
        <div className="space-y-4">
          <h3 className="text-xs font-black uppercase tracking-wider text-slate-400 px-1">
            Recorded Doses Log History
          </h3>

          {logs.length === 0 ? (
            <div className="bg-white dark:bg-slate-900 border border-slate-200/80 dark:border-slate-800 rounded-3xl p-10 text-center space-y-2">
              <Calendar className="w-10 h-10 text-slate-300 dark:text-slate-600 mx-auto" />
              <p className="text-sm font-bold text-slate-600 dark:text-slate-400">
                No doses recorded in history yet.
              </p>
            </div>
          ) : (
            <div className="space-y-2.5">
              {logs.map((log) => (
                <div
                  key={log.id}
                  className="bg-white dark:bg-slate-900 border border-slate-200/80 dark:border-slate-800 rounded-2xl p-4 shadow-xs flex items-center justify-between gap-3"
                >
                  <div className="space-y-0.5">
                    <div className="text-sm font-bold text-slate-900 dark:text-white">
                      {log.medicineName}
                    </div>
                    <div className="text-xs text-slate-500 font-medium">
                      Scheduled: {log.scheduledTimeSlot} • Recorded: {new Date(log.takenAt).toLocaleTimeString([], { hour: '2-digit', minute: '2-digit' })} ({log.date})
                    </div>
                  </div>

                  <span className={`px-3 py-1 rounded-full text-xs font-bold ${
                    log.status === 'taken_on_time' || log.status === 'taken_late'
                      ? 'bg-emerald-100 dark:bg-emerald-950/60 text-emerald-700 dark:text-emerald-300'
                      : 'bg-amber-100 dark:bg-amber-950/60 text-amber-700 dark:text-amber-300'
                  }`}>
                    {log.status === 'taken_on_time' ? 'Taken On Time' : log.status === 'taken_late' ? 'Taken Late' : 'Skipped'}
                  </span>
                </div>
              ))}
            </div>
          )}
        </div>
      )}

      {/* ALARM RELIABILITY & DIAGNOSTIC MODAL */}
      {showDiagnosticModal && (
        <div className="fixed inset-0 z-50 bg-slate-950/80 backdrop-blur-md flex items-center justify-center p-4 animate-fade-in">
          <div className="bg-white dark:bg-slate-900 border border-slate-200 dark:border-slate-800 rounded-3xl max-w-lg w-full p-6 sm:p-7 space-y-5 shadow-2xl relative">
            <div className="flex items-center justify-between">
              <div className="flex items-center gap-3">
                <div className="w-10 h-10 rounded-2xl bg-teal-500/10 text-[#0bbbb6] flex items-center justify-center font-bold text-xl">
                  ⏰
                </div>
                <div>
                  <h3 className="text-base font-black text-slate-900 dark:text-white">
                    Alarm Reliability & Audio Guide
                  </h3>
                  <p className="text-xs text-slate-500 dark:text-slate-400">
                    Understanding how background alarms work across devices
                  </p>
                </div>
              </div>
              <button
                onClick={() => setShowDiagnosticModal(false)}
                className="w-8 h-8 rounded-full bg-slate-100 dark:bg-slate-800 hover:bg-slate-200 text-slate-600 dark:text-slate-300 flex items-center justify-center transition cursor-pointer"
              >
                <X className="w-4 h-4" />
              </button>
            </div>

            <div className="space-y-3.5 text-xs text-slate-600 dark:text-slate-300 max-h-[60vh] overflow-y-auto pr-1">
              
              {/* 1. Closed Tab System Alerts */}
              <div className="p-3.5 rounded-2xl bg-slate-50 dark:bg-slate-800/60 border border-slate-200/80 dark:border-slate-700/80 space-y-1.5">
                <div className="flex items-center gap-2 font-bold text-slate-900 dark:text-white">
                  <Bell className="w-4 h-4 text-emerald-500" />
                  <span>1. When Tab or Browser Is Completely Closed</span>
                </div>
                <p className="text-[11px] leading-relaxed">
                  Web sandboxes prevent websites from silently turning on speakers while closed. Instead, your operating system (Windows/Android) displays a persistent heads-up notification with sound and vibration. <strong>Tap the notification banner</strong> to instantly launch the loud continuous digital alarm and voice assistant.
                </p>
              </div>

              {/* 2. Audio Guard (Continuous Background Ringing) */}
              <div className="p-3.5 rounded-2xl bg-teal-500/10 border border-teal-500/20 space-y-1.5">
                <div className="flex items-center gap-2 font-bold text-[#0bbbb6] dark:text-teal-300">
                  <Radio className="w-4 h-4" />
                  <span>2. Audio Guard (Continuous Background Ringing)</span>
                </div>
                <p className="text-[11px] leading-relaxed">
                  Turn on <strong>Audio Guard</strong> to keep MediFinder's audio pipeline active via HTML5 MediaSession. This allows alarms to ring continuously at full volume without needing to click the notification, even if your phone screen dims or you switch tabs.
                </p>
              </div>

              {/* 3. Native Android App (AlarmManager) */}
              <div className="p-3.5 rounded-2xl bg-purple-500/10 border border-purple-500/20 space-y-1.5">
                <div className="flex items-center gap-2 font-bold text-purple-700 dark:text-purple-300">
                  <Smartphone className="w-4 h-4" />
                  <span>3. Native Android App (Capacitor AlarmManager)</span>
                </div>
                <p className="text-[11px] leading-relaxed">
                  For 100% native hardware alarm clock behavior (waking up a locked screen and ringing even when killed), MediFinder includes Capacitor native support. Run <code className="px-1 py-0.5 rounded bg-purple-100 dark:bg-purple-950 font-mono text-[10px]">npm run cap:android</code> to compile a native Android APK using Android <code className="font-mono text-[10px]">setExactAndAllowWhileIdle</code>.
                </p>
              </div>

              {/* 4. Battery Optimization Tips */}
              <div className="p-3.5 rounded-2xl bg-amber-500/10 border border-amber-500/20 space-y-1.5">
                <div className="flex items-center gap-2 font-bold text-amber-800 dark:text-amber-300">
                  <ShieldAlert className="w-4 h-4" />
                  <span>4. Prevent Battery Saving from Delaying Alarms</span>
                </div>
                <ul className="text-[11px] list-disc list-inside space-y-1 text-slate-600 dark:text-slate-300">
                  <li><strong>Android:</strong> Settings → Apps → Chrome/MediFinder → Battery → Select <strong>"Unrestricted"</strong>.</li>
                  <li><strong>Windows:</strong> Settings → System → Focus Assist → Turn off or set to <strong>Priority Only</strong>.</li>
                </ul>
              </div>

            </div>

            <button
              onClick={() => setShowDiagnosticModal(false)}
              className="w-full py-3 bg-[#0bbbb6] hover:bg-[#0aa6a1] text-white font-bold rounded-2xl text-xs shadow-md transition cursor-pointer"
            >
              Got It, Thanks!
            </button>
          </div>
        </div>
      )}

      {/* FULL-SCREEN RINGING ALARM OVERLAY */}
      {activeAlarm && (
        <div className="fixed inset-0 z-50 bg-slate-950/95 backdrop-blur-xl flex items-center justify-center p-4 animate-fade-in">
          {/* Pulsing ambient alarm glow */}
          <div className="absolute inset-0 flex items-center justify-center pointer-events-none overflow-hidden">
            <div className="w-[500px] h-[500px] rounded-full bg-rose-500/20 blur-3xl animate-ping opacity-60"></div>
            <div className="w-[350px] h-[350px] rounded-full bg-teal-500/20 blur-2xl animate-pulse opacity-80"></div>
          </div>

          <div className="bg-white dark:bg-slate-900 border-2 border-rose-500/80 rounded-3xl max-w-md w-full p-6 sm:p-8 text-center space-y-6 shadow-2xl relative overflow-hidden z-10">
            
            {/* Urgent ringing alarm banner */}
            <div className="inline-flex items-center gap-2 px-4 py-1.5 rounded-full bg-rose-100 dark:bg-rose-950/80 text-rose-700 dark:text-rose-300 text-xs font-black tracking-widest uppercase border border-rose-300 dark:border-rose-800 animate-pulse">
              <span className="w-2.5 h-2.5 rounded-full bg-rose-600 animate-ping"></span>
              <span>🚨 MEDICINE ALARM RINGING 🚨</span>
            </div>

            {/* Pulsing Ringing Bell with sound waves */}
            <div className="relative w-28 h-28 mx-auto flex items-center justify-center">
              <div className="absolute inset-0 rounded-full bg-rose-500/20 animate-ping"></div>
              <div className="w-24 h-24 rounded-full bg-gradient-to-tr from-rose-500 to-amber-500 text-white shadow-xl flex items-center justify-center relative z-10 animate-bounce">
                <Bell className="w-12 h-12 animate-pulse text-white" />
              </div>
            </div>

            {/* Sound indicator */}
            <div className="flex items-center justify-center gap-1.5 text-xs font-extrabold text-slate-500 dark:text-slate-400">
              <Volume2 className="w-4 h-4 text-rose-500 animate-bounce" />
              <span>
                Playing {alarmTone === 'digital' ? 'Classic Digital Alarm' : alarmTone === 'bell' ? 'Twin Bell Alarm' : alarmTone === 'siren' ? 'Urgent Siren' : 'Melodic Chime'}
              </span>
            </div>

            <div className="space-y-1.5">
              <div className="inline-flex items-center gap-1.5 px-3 py-1 rounded-full bg-slate-100 dark:bg-slate-800 text-slate-700 dark:text-slate-300 text-xs font-bold">
                <Clock className="w-3.5 h-3.5 text-[#0bbbb6]" />
                <span>Scheduled Time: {activeAlarm.timeSlot}</span>
              </div>

              <h2 className="text-2xl sm:text-3xl font-black text-slate-900 dark:text-white pt-1">
                {activeAlarm.reminder.medicineName}
              </h2>

              <p className="text-sm text-slate-600 dark:text-slate-300 font-semibold">
                Dosage: {activeAlarm.reminder.dosage} • {activeAlarm.reminder.foodInstruction}
              </p>
            </div>

            {/* ACTION BUTTONS */}
            <div className="space-y-3 pt-1">
              <button
                onClick={() => handleMarkTaken(activeAlarm.reminder, activeAlarm.timeSlot)}
                className="w-full py-4 bg-emerald-600 hover:bg-emerald-700 text-white font-black rounded-2xl text-sm shadow-xl transition active:scale-95 cursor-pointer flex items-center justify-center gap-2 border border-emerald-400"
              >
                <CheckCircle2 className="w-5 h-5" />
                <span>STOP ALARM & TAKE MEDICINE NOW</span>
              </button>

              <div className="grid grid-cols-3 gap-2">
                <button
                  onClick={() => handleSnooze(activeAlarm.reminder, 5)}
                  className="py-2.5 bg-amber-50 hover:bg-amber-100 text-amber-800 dark:bg-amber-950/40 dark:text-amber-200 rounded-2xl text-xs font-extrabold transition cursor-pointer"
                >
                  Snooze 5m
                </button>
                <button
                  onClick={() => handleSnooze(activeAlarm.reminder, 10)}
                  className="py-2.5 bg-amber-50 hover:bg-amber-100 text-amber-800 dark:bg-amber-950/40 dark:text-amber-200 rounded-2xl text-xs font-extrabold transition cursor-pointer"
                >
                  Snooze 10m
                </button>
                <button
                  onClick={() => handleSnooze(activeAlarm.reminder, 15)}
                  className="py-2.5 bg-amber-50 hover:bg-amber-100 text-amber-800 dark:bg-amber-950/40 dark:text-amber-200 rounded-2xl text-xs font-extrabold transition cursor-pointer"
                >
                  Snooze 15m
                </button>
              </div>

              <button
                onClick={() => handleDirectSkip(activeAlarm.reminder, activeAlarm.timeSlot)}
                className="w-full py-2.5 bg-slate-100 hover:bg-slate-200 dark:bg-slate-800 text-slate-700 dark:text-slate-300 font-bold rounded-2xl text-xs transition cursor-pointer"
              >
                Dismiss / Skip This Dose
              </button>
            </div>

          </div>
        </div>
      )}

    </div>
  );
}
