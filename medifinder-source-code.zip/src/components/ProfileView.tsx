import React, { useState, useEffect } from 'react';
import { 
  Phone, 
  ShieldCheck, 
  Sun, 
  Moon, 
  Tv, 
  ShieldAlert, 
  LogOut, 
  ChevronRight,
  HeartPulse,
  Mail
} from 'lucide-react';
import { reminderStore } from '../services/reminderStore';
import { UserProfile } from '../types';

interface ProfileViewProps {
  currentUser: UserProfile;
  darkMode: boolean;
  setDarkMode: (val: boolean) => void;
  onShowVideoTour: () => void;
  onShowAdminPrompt: () => void;
  onLogout: () => void;
}

export default function ProfileView({
  currentUser,
  darkMode,
  setDarkMode,
  onShowVideoTour,
  onShowAdminPrompt,
  onLogout
}: ProfileViewProps) {
  const [remindersCount, setRemindersCount] = useState(0);
  const [logsCount, setLogsCount] = useState(0);

  useEffect(() => {
    const updateStats = () => {
      const rems = reminderStore.getReminders(currentUser.phone);
      const lgs = reminderStore.getLogs(currentUser.phone);
      setRemindersCount(rems.length);
      setLogsCount(lgs.length);
    };

    updateStats();
    const unsubscribe = reminderStore.subscribe(updateStats);
    return unsubscribe;
  }, [currentUser.phone]);

  return (
    <div className="space-y-6 pb-20 md:pb-8 animate-fade-in max-w-2xl mx-auto">
      
      {/* PROFILE HEADER CARD */}
      <div className="bg-white dark:bg-slate-900 border border-slate-200/80 dark:border-slate-800 rounded-3xl p-6 sm:p-8 text-center space-y-4 shadow-xs">
        <div className="relative inline-block">
          {currentUser.avatar ? (
            <img
              src={currentUser.avatar}
              alt={currentUser.name}
              className="w-20 h-20 rounded-full object-cover border-2 border-[#0bbbb6]/30 mx-auto shadow-sm"
            />
          ) : (
            <div className="w-20 h-20 rounded-full bg-[#e6f8f7] dark:bg-teal-950/50 text-[#0bbbb6] dark:text-teal-400 border-2 border-[#0bbbb6]/30 flex items-center justify-center font-black text-2xl mx-auto shadow-sm">
              {currentUser.name.charAt(0).toUpperCase()}
            </div>
          )}
          <div className="absolute bottom-0 right-0 p-1.5 bg-emerald-500 text-white rounded-full border-2 border-white dark:border-slate-900 shadow-xs">
            <ShieldCheck className="w-4 h-4" />
          </div>
        </div>

        <div className="space-y-1">
          <h2 className="text-xl font-extrabold text-slate-900 dark:text-white">
            {currentUser.name}
          </h2>
          {currentUser.email && (
            <p className="text-xs font-semibold text-slate-600 dark:text-slate-300 flex items-center justify-center gap-1.5">
              <Mail className="w-3.5 h-3.5 text-blue-500" />
              <span>{currentUser.email}</span>
            </p>
          )}
          <p className="text-xs font-semibold text-slate-500 dark:text-slate-400 flex items-center justify-center gap-1.5">
            <Phone className="w-3.5 h-3.5 text-[#0bbbb6]" />
            <span>{currentUser.phone}</span>
          </p>
        </div>

        <div className="flex flex-wrap items-center justify-center gap-2 pt-1">
          {currentUser.authProvider === 'google' ? (
            <div className="inline-flex items-center gap-1.5 px-3 py-1 bg-blue-50 dark:bg-blue-950/40 border border-blue-200 dark:border-blue-800 text-blue-600 dark:text-blue-400 rounded-full text-xs font-bold">
              <svg className="w-3.5 h-3.5" viewBox="0 0 24 24">
                <path fill="#4285F4" d="M22.56 12.25c0-.78-.07-1.53-.2-2.25H12v4.26h5.92c-.26 1.37-1.04 2.53-2.21 3.31v2.77h3.57c2.08-1.92 3.28-4.74 3.28-8.09z" />
                <path fill="#34A853" d="M12 23c2.97 0 5.46-.98 7.28-2.66l-3.57-2.77c-.98.66-2.23 1.06-3.71 1.06-2.86 0-5.29-1.93-6.16-4.53H2.18v2.84C3.99 20.53 7.7 23 12 23z" />
                <path fill="#FBBC05" d="M5.84 14.09c-.22-.66-.35-1.36-.35-2.09s.13-1.43.35-2.09V7.06H2.18C1.43 8.55 1 10.22 1 12s.43 3.45 1.18 4.94l2.85-2.22.81-.63z" />
                <path fill="#EA4335" d="M12 5.38c1.62 0 3.06.56 4.21 1.64l3.15-3.15C17.45 2.09 14.97 1 12 1 7.7 1 3.99 3.47 2.18 7.06l3.66 2.84c.87-2.6 3.3-4.52 6.16-4.52z" />
              </svg>
              <span>Google Authenticated</span>
            </div>
          ) : (
            <div className="inline-flex items-center gap-1.5 px-3 py-1 bg-teal-50 dark:bg-teal-950/40 border border-[#0bbbb6]/20 text-[#0bbbb6] rounded-full text-xs font-bold">
              <HeartPulse className="w-3.5 h-3.5" />
              <span>Verified Patient Account</span>
            </div>
          )}
        </div>
      </div>

      {/* QUICK STATS ROW */}
      <div className="grid grid-cols-2 gap-3.5">
        <div className="bg-white dark:bg-slate-900 border border-slate-200/80 dark:border-slate-800 rounded-3xl p-5 text-center space-y-1 shadow-xs">
          <div className="text-2xl font-black text-[#0bbbb6]">
            {remindersCount}
          </div>
          <div className="text-xs font-bold text-slate-600 dark:text-slate-400">
            Medicine Reminders
          </div>
        </div>

        <div className="bg-white dark:bg-slate-900 border border-slate-200/80 dark:border-slate-800 rounded-3xl p-5 text-center space-y-1 shadow-xs">
          <div className="text-2xl font-black text-emerald-500">
            {logsCount}
          </div>
          <div className="text-xs font-bold text-slate-600 dark:text-slate-400">
            Doses Recorded
          </div>
        </div>
      </div>

      {/* SETTINGS & OPTIONS LIST */}
      <div className="bg-white dark:bg-slate-900 border border-slate-200/80 dark:border-slate-800 rounded-3xl p-4 sm:p-6 space-y-4 shadow-xs">
        <h3 className="text-xs font-black uppercase tracking-wider text-slate-400 dark:text-slate-400 px-1">
          Application Preferences
        </h3>

        {/* Theme Segmented Switcher */}
        <div className="flex items-center justify-between p-3.5 bg-slate-50 dark:bg-slate-950 rounded-2xl border border-slate-200/60 dark:border-slate-800">
          <div className="flex items-center gap-3">
            <div className="p-2 bg-amber-500/10 text-amber-500 rounded-xl">
              {darkMode ? <Moon className="w-5 h-5 text-indigo-400" /> : <Sun className="w-5 h-5 text-amber-500" />}
            </div>
            <div>
              <div className="text-xs font-bold text-slate-900 dark:text-white">Appearance Theme</div>
              <div className="text-[11px] font-medium text-slate-500 dark:text-slate-400">
                {darkMode ? 'Dark Theme Active' : 'Light Theme Active'}
              </div>
            </div>
          </div>

          <div className="flex bg-slate-200/80 dark:bg-slate-800 p-1 rounded-full">
            <button
              onClick={() => setDarkMode(false)}
              className={`px-3 py-1 rounded-full text-xs font-bold transition ${
                !darkMode ? 'bg-white text-slate-900 shadow-xs' : 'text-slate-500 hover:text-slate-900 dark:text-slate-400'
              }`}
            >
              Light
            </button>
            <button
              onClick={() => setDarkMode(true)}
              className={`px-3 py-1 rounded-full text-xs font-bold transition ${
                darkMode ? 'bg-slate-950 text-white shadow-xs' : 'text-slate-500 hover:text-slate-900 dark:text-slate-400'
              }`}
            >
              Dark
            </button>
          </div>
        </div>

        {/* AI Video Presentation Tour */}
        <button
          onClick={onShowVideoTour}
          className="w-full flex items-center justify-between p-3.5 bg-gradient-to-r from-teal-500/10 via-emerald-500/10 to-teal-500/10 hover:from-teal-500/20 hover:to-emerald-500/20 border border-teal-500/20 rounded-2xl transition group text-left cursor-pointer"
        >
          <div className="flex items-center gap-3">
            <div className="p-2 bg-[#0bbbb6] text-white rounded-xl shadow-xs">
              <Tv className="w-5 h-5" />
            </div>
            <div>
              <div className="text-xs font-bold text-slate-900 dark:text-white group-hover:text-[#0bbbb6] transition">
                AI Video Presentation Tour
              </div>
              <div className="text-[11px] font-medium text-slate-500 dark:text-slate-400">
                Watch voice walkthrough & features demo
              </div>
            </div>
          </div>
          <ChevronRight className="w-4 h-4 text-slate-400 group-hover:text-[#0bbbb6] transition" />
        </button>

        {/* Clinical Admin Access */}
        <button
          onClick={onShowAdminPrompt}
          className="w-full flex items-center justify-between p-3.5 bg-slate-50 dark:bg-slate-950 hover:bg-slate-100 dark:hover:bg-slate-800 border border-slate-200/60 dark:border-slate-800 rounded-2xl transition group text-left cursor-pointer"
        >
          <div className="flex items-center gap-3">
            <div className="p-2 bg-slate-200 dark:bg-slate-800 text-slate-700 dark:text-slate-300 rounded-xl">
              <ShieldAlert className="w-5 h-5 text-slate-500" />
            </div>
            <div>
              <div className="text-xs font-bold text-slate-900 dark:text-white">
                Clinical Admin Access
              </div>
              <div className="text-[11px] font-medium text-slate-500 dark:text-slate-400">
                View patient logs & system database
              </div>
            </div>
          </div>
          <ChevronRight className="w-4 h-4 text-slate-400 transition" />
        </button>

        {/* Sign Out Button */}
        <div className="pt-2">
          <button
            onClick={onLogout}
            className="w-full py-3 bg-rose-50 hover:bg-rose-100 dark:bg-rose-950/30 dark:hover:bg-rose-950/50 text-rose-600 dark:text-rose-400 border border-rose-200/60 dark:border-rose-900/40 rounded-2xl text-xs font-bold flex items-center justify-center gap-2 transition cursor-pointer shadow-2xs"
          >
            <LogOut className="w-4 h-4" />
            <span>Sign Out of MediFinder</span>
          </button>
        </div>

      </div>

    </div>
  );
}
