import React, { useState, useEffect } from 'react';
import { 
  Plus, 
  Bell, 
  Sparkles, 
  MapPin, 
  Pill, 
  Clock, 
  CheckCircle2, 
  ChevronRight, 
  ArrowRight,
  Check, 
  LocateFixed, 
  Phone, 
  Navigation, 
  Store, 
  Compass, 
  Search,
  AlertTriangle,
  Zap
} from 'lucide-react';
import Hero3DMedicineScene from './Hero3DMedicineScene';
import { reminderStore } from '../services/reminderStore';
import { MedicineReminder, DoseLog, Pharmacy, UserProfile } from '../types';
import { 
  calculateDistanceKm, 
  calculateTravelTime, 
  reverseGeocode, 
  getLiveNearbyPharmacies,
  getLastKnownUserLocation,
  saveLastKnownUserLocation
} from '../services/locationService';

interface HomeScreenProps {
  currentUser: UserProfile;
  onNavigate: (
    tab: 'home' | 'search' | 'ai' | 'connect' | 'reminders' | 'profile',
    options?: { 
      reminderSubTab?: 'schedule' | 'reminders' | 'add' | 'history';
      searchQuery?: string;
      aiPrompt?: string;
    }
  ) => void;
  onSelectPharmacyForNav?: (ph: Pharmacy) => void;
  darkMode?: boolean;
}

const POPULAR_SEARCH_CHIPS = [
  'Dolo 650',
  'Paracetamol',
  'Amoxicillin',
  'Azithral 500',
  'Metformin',
  'Cetirizine',
  'Pantoprazole'
];

const AI_QUICK_QUESTIONS = [
  {
    icon: '💊',
    badge: 'Safe Dosage',
    title: 'Uses & side effects of Dolo 650',
    desc: 'Daily safe limits, interval timing & fever relief',
    prompt: 'Uses & side effects of Dolo 650'
  },
  {
    icon: '🍽️',
    badge: 'Meal Rules',
    title: 'Can I take Azithral after food?',
    desc: 'Preventing stomach upset & full course instructions',
    prompt: 'Can I take Azithral after food?'
  },
  {
    icon: '⚠️',
    badge: 'Safety Caution',
    title: 'What should I avoid with Metformin?',
    desc: 'Alcohol warnings, timing rules & food precautions',
    prompt: 'What should I avoid while taking Metformin?'
  },
  {
    icon: '⏰',
    badge: 'Missed Dose',
    title: 'What if I miss a medicine dose?',
    desc: 'Safe buffer rules and why you should never double dose',
    prompt: 'What should I do if I miss a dose of my medicine?'
  }
];

function getGreeting(): string {
  const hour = new Date().getHours();
  if (hour < 12) return 'Good morning';
  if (hour < 17) return 'Good afternoon';
  return 'Good evening';
}

export default function HomeScreen({ currentUser, onNavigate, onSelectPharmacyForNav }: HomeScreenProps) {
  const [reminders, setReminders] = useState<MedicineReminder[]>([]);
  const [logs, setLogs] = useState<DoseLog[]>([]);
  const [pharmacies, setPharmacies] = useState<Pharmacy[]>([]);
  const [homeSearchQuery, setHomeSearchQuery] = useState('');

  // Geolocation state (restores cached location immediately if available)
  const [userCoords, setUserCoords] = useState<{ lat: number; lng: number }>(() => {
    const cached = getLastKnownUserLocation();
    return cached?.coords || { lat: 18.2969, lng: 83.8967 }; // Default Srikakulam
  });
  const [isDetectingGps, setIsDetectingGps] = useState(false);
  const [gpsLocationLabel, setGpsLocationLabel] = useState<string>(() => {
    const cached = getLastKnownUserLocation();
    return cached?.address || 'Detecting location...';
  });

  useEffect(() => {
    // Initial fetch
    setReminders(reminderStore.getReminders(currentUser.phone));
    setLogs(reminderStore.getLogs(currentUser.phone));

    // Load initial pharmacies using current or cached coordinates
    getLiveNearbyPharmacies(userCoords.lat, userCoords.lng).then(stores => {
      setPharmacies(stores);
    });

    // Auto detect GPS on mount
    handleDetectGPS();

    // Reactive store subscription
    const unsubscribe = reminderStore.subscribe(() => {
      setReminders(reminderStore.getReminders(currentUser.phone));
      setLogs(reminderStore.getLogs(currentUser.phone));
    });

    return unsubscribe;
  }, [currentUser.phone]);

  const activeReminders = reminders.filter(r => r.active);
  const todayStr = new Date().toISOString().split('T')[0];
  const todayLogs = logs.filter(l => l.date === todayStr);

  // Compute daily dose adherence metrics
  const allScheduledSlots: { reminder: MedicineReminder; time: string; isDone: boolean }[] = [];
  activeReminders.forEach(r => {
    r.times.forEach(t => {
      const isDone = todayLogs.some(
        l => l.reminderId === r.id && l.scheduledTimeSlot === t && (l.status === 'taken_on_time' || l.status === 'taken_late')
      );
      allScheduledSlots.push({ reminder: r, time: t, isDone });
    });
  });

  const totalScheduledDoses = allScheduledSlots.length;
  const completedDoses = allScheduledSlots.filter(s => s.isDone).length;
  const adherencePct = totalScheduledDoses > 0 ? Math.round((completedDoses / totalScheduledDoses) * 100) : 100;
  const nextDueSlot = allScheduledSlots.find(s => !s.isDone);

  const handleMarkDoseTaken = (reminder: MedicineReminder, timeSlot: string) => {
    reminderStore.recordDoseAction(currentUser.phone, reminder.id, timeSlot, 'taken_on_time');
  };

  const handleDetectGPS = () => {
    if (typeof navigator === 'undefined' || !('geolocation' in navigator)) {
      setGpsLocationLabel('Location GPS unavailable');
      return;
    }
    setIsDetectingGps(true);

    navigator.geolocation.getCurrentPosition(
      async (pos) => {
        const { latitude, longitude } = pos.coords;
        setUserCoords({ lat: latitude, lng: longitude });
        setIsDetectingGps(false);
        const addrRes = await reverseGeocode(latitude, longitude);
        setGpsLocationLabel(addrRes.address);
        saveLastKnownUserLocation({ lat: latitude, lng: longitude }, addrRes.address, addrRes.city || 'Local');

        // Fetch and anchor real local pharmacies around the user's detected GPS coordinates!
        const localStores = await getLiveNearbyPharmacies(latitude, longitude, addrRes.city || 'Local');
        setPharmacies(localStores);
      },
      async (_err) => {
        setIsDetectingGps(false);
        const cached = getLastKnownUserLocation();
        setGpsLocationLabel(cached?.address || 'Current Position (GPS)');
        const fallbackStores = await getLiveNearbyPharmacies(userCoords.lat, userCoords.lng, cached?.city || 'Local');
        setPharmacies(fallbackStores);
      },
      { timeout: 10000, enableHighAccuracy: true }
    );
  };

  const handleSearchSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    if (homeSearchQuery.trim()) {
      onNavigate('search', { searchQuery: homeSearchQuery.trim() });
    } else {
      onNavigate('search');
    }
  };

  // Sort pharmacies by distance to userCoords
  const nearestPharmacies = [...pharmacies]
    .map(ph => {
      const computedDistance = calculateDistanceKm(userCoords.lat, userCoords.lng, ph.lat, ph.lng);
      const travelTime = calculateTravelTime(computedDistance);
      return {
        ...ph,
        computedDistance: computedDistance || ph.distanceKm,
        travelTime
      };
    })
    .sort((a, b) => a.computedDistance - b.computedDistance)
    .slice(0, 3);

  // Identify emergency 24/7 pharmacy
  const emergencyPharmacy = pharmacies.find(ph => ph.openHours?.toLowerCase().includes('24')) || nearestPharmacies[0];

  return (
    <div className="space-y-6 pb-20 md:pb-8 animate-fade-in max-w-5xl mx-auto">
      
      {/* 1. HERO BANNER WITH EMBEDDED INSTANT MEDICINE SEARCH & 3D INTERACTIVE MEDICINE SCENE */}
      <div className="relative overflow-hidden rounded-3xl bg-gradient-to-br from-[#e6f8f7] via-teal-50/40 to-slate-50 dark:from-slate-900 dark:via-teal-950/20 dark:to-slate-900 border border-[#0bbbb6]/20 dark:border-teal-800/30 p-6 sm:p-8 shadow-xs">
        {/* Soft Background Accent Glows */}
        <div className="absolute -top-16 -right-16 w-80 h-80 bg-[#0bbbb6]/15 dark:bg-[#0bbbb6]/15 rounded-full blur-3xl pointer-events-none" />
        <div className="absolute -bottom-16 -left-16 w-64 h-64 bg-emerald-500/10 dark:bg-emerald-500/10 rounded-full blur-3xl pointer-events-none" />

        <div className="relative z-10 flex flex-col lg:flex-row lg:items-center justify-between gap-6">
          {/* Left Column: Greeting & Instant Search */}
          <div className="flex-1 max-w-2xl space-y-4">
            <div>
              <div className="inline-flex items-center gap-1.5 px-3 py-1 rounded-full bg-[#0bbbb6]/15 text-[#078e8a] dark:text-teal-300 text-[11px] font-black uppercase tracking-wider mb-2 border border-[#0bbbb6]/30 shadow-2xs">
                <Sparkles className="w-3.5 h-3.5 text-[#0bbbb6]" />
                <span>Real-Time Healthcare Companion</span>
              </div>
              <h1 className="text-2xl sm:text-3xl font-black text-slate-900 dark:text-white tracking-tight">
                {getGreeting()}, {currentUser.name.split(' ')[0]} 👋
              </h1>
              <p className="text-xs sm:text-sm text-slate-600 dark:text-slate-300 font-medium mt-1">
                Find available medicines in stock nearby, manage your doses, or consult the AI assistant.
              </p>
            </div>

            {/* Embedded Instant Medicine Search Bar */}
            <div className="bg-white dark:bg-slate-900/95 p-2 sm:p-2.5 rounded-2xl sm:rounded-3xl border border-slate-200/90 dark:border-slate-700/90 shadow-sm">
              <form onSubmit={handleSearchSubmit} className="flex items-center gap-2">
                <div className="relative flex-grow">
                  <Search className="absolute left-3.5 top-1/2 -translate-y-1/2 w-4 h-4 text-slate-400" />
                  <input
                    type="text"
                    value={homeSearchQuery}
                    onChange={(e) => setHomeSearchQuery(e.target.value)}
                    placeholder="Search medicines, generics, symptoms (e.g. Paracetamol, Dolo 650)..."
                    className="w-full pl-10 pr-3 py-2.5 sm:py-3 bg-transparent text-xs sm:text-sm font-medium text-slate-900 dark:text-white placeholder-slate-400 focus:outline-none"
                  />
                </div>
                <button
                  type="submit"
                  className="px-5 sm:px-6 py-2.5 sm:py-3 bg-[#0bbbb6] hover:bg-[#0aa6a1] text-white rounded-xl sm:rounded-2xl text-xs sm:text-sm font-extrabold transition shadow-xs hover:shadow-md cursor-pointer shrink-0 flex items-center gap-1.5"
                >
                  <span>Search</span>
                  <ArrowRight className="w-3.5 h-3.5" />
                </button>
              </form>

              {/* Trending Search Chips */}
              <div className="pt-2 mt-2 border-t border-slate-100 dark:border-slate-800/80 flex items-center gap-1.5 overflow-x-auto no-scrollbar px-1">
                <span className="text-[10px] font-bold text-slate-400 uppercase tracking-wider shrink-0 mr-1 flex items-center gap-1">
                  <Zap className="w-3 h-3 text-amber-500" />
                  Trending:
                </span>
                {POPULAR_SEARCH_CHIPS.map((med) => (
                  <button
                    key={med}
                    type="button"
                    onClick={() => onNavigate('search', { searchQuery: med })}
                    className="px-2.5 py-0.8 bg-slate-100/80 hover:bg-[#e6f8f7] dark:bg-slate-800/80 dark:hover:bg-teal-950/40 text-slate-600 dark:text-slate-300 hover:text-[#0bbbb6] dark:hover:text-teal-300 rounded-full text-[11px] font-semibold transition whitespace-nowrap shrink-0 cursor-pointer"
                  >
                    {med}
                  </button>
                ))}
              </div>
            </div>
          </div>

          {/* Right Column: 3D Interactive Medicine Capsule Scene */}
          <div className="hidden lg:flex items-center justify-center w-72 h-[260px] shrink-0">
            <Hero3DMedicineScene />
          </div>
        </div>
      </div>

      {/* 2. TODAY'S MEDICATION GLANCE (Shown when user has active reminders) */}
      {activeReminders.length > 0 && (
        <div className="bg-white dark:bg-slate-900 border border-slate-200/80 dark:border-slate-800 rounded-3xl p-4 sm:p-5 shadow-xs flex flex-col md:flex-row md:items-center justify-between gap-4">
          {/* Left: Next Due Dose */}
          <div className="flex items-center gap-3.5 flex-1 min-w-0">
            <div className="w-11 h-11 rounded-2xl bg-teal-500/10 text-[#0bbbb6] dark:bg-teal-500/20 dark:text-teal-300 flex items-center justify-center shrink-0">
              <Pill className="w-5.5 h-5.5" />
            </div>
            <div className="min-w-0">
              <div className="text-[11px] font-bold uppercase tracking-wider text-slate-400 flex items-center gap-1.5">
                <span>Next Dose</span>
                {nextDueSlot && (
                  <span className="px-2 py-0.2 bg-teal-50 dark:bg-teal-950/60 text-[#0bbbb6] dark:text-teal-300 rounded-full text-[10px] font-extrabold">
                    Due at {nextDueSlot.time}
                  </span>
                )}
              </div>
              {nextDueSlot ? (
                <div className="flex items-center gap-2 mt-0.5">
                  <span className="text-sm font-extrabold text-slate-900 dark:text-white truncate">
                    {nextDueSlot.reminder.medicineName}
                  </span>
                  <span className="text-xs text-slate-500 dark:text-slate-400 font-medium">
                    ({nextDueSlot.reminder.dosage} • {nextDueSlot.reminder.foodInstruction})
                  </span>
                </div>
              ) : (
                <div className="text-sm font-bold text-emerald-600 dark:text-emerald-400 flex items-center gap-1.5 mt-0.5">
                  <Check className="w-4 h-4" />
                  <span>All scheduled doses completed for today!</span>
                </div>
              )}
            </div>
          </div>

          {/* Right: Adherence Progress & Actions */}
          <div className="flex items-center gap-3 border-t md:border-t-0 pt-3 md:pt-0 border-slate-100 dark:border-slate-800 shrink-0">
            <div className="text-right hidden sm:block">
              <div className="text-xs font-bold text-slate-700 dark:text-slate-300">
                {completedDoses} of {totalScheduledDoses} taken ({adherencePct}%)
              </div>
              <div className="w-28 bg-slate-100 dark:bg-slate-800 h-2 rounded-full overflow-hidden mt-1.5 ml-auto">
                <div 
                  className="bg-[#0bbbb6] h-full rounded-full transition-all duration-500"
                  style={{ width: `${adherencePct}%` }}
                />
              </div>
            </div>

            {nextDueSlot && (
              <button
                onClick={() => handleMarkDoseTaken(nextDueSlot.reminder, nextDueSlot.time)}
                className="px-4 py-2 bg-[#0bbbb6] hover:bg-[#0aa6a1] text-white rounded-xl text-xs font-bold transition shadow-xs flex items-center gap-1.5 cursor-pointer"
              >
                <CheckCircle2 className="w-3.5 h-3.5" />
                <span>Mark Taken</span>
              </button>
            )}

            <button
              onClick={() => onNavigate('reminders', { reminderSubTab: 'schedule' })}
              className="px-3 py-2 bg-slate-100 hover:bg-slate-200 dark:bg-slate-800 dark:hover:bg-slate-700 text-slate-700 dark:text-slate-200 text-xs font-bold rounded-xl transition flex items-center gap-1 cursor-pointer"
            >
              <span>Schedule</span>
              <ChevronRight className="w-3.5 h-3.5" />
            </button>
          </div>
        </div>
      )}

      {/* 3. QUICK ACCESS PORTALS */}
      <div className="space-y-3">
        <h2 className="text-xs font-black uppercase tracking-wider text-slate-400 dark:text-slate-400 px-1">
          Quick Portals
        </h2>

        <div className="grid grid-cols-2 lg:grid-cols-4 gap-3.5">
          {/* Action 1: Search Medicines & Nearby Stores */}
          <button
            onClick={() => onNavigate('search')}
            className="group p-4 sm:p-5 bg-white dark:bg-slate-900 border border-slate-200/80 dark:border-slate-800 hover:border-[#0bbbb6]/40 dark:hover:border-teal-500/40 rounded-3xl shadow-xs hover:shadow-md transition-all text-left cursor-pointer"
          >
            <div className="flex items-center justify-between w-full mb-3">
              <div className="w-10 h-10 rounded-2xl bg-teal-500/10 text-[#0bbbb6] dark:bg-teal-500/20 dark:text-teal-300 flex items-center justify-center transition-transform group-hover:scale-110">
                <Store className="w-5 h-5" />
              </div>
              <ChevronRight className="w-4 h-4 text-slate-300 dark:text-slate-600 group-hover:text-[#0bbbb6] transition-colors" />
            </div>
            <div>
              <h3 className="text-sm font-bold text-slate-900 dark:text-white group-hover:text-[#0bbbb6] transition-colors">
                Find Medicines
              </h3>
              <p className="text-xs text-slate-500 dark:text-slate-400 font-medium mt-0.5">
                Check stock & stores
              </p>
            </div>
          </button>

          {/* Action 2: Medicine Reminders */}
          <button
            onClick={() => onNavigate('reminders')}
            className="group p-4 sm:p-5 bg-white dark:bg-slate-900 border border-slate-200/80 dark:border-slate-800 hover:border-indigo-500/40 dark:hover:border-indigo-400/40 rounded-3xl shadow-xs hover:shadow-md transition-all text-left cursor-pointer"
          >
            <div className="flex items-center justify-between w-full mb-3">
              <div className="w-10 h-10 rounded-2xl bg-indigo-500/10 text-indigo-600 dark:bg-indigo-500/20 dark:text-indigo-300 flex items-center justify-center transition-transform group-hover:scale-110">
                <Bell className="w-5 h-5" />
              </div>
              <ChevronRight className="w-4 h-4 text-slate-300 dark:text-slate-600 group-hover:text-indigo-500 transition-colors" />
            </div>
            <div>
              <h3 className="text-sm font-bold text-slate-900 dark:text-white group-hover:text-indigo-600 dark:group-hover:text-indigo-400 transition-colors">
                Dose Reminders
              </h3>
              <p className="text-xs text-slate-500 dark:text-slate-400 font-medium mt-0.5">
                {activeReminders.length > 0 ? `${activeReminders.length} active schedules` : 'Set daily alarms'}
              </p>
            </div>
          </button>

          {/* Action 3: AI Clinical Assistant */}
          <button
            onClick={() => onNavigate('ai')}
            className="group p-4 sm:p-5 bg-white dark:bg-slate-900 border border-slate-200/80 dark:border-slate-800 hover:border-purple-500/40 dark:hover:border-purple-400/40 rounded-3xl shadow-xs hover:shadow-md transition-all text-left cursor-pointer"
          >
            <div className="flex items-center justify-between w-full mb-3">
              <div className="w-10 h-10 rounded-2xl bg-purple-500/10 text-purple-600 dark:bg-purple-500/20 dark:text-purple-300 flex items-center justify-center transition-transform group-hover:scale-110">
                <Sparkles className="w-5 h-5" />
              </div>
              <ChevronRight className="w-4 h-4 text-slate-300 dark:text-slate-600 group-hover:text-purple-500 transition-colors" />
            </div>
            <div>
              <h3 className="text-sm font-bold text-slate-900 dark:text-white group-hover:text-purple-600 dark:group-hover:text-purple-400 transition-colors">
                AI Assistant
              </h3>
              <p className="text-xs text-slate-500 dark:text-slate-400 font-medium mt-0.5">
                Ask drug queries
              </p>
            </div>
          </button>

          {/* Action 4: 24/7 Emergency Pharmacies */}
          <button
            onClick={() => {
              if (emergencyPharmacy && onSelectPharmacyForNav) {
                onSelectPharmacyForNav(emergencyPharmacy);
              } else {
                onNavigate('search');
              }
            }}
            className="group p-4 sm:p-5 bg-white dark:bg-slate-900 border border-rose-200/80 dark:border-rose-900/40 hover:border-rose-500/50 rounded-3xl shadow-xs hover:shadow-md transition-all text-left cursor-pointer"
          >
            <div className="flex items-center justify-between w-full mb-3">
              <div className="w-10 h-10 rounded-2xl bg-rose-500/10 text-rose-600 dark:bg-rose-500/20 dark:text-rose-400 flex items-center justify-center transition-transform group-hover:scale-110">
                <AlertTriangle className="w-5 h-5" />
              </div>
              <span className="w-2 h-2 rounded-full bg-rose-500 animate-ping mr-1" />
            </div>
            <div>
              <h3 className="text-sm font-bold text-slate-900 dark:text-white group-hover:text-rose-600 dark:group-hover:text-rose-400 transition-colors">
                24/7 Emergency
              </h3>
              <p className="text-xs text-slate-500 dark:text-slate-400 font-medium mt-0.5">
                {emergencyPharmacy ? `${emergencyPharmacy.name.split(' ')[0]} open nearby` : 'Locate open stores'}
              </p>
            </div>
          </button>
        </div>
      </div>

      {/* 4. AI ASSISTANT CLINICAL PROMPT CHIPS */}
      <div className="bg-gradient-to-br from-white via-teal-50/20 to-white dark:from-slate-900 dark:via-teal-950/20 dark:to-slate-900 border-2 border-teal-500/20 dark:border-teal-500/20 rounded-3xl p-5 shadow-xs space-y-3.5">
        <div className="flex items-center justify-between">
          <div className="flex items-center gap-2.5">
            <div className="w-9 h-9 rounded-2xl bg-gradient-to-tr from-[#0bbbb6] to-teal-600 text-white flex items-center justify-center font-bold shadow-2xs">
              <Sparkles className="w-5 h-5" />
            </div>
            <div>
              <div className="flex items-center gap-2">
                <h2 className="text-xs font-black uppercase tracking-wider text-teal-600 dark:text-teal-400">Quick Clinical AI</h2>
                <span className="inline-flex items-center gap-1 px-2 py-0.5 rounded-full text-[10px] font-black bg-amber-500/15 text-amber-700 dark:text-amber-300 border border-amber-500/30">
                  <Zap className="w-2.5 h-2.5 fill-amber-500 text-amber-500" />
                  Instant Answers
                </span>
              </div>
              <span className="text-sm font-extrabold text-slate-900 dark:text-white">Ask MediFinder AI Assistant</span>
            </div>
          </div>
          <button
            onClick={() => onNavigate('ai')}
            className="text-xs font-bold text-[#0bbbb6] hover:text-[#0aa6a1] flex items-center gap-1 cursor-pointer group bg-teal-50 dark:bg-teal-950/60 px-3 py-1.5 rounded-xl border border-teal-200 dark:border-teal-800 transition"
          >
            <span>Open Chat</span>
            <ChevronRight className="w-3.5 h-3.5 group-hover:translate-x-0.5 transition-transform" />
          </button>
        </div>

        <div className="grid grid-cols-1 sm:grid-cols-2 gap-3">
          {AI_QUICK_QUESTIONS.map((item) => (
            <button
              key={item.title}
              onClick={() => onNavigate('ai', { aiPrompt: item.prompt })}
              className="p-3.5 bg-white dark:bg-slate-800/90 hover:bg-teal-50/60 dark:hover:bg-teal-950/40 border-2 border-slate-200/80 dark:border-slate-700/80 hover:border-[#0bbbb6] dark:hover:border-[#0bbbb6] rounded-2xl text-left transition-all duration-200 shadow-2xs hover:shadow-sm cursor-pointer flex flex-col justify-between group"
            >
              <div className="space-y-1.5">
                <div className="flex items-center justify-between">
                  <span className="w-7 h-7 rounded-xl bg-teal-50 dark:bg-teal-950/80 border border-teal-200/60 dark:border-teal-800 flex items-center justify-center text-sm shadow-2xs">
                    {item.icon}
                  </span>
                  <span className="text-[10px] font-extrabold uppercase tracking-wider px-2 py-0.5 rounded-md bg-slate-100 dark:bg-slate-700 text-slate-600 dark:text-slate-300 group-hover:bg-[#0bbbb6]/15 group-hover:text-[#0bbbb6] dark:group-hover:text-teal-300 transition">
                    {item.badge}
                  </span>
                </div>
                <h3 className="text-xs sm:text-sm font-black text-slate-900 dark:text-white group-hover:text-[#0bbbb6] transition leading-snug">
                  {item.title}
                </h3>
                <p className="text-[11px] text-slate-500 dark:text-slate-400 font-medium leading-relaxed">
                  {item.desc}
                </p>
              </div>

              <div className="mt-2.5 pt-2 border-t border-slate-100 dark:border-slate-700/50 flex items-center justify-between text-[11px] font-extrabold text-[#0bbbb6]">
                <span>Ask AI now</span>
                <ArrowRight className="w-3.5 h-3.5 group-hover:translate-x-1 transition-transform" />
              </div>
            </button>
          ))}
        </div>
      </div>

      {/* 5. NEAREST PHARMACIES NEAR USER LOCATION */}
      <div className="space-y-3 pt-2">
        <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-2 px-1">
          <div>
            <h2 className="text-xs font-black uppercase tracking-wider text-slate-400 dark:text-slate-400 flex items-center gap-1.5">
              <MapPin className="w-3.5 h-3.5 text-[#0bbbb6]" />
              <span>Nearest Pharmacies to Your Location</span>
            </h2>
            <p className="text-[11px] text-slate-500 dark:text-slate-400 font-medium">
              Sorted by real-time GPS proximity from {gpsLocationLabel}
            </p>
          </div>

          <div className="flex items-center gap-2">
            <button
              onClick={handleDetectGPS}
              disabled={isDetectingGps}
              className="px-3 py-1.5 bg-teal-50 dark:bg-teal-950/40 text-[#0bbbb6] border border-[#0bbbb6]/30 hover:bg-[#0bbbb6]/10 rounded-2xl text-xs font-bold transition flex items-center gap-1.5 cursor-pointer"
            >
              <LocateFixed className={`w-3.5 h-3.5 ${isDetectingGps ? 'animate-spin' : ''}`} />
              <span>{isDetectingGps ? 'Detecting...' : 'Detect GPS'}</span>
            </button>

            <button
              onClick={() => onNavigate('search')}
              className="text-xs font-bold text-[#0bbbb6] hover:text-[#0aa6a1] flex items-center gap-1 transition cursor-pointer"
            >
              <span>View All ({pharmacies.length})</span>
              <ArrowRight className="w-3.5 h-3.5" />
            </button>
          </div>
        </div>

        <div className="grid grid-cols-1 md:grid-cols-3 gap-3.5">
          {nearestPharmacies.map((ph) => (
            <div
              key={ph.id}
              className="bg-white dark:bg-slate-900 border border-slate-200/80 dark:border-slate-800 hover:border-[#0bbbb6]/40 dark:hover:border-teal-500/40 rounded-3xl p-5 shadow-xs hover:shadow-md transition-all flex flex-col justify-between space-y-3"
            >
              <div className="space-y-2">
                <div className="flex items-start justify-between gap-2">
                  <div className="w-10 h-10 rounded-2xl bg-teal-500/10 text-[#0bbbb6] dark:bg-teal-500/20 dark:text-teal-300 flex items-center justify-center font-bold shrink-0">
                    <Store className="w-5 h-5" />
                  </div>
                  <span className="px-2.5 py-1 rounded-full bg-emerald-50 dark:bg-emerald-950/40 text-emerald-700 dark:text-emerald-300 border border-emerald-200 dark:border-emerald-800 text-xs font-black flex items-center gap-1">
                    <Compass className="w-3 h-3 text-emerald-600" />
                    <span>{ph.computedDistance} km away</span>
                  </span>
                </div>

                <div>
                  <h3 className="text-sm font-extrabold text-slate-900 dark:text-white line-clamp-1">
                    {ph.name}
                  </h3>
                  <p className="text-xs text-slate-500 dark:text-slate-400 line-clamp-2 mt-0.5 font-medium">
                    {ph.address}, {ph.city}
                  </p>
                </div>

                <div className="flex flex-wrap items-center gap-2 text-[11px] font-semibold text-slate-500">
                  <span className="px-2 py-0.5 rounded-full bg-slate-100 dark:bg-slate-800 text-slate-600 dark:text-slate-300">
                    {ph.openHours}
                  </span>
                  <span className="text-emerald-600 dark:text-emerald-400 font-bold">
                    {ph.medicines.length} Medicines Stocked
                  </span>
                </div>
              </div>

              <div className="pt-2 border-t border-slate-100 dark:border-slate-800 flex items-center gap-2">
                <a
                  href={`tel:${ph.phone}`}
                  className="flex-1 py-2 px-3 bg-slate-100 hover:bg-slate-200 dark:bg-slate-800 dark:hover:bg-slate-700 text-slate-700 dark:text-slate-200 rounded-xl text-xs font-bold transition flex items-center justify-center gap-1.5"
                >
                  <Phone className="w-3.5 h-3.5 text-[#0bbbb6]" />
                  <span>Call Store</span>
                </a>

                <button
                  onClick={() => {
                    if (onSelectPharmacyForNav) {
                      onSelectPharmacyForNav(ph);
                    } else {
                      onNavigate('search');
                    }
                  }}
                  className="flex-1 py-2 px-3 bg-[#0bbbb6] hover:bg-[#0aa6a1] text-white rounded-xl text-xs font-extrabold transition shadow-2xs flex items-center justify-center gap-1.5 cursor-pointer"
                >
                  <Navigation className="w-3.5 h-3.5" />
                  <span>Directions</span>
                </button>
              </div>
            </div>
          ))}
        </div>
      </div>

      {/* 6. TODAY'S ACTIVE MEDICINE REMINDERS LIST */}
      <div className="space-y-3 pt-2">
        <div className="flex items-center justify-between px-1">
          <h2 className="text-xs font-black uppercase tracking-wider text-slate-400 dark:text-slate-400">
            Medicine Reminders & Schedule
          </h2>
          {reminders.length > 0 && (
            <button
              onClick={() => onNavigate('reminders')}
              className="text-xs font-bold text-[#0bbbb6] hover:text-[#0aa6a1] flex items-center gap-1 transition cursor-pointer"
            >
              <span>View All ({reminders.length})</span>
              <ArrowRight className="w-3.5 h-3.5" />
            </button>
          )}
        </div>

        {/* EMPTY STATE OR REMINDERS LIST */}
        {reminders.length === 0 ? (
          <div className="bg-white dark:bg-slate-900 border border-slate-200/80 dark:border-slate-800 rounded-3xl p-8 sm:p-12 text-center space-y-4 shadow-xs">
            <div className="w-20 h-20 rounded-full bg-teal-50 dark:bg-teal-950/40 border border-[#0bbbb6]/20 flex items-center justify-center mx-auto text-[#0bbbb6]">
              <Pill className="w-10 h-10 animate-pulse" />
            </div>

            <div className="space-y-1.5 max-w-sm mx-auto">
              <h3 className="text-lg font-bold text-slate-900 dark:text-white">
                No medicine reminders scheduled
              </h3>
              <p className="text-xs text-slate-500 dark:text-slate-400 leading-relaxed font-medium">
                Add your prescriptions and daily vitamins to receive smart alerts and voice reminders.
              </p>
            </div>

            <div className="pt-2">
              <button
                onClick={() => onNavigate('reminders', { reminderSubTab: 'add' })}
                className="inline-flex items-center gap-2 px-6 py-3 bg-[#0bbbb6] hover:bg-[#0aa6a1] text-white rounded-2xl text-xs font-bold shadow-md hover:shadow-lg transition-all active:scale-95 cursor-pointer"
              >
                <Plus className="w-4 h-4" />
                <span>Add Medicine Reminder</span>
              </button>
            </div>
          </div>
        ) : (
          <div className="space-y-3">
            {reminders.map((rem) => {
              const isTakenToday = rem.times.every(t => 
                todayLogs.some(l => l.reminderId === rem.id && l.scheduledTimeSlot === t && (l.status === 'taken_on_time' || l.status === 'taken_late'))
              );

              return (
                <div
                  key={rem.id}
                  className="bg-white dark:bg-slate-900 border border-slate-200/80 dark:border-slate-800 hover:border-[#0bbbb6]/30 dark:hover:border-teal-500/30 rounded-3xl p-4 sm:p-5 shadow-xs transition-all flex flex-col sm:flex-row sm:items-center justify-between gap-4"
                >
                  <div className="flex items-start gap-3.5">
                    <div className="w-11 h-11 rounded-2xl bg-teal-500/10 text-[#0bbbb6] dark:bg-teal-500/20 dark:text-teal-300 flex items-center justify-center shrink-0 mt-0.5">
                      <Pill className="w-5.5 h-5.5" />
                    </div>

                    <div className="space-y-1">
                      <div className="flex flex-wrap items-center gap-2">
                        <h4 className="text-sm sm:text-base font-bold text-slate-900 dark:text-white">
                          {rem.medicineName}
                        </h4>
                        <span className="px-2.5 py-0.5 rounded-full text-[10px] font-bold bg-slate-100 dark:bg-slate-800 text-slate-600 dark:text-slate-300 border border-slate-200 dark:border-slate-700">
                          {rem.medicineType}
                        </span>
                        {rem.active ? (
                          <span className="px-2 py-0.5 rounded-full text-[10px] font-bold bg-emerald-100 dark:bg-emerald-950/40 text-emerald-700 dark:text-emerald-400">
                            Active
                          </span>
                        ) : (
                          <span className="px-2 py-0.5 rounded-full text-[10px] font-bold bg-slate-100 dark:bg-slate-800 text-slate-400">
                            Paused
                          </span>
                        )}
                      </div>

                      <div className="flex flex-wrap items-center gap-y-1 gap-x-3 text-xs text-slate-500 dark:text-slate-400 font-medium">
                        <span>{rem.dosage}</span>
                        <span>•</span>
                        <span>{rem.foodInstruction}</span>
                        <span>•</span>
                        <span>{rem.frequency}</span>
                      </div>

                      <div className="flex flex-wrap items-center gap-1.5 pt-1">
                        <Clock className="w-3.5 h-3.5 text-slate-400 mr-0.5" />
                        {rem.times.map((t) => {
                          const log = todayLogs.find(l => l.reminderId === rem.id && l.scheduledTimeSlot === t);
                          const isDone = log && (log.status === 'taken_on_time' || log.status === 'taken_late');

                          return (
                            <span
                              key={t}
                              className={`px-2.5 py-0.5 rounded-full text-xs font-semibold flex items-center gap-1 transition ${
                                isDone
                                  ? 'bg-emerald-50 dark:bg-emerald-950/40 text-emerald-700 dark:text-emerald-300 border border-emerald-200 dark:border-emerald-800'
                                  : 'bg-slate-50 dark:bg-slate-800 text-slate-700 dark:text-slate-200 border border-slate-200 dark:border-slate-700'
                              }`}
                            >
                              {isDone && <Check className="w-3 h-3 text-emerald-600 dark:text-emerald-400" />}
                              <span>{t}</span>
                            </span>
                          );
                        })}
                      </div>
                    </div>
                  </div>

                  <div className="flex items-center gap-2 self-end sm:self-center shrink-0">
                    <button
                      onClick={() => onNavigate('reminders')}
                      className="px-4 py-2 bg-slate-100 hover:bg-slate-200 dark:bg-slate-800 dark:hover:bg-slate-700 text-slate-700 dark:text-slate-200 rounded-2xl text-xs font-bold transition cursor-pointer"
                    >
                      Details
                    </button>
                    {!isTakenToday && rem.times.length > 0 && (
                      <button
                        onClick={() => handleMarkDoseTaken(rem, rem.times[0])}
                        className="px-4 py-2 bg-[#0bbbb6] hover:bg-[#0aa6a1] text-white rounded-2xl text-xs font-bold shadow-xs hover:shadow-md transition cursor-pointer flex items-center gap-1.5"
                      >
                        <CheckCircle2 className="w-3.5 h-3.5" />
                        <span>Mark Taken</span>
                      </button>
                    )}
                  </div>

                </div>
              );
            })}
          </div>
        )}
      </div>

    </div>
  );
}
