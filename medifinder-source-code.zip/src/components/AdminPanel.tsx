import React, { useState } from 'react';
import { ShieldAlert, Database, Users, Pill, Trash2, RefreshCw } from 'lucide-react';
import { reminderStore } from '../services/reminderStore';

export default function AdminPanel({ onClose }: { onClose: () => void }) {
  const [reminders, setReminders] = useState(reminderStore.getAllReminders());
  const [logs, setLogs] = useState(reminderStore.getAllLogs());

  const handleClearAll = () => {
    if (window.confirm('Are you sure you want to clear all system medicine reminders?')) {
      localStorage.removeItem('medifinder_reminders_v2');
      localStorage.removeItem('medifinder_logs_v2');
      setReminders([]);
      setLogs([]);
    }
  };

  return (
    <div className="fixed inset-0 z-50 bg-slate-950/80 backdrop-blur-md flex items-center justify-center p-4 animate-fade-in">
      <div className="bg-white dark:bg-slate-900 border border-slate-200/80 dark:border-slate-800 rounded-3xl max-w-3xl w-full p-6 sm:p-8 space-y-6 shadow-2xl max-h-[90vh] overflow-y-auto">
        
        <div className="flex items-center justify-between pb-4 border-b border-slate-200 dark:border-slate-800">
          <div className="flex items-center gap-3">
            <div className="p-2.5 bg-rose-500/10 text-rose-600 rounded-2xl">
              <ShieldAlert className="w-6 h-6" />
            </div>
            <div>
              <h2 className="text-lg font-extrabold text-slate-900 dark:text-white">
                Clinical Admin System Dashboard
              </h2>
              <p className="text-xs text-slate-500 dark:text-slate-400 font-medium">
                Internal system state & active background reminders log
              </p>
            </div>
          </div>

          <button
            onClick={onClose}
            className="px-4 py-2 bg-slate-100 dark:bg-slate-800 hover:bg-slate-200 dark:hover:bg-slate-700 text-slate-700 dark:text-slate-200 text-xs font-bold rounded-2xl transition cursor-pointer"
          >
            Close
          </button>
        </div>

        <div className="grid grid-cols-2 sm:grid-cols-3 gap-3">
          <div className="p-4 bg-slate-50 dark:bg-slate-800/60 rounded-2xl border border-slate-200/60 dark:border-slate-700/60 text-center">
            <div className="text-xl font-black text-slate-900 dark:text-white">{reminders.length}</div>
            <div className="text-[11px] font-bold text-slate-500 dark:text-slate-400">Total Reminders</div>
          </div>

          <div className="p-4 bg-slate-50 dark:bg-slate-800/60 rounded-2xl border border-slate-200/60 dark:border-slate-700/60 text-center">
            <div className="text-xl font-black text-emerald-600">{logs.length}</div>
            <div className="text-[11px] font-bold text-slate-500 dark:text-slate-400">Recorded Dose Logs</div>
          </div>

          <div className="p-4 bg-slate-50 dark:bg-slate-800/60 rounded-2xl border border-slate-200/60 dark:border-slate-700/60 text-center col-span-2 sm:col-span-1">
            <div className="text-xl font-black text-[#0bbbb6]">Active</div>
            <div className="text-[11px] font-bold text-slate-500 dark:text-slate-400">Service Worker Engine</div>
          </div>
        </div>

        <div className="space-y-3">
          <h3 className="text-xs font-black uppercase tracking-wider text-slate-400">
            System Reminders Raw Database
          </h3>
          <div className="bg-slate-950 text-slate-200 p-4 rounded-2xl font-mono text-[11px] overflow-x-auto max-h-48">
            <pre>{JSON.stringify(reminders, null, 2)}</pre>
          </div>
        </div>

        <div className="flex items-center justify-between pt-2">
          <button
            onClick={handleClearAll}
            className="px-4 py-2 bg-rose-50 hover:bg-rose-100 text-rose-600 text-xs font-bold rounded-2xl flex items-center gap-1.5 transition cursor-pointer"
          >
            <Trash2 className="w-4 h-4" />
            <span>Reset All Database Records</span>
          </button>
        </div>

      </div>
    </div>
  );
}
