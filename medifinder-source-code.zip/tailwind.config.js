/** @type {import('tailwindcss').Config} */
export default {
  content: [
    "./index.html",
    "./src/**/*.{js,ts,jsx,tsx}",
  ],
  darkMode: 'class',
  theme: {
    extend: {
      fontFamily: {
        sans: ['"Plus Jakarta Sans"', 'ui-sans-serif', 'system-ui', '-apple-system', 'BlinkMacSystemFont', '"Segoe UI"', 'Roboto', 'sans-serif'],
        display: ['"Plus Jakarta Sans"', 'sans-serif'],
      },
      letterSpacing: {
        tighter: '-0.035em',
        tight: '-0.02em',
        snug: '-0.01em',
        normal: '-0.005em',
        wide: '0.025em',
        wider: '0.05em',
        widest: '0.08em',
      },
      colors: {
        brand: {
          50: '#e6f8f7',
          100: '#ccf1ef',
          200: '#99e3df',
          300: '#66d5cf',
          400: '#33c7bf',
          500: '#0bbbb6',
          600: '#0aa6a1',
          700: '#088a86',
          800: '#066d6a',
          900: '#044e4c',
        }
      }
    },
  },
  plugins: [],
};
